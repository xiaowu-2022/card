iOS native storage fix, 2026-10-20.
Replace the included shell source file, recompile resources, then sign/build and install a new IPA.
H5 publication alone cannot patch the installed native vault.
Regression covers protection flags, native NSString/BOOL, lock, scope and backup exclusion.
No signed IPA is included. Physical-device acceptance is pending.
