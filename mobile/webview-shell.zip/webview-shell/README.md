# 2026-10-19: current Token transport

The 2.6.12 (2612) shell and ordinary H5 use explicit Bearer authentication via the
existing `/api/mobile/v1` endpoints. This supersedes the cookie synchronization
workflow described historically below. WebView credentials stay in page memory
and OS-protected native storage, with a scoped, encrypted, expiring HTTP mailbox
for document-to-shell capture; no credential travels through a URL or title.
See [consumer Token architecture](../../docs/architecture/CONSUMER_TOKEN_AUTH.md).

Release the PHP, matching H5 and signed rebuilt shell as a coordinated cutover.
Cookie-only installed shells require upgrading; do not replace their shared H5
entry alone. Old cookies are not imported: sign in once after upgrading. Native
resource builds do not constitute signed packages or real-device persistence tests.

# U卡 WebView 过渡工程

这是独立的 uni-app CLI 工程，只负责打开线上 H5，不导入原 App 的业务页面。

## 打包：一个版本来源、一个资源目录

版本只修改 `src/manifest.json` 的 `versionName` / `versionCode`。
不要修改生成目录的 manifest，也不要按 IPA 文件名或 HBuilder 显示的资源版本判定 iOS 安装包版本。

1. 用 HBuilderX 导入本目录 `mobile/webview-shell`；不要另行导入 `src`、`dist/build/app` 或旧 `mobile/uni-app`。
2. 使用 Node.js 22，首次安装依赖执行 `npm ci`。运行 `npm run typecheck`，然后运行 `npm run build:app`。
3. 此命令将旧 App 资源及 APK/IPA/WGT 打包缓存移到 `dist/archive/<时间>/`，保留历史签名包和签名配置；
   重新编译到唯一发布资源目录 **`dist/build/app-plus`**，核对其版本/AppID 与源码一致。不要同时执行此命令和 HBuilder 云打包。
4. 回到 HBuilderX，选中 `mobile/webview-shell`，执行「发行 → App 云打包」，使用原签名材料生成完整原生包。
   不使用自定义调试基座或仅资源更新作为发布包。Android 覆盖安装需要原签名一致。
5. 下载 IPA 后执行（路径含空格时加引号）：

   ```bash
   npm run check:ipa -- "dist/release/ipa/实际文件名.ipa"
   ```

   校验器同时检查 iOS `Info.plist` 的版本/构建号、包内资源的版本/构建号，以及 Bundle ID、DCloud AppID。
   任一不一致均返回失败，不应发布。校验只读，不重签或篡改 IPA，也不读取/输出签名密钥。
   若干净整包仍出现不一致，应保留本次云打包任务信息查原生打包环节，不能靠改资源版本掩盖。

DCloud AppID `__UNI__30F90A0`，Android 包名 `cc.specpay.cards`，iOS Bundle ID `com.tng.pingqiu`。
保留原图标和签名身份。编译资源不等于已经生成 APK / IPA。
历史 `dist/release` 安装包不会被构建命令修改；它们的版本不会随源码变化。
归档可能含 HBuilder 缓存签名材料，位于 Git 忽略的 `dist` 内，不要上传归档。

2026-10-09 检查发现旧 `dist/build/app` 为 2.6.01/2601，而 `app-plus` 和最新 IPA 的资源为 2.6.02/2602，
同一 IPA 的原生 Info.plist 仍为 2.6.01/2601。以上流程消除本地双目录和缓存混用；是否解决云端原生版本问题，
以新完整 IPA 校验通过为准，不将目录整理当作已修复安装包的证明。

参考：[DCloud CLI 构建目录](https://uniapp.dcloud.net.cn/quickstart-cli.html)、
[Apple 安装包版本字段](https://developer.apple.com/cn/help/glossary/version-number/)。

## 网站与线路

`src/config.json` 集中配置内置域名、公司 slug、H5 入口和缓存键。
当前内置 23 条种子域名，以 `src/config.json` 为准；历史上移除的
`specpay.cc`、`specpay.top`、`specpay.vip` 不在种子中。此调整不禁止服务器目录或已验证缓存
再次提供这些域名；若要停止动态发现，需在 Platform 中停用或解绑相应域名。
默认入口为 `https://选定域名/#/pages/login/index`。
部署前确保所有分配给该公司的域名均提供同一份 H5 和同源 API。

每次启动、重试和手动重连，从内置域名与缓存域名合并、去重后的有效候选池
随机抽取最多两组，每组最多三条。首组并发读取 `/api/mobile/v1/domains`；
首条通过 HTTPS、公司 slug、已缓存公司 ID 和活动域名成员校验的响应立即胜出，
取消其余请求。首组全部失败或超时后才启动第二组，不逐条补测其他线路。
每组上限 2 秒，整轮上限 4 秒；最多检测六条、最多三个并发，不遍历或全量比速。
上次使用的线路不强制占首组名额。两组失败后显示中文错误与重试，点击重试重新抽样。
这 4 秒仅指选线，不包括后续登录确认及网页加载。

完整的新目录替换缓存，但不追加检测其中的新域名；缓存不会绕过服务器验证。
检测期间不发送 Token，选定已验证公司线路后才恢复凭证并继续现有身份/页面显示检查。
每次回到前台，最多每分钟刷新一次目录缓存，不自动移动当前网页；手动重连复用
正在进行的目录发现。保留页面挂载状态和滚动位置。

启动选线及网页加载期间显示本地黑金品牌欢迎页：“Spec Pay 万事达U卡 / 全球支付，尽在掌握。”，
卡片示意图随包内置，不依赖网络。移除常驻返回、刷新、线路工具栏；加载成功后网页占满状态栏下方区域。
加载超时或连接失败时在同一品牌页提供重试；“重新连接”确认后选择线路并恢复有效登录，失效凭证仍需重新登录。
Android 返回键优先回退网页历史，无历史时提示退出。
WebView 不注入 5+ 权限；业务通过 H5 的 Token 接口及原有服务端权限处理。
壳不保存账号密码、不替网页重发交易，也不注入脚本提交表单。2026-10-09 起允许下述受公司范围约束的登录凭证保存与恢复。

## 2026-10-09 同公司跨域保持登录

后续冷启动修正：iOS 读取已登录来源的 Cookie 时先做有界等待；首次读空不再
写入“已退出”标记并清掉目标线路。仍无法恢复时显示重试，只有用户确认
“重新登录”才清除本机状态。捕获暂时失败时保留新来源信息但丢弃旧账号凭证，
防止恢复成前一个账号。同域已有相同 Cookie 时不覆盖，跨域写入同时带
Max-Age 与 Expires；服务端 30 天、公司/账号/密码撤销校验保持不变。

这次修改在壳内，需重新云打包并覆盖安装。离线测试覆盖 Cookie 延迟可见、
恢复失败后重试、明确重新登录、退出不复活及同域不重写；仍需 iPhone 登录后
杀进程重开、切换线路和退出重开验收。没有将浏览器模拟当作真机登录保持成功。


壳通过 [HTML5+ 原生 Cookie API](https://www.html5plus.org/specification/Navigator.html)
读取/设置 `consumer_remember` 这一项 HttpOnly 凭证，保持 Secure、SameSite=Lax、
host-only；不复制 Laravel 会话、CSRF、管理员或第三方 Cookie，不向网页注入 Token。
复用服务端已有的 browser token/hash、30 天滑动有效期和撤销机制，不新增 Bearer
能力、不更改普通浏览器的跨域规则。各线路必须属于同一部署并共享现有 APP_KEY/数据库。

Android 使用 AndroidKeyStore AES-GCM 再加密持久化，作用域包含壳 AppID、公司 slug
和公司 ID，不含所选线路。丢失密钥/损坏密文后不从旧 Cookie 绕过恢复。iOS 继续使用
原生 WebView 的 HttpOnly Cookie 存储，从仍在已验证列表中的最近登录域名恢复；
没有新增 Keychain 或明文 Token 存储。源域名已移除且无可用凭证时需要重新登录。

新安装版本可在第一次运行时接续旧版本最近线路的有效 Cookie。已有保存记录后，
明确退出标记阻止旧 Cookie 重新导入。切换前只在已验证的活动页面捕获凭证，目标
Cookie 写入并读回确认后才打开 `/?app_webview=1#/pages/login/index`。
H5 只发出公司 ID 和已登录/未登录通知；标题事件不携带账号、密码或凭证，远程
页面仍然 `plusrequire:none`。非当前窗口、非当前域名、不同公司和旧事件均不接受。

H5 API 的 `X-Consumer-Webview: 1` 只要求更严格的凭证验证，不能授予权限。
PHP 在该模式下不使用目的域名遗留的其他用户会话；没有有效 remember 凭证时
清除消费者登录，有效凭证的账号不同时重新绑定并清除联系信息变更流程。
退出登录撤销服务端 token，并清除壳保存与已验证域名中的同项 Cookie。
后台仍校验公司、账号状态及 session_version，交易/表单请求不会自动重放。

发布需同时更新 `RememberConsumerSession.php`、`public/h5` 和重新云打包的壳。
无需数据库迁移；仅更新 H5 不能让旧 APK 获得原生凭证恢复能力。编译 App 资源
不等于生成签名 APK/IPA。真机验收：登录后杀进程重开并切换线路、退出后换线路、
更换账号、密码撤销与过期，以及 Android/iOS HttpOnly Cookie 写入时序。

## 配套 H5

H5 登录页首次进入默认英文，右上角可切换公司已启用的语言；注册页沿用所选语言。
需要把本次 `public/h5` 部署到服务器。只换壳 APK 而没有部署 H5，线上仍会显示旧网页。
后续网页修改部署 H5 即可；修改内置种子、壳行为或原生权限需要重新打包。

本地已验证目录选择和缓存测试、类型检查、App 资源编译。发布前仍需真机验证：
登录保持、注册、身份证照片选择/上传、客服图片、流水、返回键及断网恢复。
本工程不宣称已完成 APK 签名或真机验收。

## 2026-10-09 冷启动窗口布局修正

针对冷启动登录页底部黑边、页面切换或键盘开合后可能恢复的反馈，父壳改为
固定视口，欢迎页在壳内滚动，不再靠欢迎页内容撑高父页面。子窗口明确采用
absolute 定位，收到网页就绪信号后先移除欢迎页，等待 Vue 完成布局更新，
再应用 top/bottom 边界并显示子窗口；回到前台时重新应用边界。
继续保留零 windowHeight 启动兼容、就绪检测和失败重试，过期回调不得显示旧窗口。

这是对启动显示顺序的修正，尚未证明就是用户设备黑边的根因。需要用
`mobile/webview-shell` 重新云打包、原签名覆盖安装，并验证冷启动、键盘、
登录后切换、前后台恢复及调试面板开关。仅部署 H5 不会应用此壳修改。
App 资源编译成功不等于已生成签名 APK；版本号当前未改。

## 2026-10-08 白屏入口修复

这些域名的站点根目录已经指向 H5 产物文件夹，访问入口必须是
`https://选定域名/#/pages/login/index`，不是 `/h5/#/pages/login/index`。
旧壳错误地加了 `/h5/`，服务器回退返回首页后，页面相对资源被解析为
`/h5/assets/...` 并返回 404，造成白屏。此前将其判断为服务器缺失资源不准确。
已验证 `https://27m.my/assets/index-Co5jBsxL.js` 返回 200 和 JavaScript
内容类型；无需为此修改服务器根目录或重新部署 H5 文件。

`src/config.json` 的 `entryPath` 已修正为根路径。`/api/mobile/v1/domains`
仍是公司线路接口，保留原有公司校验。`build-manifest.json` 仅是构建信息，
壳启动不请求它。不要把磁盘上的 `public/h5` 路径等同于公开 URL 路径。

壳代码同时增加单探测 4.5 秒、整轮 15 秒的独立超时，避免原生请求缺失
回调时无限等待。原生子窗口由父页面管理，不再对 append 后的窗口调用
独立 show/hide；通过内容区域尺寸控制网页展示，忽略空白文档的 loaded
事件，失败后保留重试界面。参考 [HTML5+ Webview append 约定](https://www.html5plus.org/specification/Webview.html)。

验证：`node --test tests/Frontend/webview-shell.mjs`（10 项离线测试，包含
实际入口配置的加载地址检查）、`npm --prefix mobile/webview-shell run typecheck`
和 `build:app`。这不代表签名 APK 或 OPPO 真机已通过。
入口修复需要从本工程重新云打包安装，旧 APK 内置路径不会随 Git 部署改变。
AppID 与版本保持当前 manifest 不变。


## 2026-10-08 欢迎页后黑屏修复（2.5.07）

2.5.06 将远程窗口初始化为 0px 高，并在原生 loaded 事件后直接撤掉欢迎页。
loaded 不能证明 H5 已渲染；此前测试仅模拟事件，未覆盖此情况。
2.5.07 从创建起采用 top/bottom 完整布局及 render:always，以透明度控制显隐，
不依赖启动期间可能未就绪的 windowHeight。只有检测到 uni-page-body 有可见
尺寸和文本、经过两次动画帧后才显示网页。检测只通过临时标题传递本轮就绪
标记，不读取输入值/Cookie、不注入 5+ 权限、不发业务请求，并恢复原网页标题。
30 秒内仍无内容则关闭子窗口，保留黑金欢迎页、当前域名和重试入口；重试重新
创建完整尺寸窗口，旧窗口/旧轮次事件不能覆盖新状态。附加子窗口仍不调用 show。

验证须包括缺失脚本导致的空 #app、正常 H5、失效事件及超时重试。浏览器与离线
事件测试不能代替 OPPO A72 / ColorOS 12.1 的 APK 真机验收。需重新云打包安装，
仅部署线上 H5 不能改变 2.5.06 APK 中的窗口逻辑。


## 远程调试开关（2.5.07）

Platform 公司配置的 App 设置提供默认关闭的“App 调试模式”，与版本元数据
一起保存，沿用 tenant.manage、公司锁、revision、确认与原子审计；无需提高版本号。
开关存放在既有 tenant_android_releases.metadata 中，不新增数据库迁移。
独立只读 GET /api/mobile/v1/app-debug 按当前域名解析公司，返回公司 ID/slug 和布尔
开关，no-store；无版本发布时默认关闭。此接口不依赖版本检查成功。

壳仅向已验证的当前公司域名查询，每 10 秒更新；单次请求最多 3 秒，失败或公司
不符即关闭，15 秒有效期兜底。进入后台即清空停止，回到前台重新验证，未开启时
不保留日志。开启后预留底部调试面板，展示脱敏当前地址/路由、状态、原生加载
事件、控制台级别及参数类型、异常类型/行列号、资源失败和 Promise 异常。
日志最多 60 条，仅本机内存，不写本地存储、不上传。网页 title 事件只传递白名单
结构；不展示原始参数、错误文本、Cookie、请求头/正文、查询参数或任意动态路径。
关闭时恢复 console 函数、移除监听和计时器、清空日志并恢复网页全屏尺寸。
诊断从远程开关验证成功后采集，不能追溯此前的错误。

部署匹配 PHP 路由/控制器和管理端 public/build 后，需要重新云打包安装 2.5.07；
旧 APK 不支持远程调试。无需重新部署业务 H5。后台开关以后无需重新打包。

### 父页面实测高度

静态对照页仍出现黑边后，子窗口改为使用父 `.shell` 的实际布局高度计算
显式像素高度（扣除一次顶部预留及可选调试区）。不使用 screenHeight，也不
依赖启动时可能为零的 windowHeight。首次读取不到有效尺寸仍用完整 top/bottom
布局，不写零高度；已取得有效值后零测量保留上次尺寸。250ms 内测量回调缺失
时使用已有边界，避免就绪网页永久透明。测量回调按窗口和轮次隔离。
尺寸变化、前台恢复和调试区切换会重测；开启现有公司 App 调试时记录
parent/top/height/bottom 数值，日志仅在本机内存中保留。

编译器当前强制产出 statusbar.immersed=supportedDevice，不能把修改源 manifest
当作关闭沉浸模式的证明。此次显式高度方案仍需原签名打包和真机冷启动验证，
离线尺寸模拟不等于已重现或解决黑边。H5 发布目录不包含此原生壳改动。

### 启动展示页伸缩试验（2026-10-09）

按用户要求将失败的 H5 登录页 viewport 缩放试验移除。现在在本地展示页仍
显示、远程内容已就绪时，让透明的 H5 原生子窗口缩短一次（最多 300px，
不超过当前高度一半），120ms 后恢复当前完整边界，再显示登录页。该操作
每次壳启动最多一次，不开启调试、不改变状态栏、不重新加载网页；失效窗口
和退出/失败后的回调不能显示旧内容。读不到有效高度时保留原有显示流程。

这是针对真机黑边的验证性改动，离线测试不能证明黑边已消失。需要重新云打包
本工程；public/h5 只包含撤掉登录页伸缩的版本，不包含原生窗口伸缩。

## 2026-10-09 邀请海报保存

此前 H5 通过 `<a download>` 保存，WebView 未接入下载/相册处理，图片长按
也没有原生保存动作。现由 H5 的保存按钮和长按触发专用 PNG 保存通道，壳使用
[Bitmap](https://www.html5plus.org/doc/zh_cn/nativeobj.html) 写入临时文件，调用
[Gallery.save](https://www.html5plus.org/doc/zh_cn/gallery.html#plus.gallery.save)
保存到系统相册，只有成功回调才显示保存成功；失败和等待超时均明确提示。

继续保持远程页 `plusrequire:none`。只允许当前已验证公司域名和当前文档使用
该通道；PNG 分片逐个确认、单次保存、防重放，限制体积、尺寸和传输时间。
不接受远程 URL、任意文件路径或通用原生调用，不发送凭证、上传海报或记录图片。
切换文档会丢弃未完成传输；临时图片和 Bitmap 使用后清理。
保留已有 Camera（Camera & Gallery）模块及 iOS 相册写入用途说明。

发布需部署本次 `public/h5`，并重新云打包 `mobile/webview-shell` 安装。
旧壳会提示需要更新，不再静默执行无效下载。普通浏览器仍使用浏览器下载。
离线通道、原生 API 模拟和浏览器交互测试不等于真机相册验收；需验证 Android/iOS
授权、拒绝权限、相册落盘，以及长按与连续点击。App 资源已编译不代表生成签名包。

### 2026-10-09 iPhone 保存等待修复

本地现有 IPA 的 Info.plist 已含相册读/写用途说明，不能把未弹授权直接归因于缺少配置。
保存前的 PNG 标题分片通道原来只发送一次，丢失任一片或确认便会等到总超时。
现在每 500ms 重发未确认分片，10 秒无响应退出；接收端重发确认/最终结果，
相册等待期间回复处理中，同一请求只执行一次原生保存。诊断日志避让海报标题。
App 海报最长边限制为 1600px，降低无损 PNG 传输和解码开销，二维码仍按整数像素绘制。
H5 另加 125 秒兜底，兼容不返回结果的旧壳；完整 uni-app 原生保存也有 60 秒兜底。
超时提示先检查相册，不能将超时视为确定没有保存。原生系统授权仍由 Gallery.save 触发，
不在页面打开时申请权限。

已增加分片/中间确认/最终回执丢失及授权等待不重复保存的回归覆盖。
需要更新 H5，并重新云打包、安装当前壳；仅编译资源不会更新已安装 IPA。
这些修复覆盖已确认的通道故障模式；具体手机是否存在其他原生问题仍需真机验收。

### 后续修正：保留已可用的 iOS WebView 保存路径

用户确认：之前能保存的也是 WebView 版，回归发生在新增 WebView 判断之后。
`8adcaaa` 将原来的 H5 图片下载替换为等待壳回执，并对无桥接的 WebView 直接报更新错误。
现 iPhone/iPad WebView（包括 iPad 桌面 UA）优先恢复原来的图片下载路径，
不因缺少桥接而拦截，也不等待已注入的桥接；长按交给系统图片菜单，不额外触发保存。
Android 保留原生相册通道及上述重试保护。页面仅报告下载已请求，不冒充相册写入成功。
本次 iOS 回退只需部署 H5 并重新加载页面，不依赖重新云打包 IPA。
浏览器回归覆盖 iPhone/iPad 的缺失/无响应桥接及长按行为；系统菜单和实际相册落盘仍需真机确认。
