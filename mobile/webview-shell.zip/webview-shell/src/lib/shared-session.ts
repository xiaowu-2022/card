import { origin, type DirectoryCache } from './directory';

export type SessionIdentity = { tenantId: string; signedIn: boolean; restricted?: boolean };
export const rememberCookie = 'consumer_remember';
export class LoginRestoreUnavailable extends Error {
    constructor() { super('登录状态尚未恢复，请重试；若仍无法恢复，可重新登录。'); }
}
// Laravel's encrypted/URL-encoded cookie value only, never a Set-Cookie string.
export const validRememberCookie = (value: string) => /^[A-Za-z0-9%+/=_-]{32,8192}$/.test(value);
export function readRememberCookie(header: string): string | null {
    const values = header.split(';').map(part => part.trim()).filter(part => part.startsWith(rememberCookie + '='));
    if (values.length !== 1) return null;
    const value = values[0].slice(rememberCookie.length + 1);
    return validRememberCookie(value) ? value : null;
}
export function pageOrigin(url: unknown): string | null {
    // Native WebViews have no URL while their first document is being created.
    if (typeof url !== 'string') return null;
    return origin(url.match(/^https:\/\/[^/?#]+/i)?.[0]);
}
type Metadata = { initialized: boolean; source: string | null; signedIn: boolean; recovering?: boolean };
export function sharedSession(ports: {
    cookies: { get(url: string): string; set(url: string, value: string): void };
    // Android: AES-GCM/Keystore. iOS: retain credentials only in its native
    // HttpOnly cookie store; metadata never contains a credential.
    vault: { read(): string | null; write(value: string | null): void } | null;
    metadata: { get(): Metadata | null; set(value: Metadata): void };
    verify?: (url: string, cookie: string | null) => Promise<SessionIdentity>;
}) {
    let directory: DirectoryCache | null = null;
    let credential: string | null = null;
    let initialized = false;
    const trusted = (url: string) => !!directory && directory.origins.includes(url) && origin(url) === url;
    function remember(source: string | null, signedIn: boolean) {
        ports.metadata.set({ initialized: true, source, signedIn });
    }
    function forget() {
        credential = null;
        remember(null, false);
        ports.vault?.write(null);
    }
    function capture(url: string) {
        if (!trusted(url)) return false;
        try {
            const value = readRememberCookie(ports.cookies.get(url + '/'));
            if (!value) {
                // Do not restore an earlier account, but retain the trusted source
                // so a delayed native cookie sync can recover on the next start.
                credential = null;
                ports.metadata.set({ initialized: true, source: url, signedIn: true, recovering: true });
                return false;
            }
            if (credential !== value) ports.vault?.write(value);
            credential = value;
            remember(url, true);
        } catch (error) {
            // Never retain an earlier account if saving the current one fails.
            credential = null;
            try { forget(); } catch { /* memory is already cleared */ }
            throw error;
        }
        return true;
    }
    function clear() {
        // Persist the logout marker before touching the vault/cookie store so a
        // delayed response or failed native deletion cannot resurrect it.
        try { forget(); } finally {
            for (const url of directory?.origins ?? []) {
                ports.cookies.set(url + '/', rememberCookie + '=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly; SameSite=Lax');
            }
        }
    }
    return {
        async configure(value: DirectoryCache, previousOrigin?: string) {
            if (directory && directory.tenantId !== value.tenantId) throw new Error('Company changed');
            directory = value;
            if (initialized && !ports.metadata.get()?.recovering) return;
            const meta = ports.metadata.get();
            if (meta?.initialized && !meta.signedIn) { initialized = true; return; }
            credential = meta?.recovering ? null : ports.vault?.read() ?? null;
            if (credential && !validRememberCookie(credential)) credential = null;
            // Adopt an existing installation once. iOS restores from the last
            // verified host's native cookie store, not JS/localStorage.
            const source = meta?.source ?? previousOrigin;
            if (!credential && (!ports.vault || !meta?.initialized || meta?.recovering) && source && trusted(source)) {
                // WKWebView's cookie store can become available after the shell.
                // An empty first read must not become a durable logout marker.
                for (let attempt = 0; attempt < 60; attempt++) {
                    const value = readRememberCookie(ports.cookies.get(source + '/'));
                    if (value) { capture(source); break; }
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
                if (!credential && meta?.signedIn) throw new LoginRestoreUnavailable();
            }
            if (!credential && meta?.signedIn) throw new LoginRestoreUnavailable();
            initialized = true;
        },
        expectedSignedIn: () => !!credential || ports.metadata.get()?.signedIn === true,
        capture,
        clear,
        async restore(url: string) {
            if (!trusted(url)) throw new Error('Unverified login destination');
            const value = credential;
            if (!value && ports.metadata.get()?.signedIn) throw new LoginRestoreUnavailable();
            const cookie = value
                ? `${rememberCookie}=${value}; Path=/; Max-Age=2592000; Expires=${new Date(Date.now() + 2592000000).toUTCString()}; Secure; HttpOnly; SameSite=Lax`
                : `${rememberCookie}=; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly; SameSite=Lax`;
            if (!value || readRememberCookie(ports.cookies.get(url + '/')) !== value) ports.cookies.set(url + '/', cookie);
            // Some runtimes commit native cookie writes asynchronously. Do not
            // start the destination H5 before the intended credential is ready.
            for (let attempt = 0; attempt < 60; attempt++) {
                if (readRememberCookie(ports.cookies.get(url + '/')) === value) {
                    if (ports.verify) {
                        const result = await ports.verify(url, value);
                        if (result.tenantId !== directory?.tenantId || typeof result.signedIn !== 'boolean'
                            || (result.signedIn && !value)) throw new LoginRestoreUnavailable();
                        // A valid same-company guest response confirms expiry. Show login without
                        // erasing the native vault on a transient error or accepting another account.
                        return result;
                    }
                    return { tenantId: directory!.tenantId, signedIn: value !== null };
                }
                await new Promise(resolve => setTimeout(resolve, 50));
            }
            throw new Error('登录状态恢复失败，请重试。');
        },
    };
}
