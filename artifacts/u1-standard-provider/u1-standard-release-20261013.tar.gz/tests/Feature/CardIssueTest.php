<?php

use App\Application\Card\U1Callbacks;
use App\Application\CardProduct\CreateCardProductAction;
use App\Application\CardProviderDirectory\U1Accounts;
use App\Infrastructure\Providers\Card\U1ApiClient;
use App\Infrastructure\Providers\Card\U1NotificationVerifier;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Validation\ValidationException;

use App\Application\Assets\AssetOverviewQuery;
use App\Application\Card\ActivatePhysicalCardAction;
use App\Application\Card\AdminCardLoadsQuery;
use App\Application\Card\ApplyCardIssueResultAction;
use App\Application\Card\ArchiveClearedUserCardAction;
use App\Application\Card\BatchCardTransactionSync;
use App\Application\Card\CardProductProviderRouter;
use App\Application\Card\CardVoidBatch;
use App\Application\Card\CreateCardIssueAction;
use App\Application\Card\CreateCardRecipientAction;
use App\Application\Card\DTOs\CardManagementInput;
use App\Application\Card\ManageCardAction;
use App\Application\Card\PlatformCardQuery;
use App\Application\Card\PlatformCardTransactionsQuery;
use App\Application\Card\ProcessCardNotificationAction;
use App\Application\Card\RecordCardTransactionsAction;
use App\Application\Card\RefreshManagedCardAction;
use App\Application\Card\SubmitProviderCardholderAction;
use App\Application\Card\SyncCardIssueAction;
use App\Application\Card\SyncProviderCardholderAction;
use App\Application\Card\SyncUserCardTransactionsAction;
use App\Application\Card\UserCardCenterQuery;
use App\Application\Card\UserCardholderDetailsQuery;
use App\Application\Card\UserCardManagementAction;
use App\Application\Card\UserCardOverviewQuery;
use App\Application\Card\UserCardTransactionsQuery;
use App\Application\CardProduct\CardProductCatalogQuery;
use App\Application\CardProduct\UpdateCardProductAction;
use App\Application\CardProviderDirectory\SaveCardProviderReferenceAction;
use App\Application\Cleanup\CleanupTombstones;
use App\Application\Cleanup\DataCleanup;
use App\Application\Kyc\ApproveKycAction;
use App\Application\Kyc\SubmitKycApplicationAction;
use App\Application\Promotion\PaidPromotionPurchase;
use App\Application\SecurityDeposit\FundSecurityDepositAction;
use App\Application\SecurityDeposit\RefundSecurityDepositAction;
use App\Application\Tenant\PlatformDailyFundsQuery;
use App\Application\Tenant\PlatformOverviewQuery;
use App\Application\Tenant\UpdateTenantBusinessSettingsAction;
use App\Application\User\PlatformUserCardsSummary;
use App\Application\Wallet\ActivateUserWalletAction;
use App\Application\Wallet\WalletActivityQuery;
use App\Domain\Admin\Enums\AdminUserStatus;
use App\Domain\Admin\Models\AdminUser;
use App\Domain\Audit\Models\AuditLog;
use App\Domain\Audit\Services\AuditLogger;
use App\Domain\Card\Enums\CardIssueStatus;
use App\Domain\Card\Enums\ProviderCardholderStatus;
use App\Domain\Card\Models\CardIssueOrder;
use App\Domain\Card\Models\CardManagementOrder;
use App\Domain\Card\Models\CardProviderEvent;
use App\Domain\Card\Models\CardTransaction;
use App\Domain\Card\Models\ProviderCardholder;
use App\Domain\Card\Models\UserCard;
use App\Domain\Card\Services\CardholderMaterials;
use App\Domain\CardProduct\Models\CardProduct;
use App\Domain\CardProduct\Models\TenantCardProductConfig;
use App\Domain\CardProvider\Contracts\CardProviderInterface;
use App\Domain\CardProvider\DTOs\ProviderCardDTO;
use App\Domain\CardProvider\DTOs\ProviderCardFundsDTO;
use App\Domain\CardProvider\DTOs\ProviderCardholderDTO;
use App\Domain\CardProvider\DTOs\ProviderCardQuoteDTO;
use App\Domain\CardProvider\DTOs\ProviderCardTransactionDTO;
use App\Domain\CardProvider\DTOs\ProviderOperationDTO;
use App\Domain\CardProvider\DTOs\ProviderSensitiveCardDTO;
use App\Domain\CardProvider\DTOs\ProviderTransactionPageDTO;
use App\Domain\CardProvider\Enums\MockProviderMode;
use App\Domain\CardProvider\Enums\ProviderCardholderReviewStatus;
use App\Domain\CardProvider\Enums\ProviderOperationStatus;
use App\Domain\CardProvider\Exceptions\ProviderRateLimitException;
use App\Domain\CardProvider\Exceptions\ProviderRejectedException;
use App\Domain\CardProvider\Exceptions\ProviderUnknownResultException;
use App\Domain\Kyc\Contracts\KycOcrProviderInterface;
use App\Domain\Kyc\DTOs\KycOcrResultDTO;
use App\Domain\Kyc\Enums\KycOcrOutcome;
use App\Domain\Kyc\Models\KycApplication;
use App\Domain\Ledger\DTOs\LedgerPostingInstruction;
use App\Domain\Ledger\DTOs\LedgerPostingPlan;
use App\Domain\Ledger\Enums\LedgerAccountType;
use App\Domain\Ledger\Models\LedgerAccount;
use App\Domain\Ledger\Models\LedgerEntry;
use App\Domain\Ledger\Services\LedgerWriter;
use App\Domain\Ledger\ValueObjects\Money;
use App\Domain\SecurityDeposit\Models\SecurityDepositRefundRequest;
use App\Domain\SecurityDeposit\Services\RefundCardPolicy;
use App\Domain\Tenant\Models\Tenant;
use App\Domain\User\Models\User;
use App\Domain\Wallet\Models\Wallet;
use App\Infrastructure\Providers\Card\MockCardProvider;
use App\Infrastructure\Providers\Card\PhotonPayCardProvider;
use App\Infrastructure\Providers\Card\PhotonPayCardResponseNormalizer;
use App\Infrastructure\Providers\Card\UnavailableCardProvider;
use App\Jobs\ProcessCardNotification;
use App\Support\Errors\DomainException;
use Carbon\CarbonImmutable;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;
use Illuminate\Http\Client\Factory;
use Illuminate\Routing\Middleware\ThrottleRequests;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Inertia\Testing\AssertableInertia as Assert;
use Monolog\Handler\TestHandler;
use Monolog\Logger;

it('prefills only owned card editable fields and confirmed holder changes without leaking private materials', function (): void {
    $this->holderMaterials = ['fields' => [
        'email' => 'original@example.test', 'date_of_birth' => '1990-01-02',
        'nationality_country_code' => 'MY', 'mobile' => '13800138000', 'mobile_prefix' => '86',
        'residential_country_code' => 'MY', 'residential_state' => 'Selangor', 'residential_city' => 'Petaling Jaya',
        'residential_address' => 'Original street', 'residential_postal_code' => '46000',
        'legal_first_name' => 'PRIVATE-NAME', 'identity_number' => 'PRIVATE-IDENTITY',
    ], 'documents' => ['front' => 'PRIVATE-OBJECT-KEY']];
    [$card, $provider, $action] = managedCardFixture($this);
    $original = $this->holder->materials_encrypted;
    $entries = LedgerEntry::query()->count();
    $url = 'http://a.localhost/cards/'.$card->id.'/management';
    $read = fn () => $this->actingAs($this->user, 'tenant_user')->postJson($url, ['action' => 'holder_details']);
    $response = $read()->assertOk()->assertJsonPath('fields.email', 'original@example.test')
        ->assertJsonPath('fields.mobile_country_code', 'CN')->assertJsonCount(10, 'fields');
    expect($response->headers->get('Cache-Control'))->toContain('private', 'no-store');
    expect($response->getContent())->not->toContain('PRIVATE-', 'documents', 'identity_number', 'provider_cardholder_id');
    $provider->shouldReceive('editCardholderFields')->once()->andReturnNull();
    $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'HOLDER_UPDATE', holderFields: ['email' => 'confirmed@example.test']);
    $read()->assertOk()->assertJsonPath('fields.email', 'confirmed@example.test')->assertJsonPath('fields.residential_address', 'Original street');
    $provider->shouldReceive('editCardholderFields')->once()->andThrow(new ProviderRejectedException('Rejected'));
    $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'HOLDER_UPDATE', holderFields: ['email' => 'failed@example.test']);
    $provider->shouldReceive('editCardholderFields')->once()->andThrow(new ProviderUnknownResultException('Unconfirmed'));
    $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'HOLDER_UPDATE', holderFields: ['email' => 'unknown@example.test']);
    $read()->assertOk()->assertJsonPath('fields.email', 'confirmed@example.test');
    expect($this->holder->fresh()->materials_encrypted)->toBe($original)
        ->and(LedgerEntry::query()->count())->toBe($entries)
        ->and(json_encode(app(UserCardCenterQuery::class)->get($this->tenant->id, $this->user->id)))->not->toContain('original@example.test', 'confirmed@example.test', 'PRIVATE-');
    $other = User::query()->where('tenant_id', '!=', $this->tenant->id)->firstOrFail();
    $this->actingAs($other, 'tenant_user')->postJson('http://b.localhost/cards/'.$card->id.'/management', ['action' => 'holder_details'])->assertNotFound();
    expect(fn () => app(UserCardholderDetailsQuery::class)->execute($this->tenant->id, $other->id, $card->id))->toThrow(ModelNotFoundException::class);
});

it('fails safely when original holder materials are unavailable rather than borrowing account information', function (): void {
    [$card] = managedCardFixture($this);
    $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/cards/'.$card->id.'/management', ['action' => 'holder_details'])
        ->assertStatus(503)->assertJsonMissingPath('fields');
});

function managedCardFixture($test, ?Closure $cardRead = null, string $available = '100.00000000'): array
{
    phaseTenReadyUser($test, $available);
    phaseTenIssue($test);
    $card = UserCard::query()->where('tenant_id', $test->tenant->id)->where('user_id', $test->user->id)->firstOrFail();
    $card->forceFill(['provider_status' => 'normal'])->save();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('getCard')->andReturnUsing($cardRead ?? fn () => new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'normal', false, '20.00000000'));
    app()->instance(CardProviderInterface::class, $provider);

    return [$card, $provider, app(ManageCardAction::class)];
}

it('platform operating overview totals unique successful card funding all cards and unknown cached balances without provider reads', function (): void {
    [$card, $provider, $action] = managedCardFixture($this, available: '1000.00000000');
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '101.00000000', '100.00000000', '1.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'OVERVIEW-LOAD', '101.00000000', '100.00000000', '1.00000000'));
    $card->forceFill(['balance_limit' => '120'])->save();
    $quote = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '500');
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $quote->id)->status)->toBe('SUCCEEDED');
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $quote->id);
    app(RecordCardTransactionsAction::class)->execute($card, [new ProviderCardTransactionDTO('OVERVIEW-LOAD', '100', 'USD', 'load', 'completed', now()->format('Y-m-d H:i:s'), null)], CarbonImmutable::now());
    $reader = Mockery::mock(CardProviderInterface::class);
    $reader->shouldNotReceive('getCard')->shouldNotReceive('getTransactionPage');
    app()->instance(CardProviderInterface::class, $reader);
    $access = array_fill_keys(['inflow', 'outflow', 'partners', 'cards', 'providers', 'assets'], true);
    $before = DB::table('ledger_accounts')->orderBy('id')->pluck('balance', 'id')->all();
    $overview = app(PlatformOverviewQuery::class)->execute($access);
    expect($overview['cards']['today'])->toBe('520.00000000')->and($overview['cards']['total'])->toBe('520.00000000');
    expect($overview['cards']['balance'])->toBe($card->fresh()->availableBalance());
    $this->actingAs(AdminUser::where('email', 'owner@platform.local')->firstOrFail(), 'platform_admin');
    $this->getJson('http://admin.localhost/platform/overview/sources?metric=cardFunding&period=total')->assertOk()->assertJsonPath('amount', '520.00000000')->assertJsonPath('rows.total', 2);
    $this->getJson('http://admin.localhost/platform/overview/sources?metric=cardBalance')->assertOk()->assertJsonPath('amount', $card->fresh()->availableBalance())->assertJsonPath('rows.total', 1);
    $this->getJson('http://admin.localhost/platform/overview/sources?metric=ordinaryAssets')->assertOk()->assertJsonPath('amount', $overview['assets']['ordinary']);
    expect($overview['assets']['ordinary'])->toBe(app(\App\Application\User\PlatformUserFinancialSummary::class)->funds($this->tenant->id, $this->user->id)['estimate']);
    expect(DB::table('ledger_accounts')->orderBy('id')->pluck('balance', 'id')->all())->toBe($before);
    $card->forceFill(['provider_balance' => null])->save();
    $overview = app(PlatformOverviewQuery::class)->execute($access);
    expect($overview['cards']['balance'])->toBeNull()->and($overview['assets']['ordinary'])->toBeNull()->and($overview['cards']['total'])->toBe('520.00000000');
    $this->getJson('http://admin.localhost/platform/overview/sources?metric=cardBalance')->assertOk()->assertJsonPath('amount', null)->assertJsonPath('rows.items.0.amount', null);
    $card->forceFill(['provider_balance' => '21', 'archived_at' => now()])->save();
    $overview = app(PlatformOverviewQuery::class)->execute($access);
    expect($overview['cards']['balance'])->toBe('421.00000000')->and($overview['cards']['total'])->toBe('520.00000000');
    Http::assertNothingSent();
});

it('permanently cleans card materials orders transactions and sync data without provider operations', function (bool $companyBatch): void {
    Http::preventStrayRequests();
    [$card, $provider, $management] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20', '20', '0'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'CLEANUP-LOAD', '20', '20', '0'));
    $load = $management->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $management->confirmLoad($this->tenant->id, $this->user->id, $card->id, $load->id);
    app(RecordCardTransactionsAction::class)->execute($card, [new ProviderCardTransactionDTO('CLEANUP-TX', '1.23456789', 'USD', 'purchase', 'completed', now()->format('Y-m-d H:i:s'), null)], CarbonImmutable::now());
    $platform = AdminUser::where('email', 'owner@platform.local')->sole();
    $batch = app(BatchCardTransactionSync::class)->create($platform, [...transactionBatchInput($this), 'tenant_id' => $companyBatch ? $this->tenant->id : null, 'card_ids' => [$card->id]]);
    $provider->shouldNotReceive('closeCard');
    $provider->shouldNotReceive('confirmCardTransferOut');
    $provider->shouldNotReceive('refundCardLoad');
    $cleanup = app(DataCleanup::class);
    $preview = $cleanup->preview($this->tenant->id, $platform, ['user_ids' => [$this->user->id], 'modules' => ['cards']]);
    expect($preview['summary']['blockers'])->toBe([]);
    $cleanup->execute($this->tenant->id, $preview['id'], $platform, (string) Str::uuid(), true);
    expect(UserCard::find($card->id))->toBeNull()->and(ProviderCardholder::find($this->holder->id))->toBeNull();
    foreach (['card_issue_orders', 'card_management_orders', 'card_transactions', 'card_provider_events', 'card_transaction_sync_items'] as $table) {
        expect(DB::table($table)->where('tenant_id', $this->tenant->id)->count())->toBe(0);
    }
    expect(DB::table('card_transaction_sync_batches')->where('id', $batch)->exists())->toBeFalse();
    expect($this->user->fresh())->not->toBeNull()->and($this->product->fresh())->not->toBeNull();
    expect((float) phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(100.0);
    expect(CleanupTombstones::contains('card::provider_card_id', $card->provider_card_id))->toBeTrue();
})->with(['company batch' => true, 'global header with one company' => false]);

it('blocks restricted card funding at confirmation and preserves completed replay', function (): void {
    [$card, $provider, $action] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'RESTRICTION-TEST', '20.00000000', '20.00000000', '0.00000000'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $before = LedgerEntry::count();
    $this->user->update(['card_transfer_blocked' => true]);
    expect(fn () => $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id))->toThrow(DomainException::class, 'Please contact support.');
    expect($order->fresh()->status)->toBe('QUOTED')->and(LedgerEntry::count())->toBe($before);
    $this->user->update(['card_transfer_blocked' => false]);
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('SUCCEEDED');
    $this->user->update(['card_transfer_blocked' => true]);
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('SUCCEEDED');
    expect(LedgerEntry::count())->toBe($before + 2);
});

it('manages card reload with quoted fee exact hold and one settlement', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '21.00000000', '20.00000000', '1.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-LOAD', '21.00000000', '20.00000000', '1.00000000'));
    $request = (string) Str::uuid();
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, $request, '20');
    expect($order->status)->toBe('QUOTED')->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
    expect($action->quote($this->tenant->id, $this->user->id, $card->id, $request, '20')->id)->toBe($order->id);
    $result = $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    expect($result->status)->toBe('SUCCEEDED')
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->subtract(Money::of('21', 'USDT'))->amount());
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('SUCCEEDED');
    expect(LedgerEntry::query()->where('reference_id', $order->id)->count())->toBe(2);
    expect(DB::table('inbox_events')->where('event_key', 'card_load_success:'.$order->id)->count())->toBe(1);
    $activity = app(WalletActivityQuery::class)->get($this->tenant->id, $this->user->id);
    $rows = collect($activity)->where('reference', $order->id)->values();
    expect($rows)->toHaveCount(1)
        ->and($rows[0]['amount'])->toBe('-21.00000000')
        ->and($rows[0]['state'])->toBe('Completed')
        ->and($rows[0]['eventType'])->toBe('CARD_LOAD_SETTLE')
        ->and($rows[0]['steps'])->toHaveCount(2);
    $other = User::query()->where('tenant_id', '<>', $this->tenant->id)->firstOrFail();
    expect(app(WalletActivityQuery::class)->get($this->tenant->id, $other->id))->toBe([]);
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('confirms reload without a second password or checkbox and replays without another debit', function (bool $unknown, string $client): void {
    [$card, $provider] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '21.00000000', '20.00000000', '1.00000000'));
    $confirmation = $provider->shouldReceive('confirmCardLoad')->once();
    if ($unknown) {
        $confirmation->andThrow(new ProviderUnknownResultException('Unconfirmed'));
    } else {
        $confirmation->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-ONE-SUBMIT', '21.00000000', '20.00000000', '1.00000000'));
    }
    Http::preventStrayRequests();
    if ($client === 'native') {
        $flow = $this->getJson('http://a.localhost/api/mobile/v1/bootstrap')->assertOk()->headers->get('X-Consumer-Flow');
        $token = $this->postJson('http://a.localhost/api/mobile/v1/login', ['identifier' => $this->user->email, 'password' => 'local-password'])->assertCreated()->json('token');
        $this->withToken($token)->withHeader('X-Consumer-Flow', $flow)->withHeader('X-Consumer-Page', '/cards');
    } else {
        $this->actingAs($this->user, 'tenant_user');
    }
    $prefix = match ($client) {
        'native' => '/api/mobile/v1/client', 'h5' => '/api/v1/client', default => ''
    };
    $url = 'http://a.localhost'.$prefix.'/cards/'.$card->id.'/management';
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $quote = $this->postJson($url, ['action' => 'quote', 'request_id' => (string) Str::uuid(), 'amount' => '20'])->assertOk()->assertJsonPath('state', 'quoted')->json();
    expect(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
    $input = ['action' => 'confirm', 'order_id' => $quote['id']];
    $this->postJson($url, $input)->assertOk()->assertJsonPath('state', $unknown ? 'confirming' : 'completed');
    expect(DB::table('inbox_events')->where('event_key', 'like', 'card_load_%:'.$quote['id'])->count())->toBe($unknown ? 0 : 1);
    $entries = LedgerEntry::query()->count();
    $this->postJson($url, $input)->assertOk()->assertJsonPath('state', $unknown ? 'confirming' : 'completed');
    expect(LedgerEntry::query()->count())->toBe($entries)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->subtract(Money::of('21', 'USDT'))->amount());
    $this->postJson($url, ['action' => 'return', 'request_id' => (string) Str::uuid(), 'amount' => '20'])->assertUnprocessable()->assertJsonValidationErrors(['current_password', 'confirmed']);
    $this->postJson($url, ['action' => 'reveal'])->assertUnprocessable()->assertJsonValidationErrors('current_password');
})->with([[false, 'web'], [true, 'web'], [false, 'h5'], [true, 'h5'], [false, 'native'], [true, 'native']]);

it('keeps uncertain reload held blocks a new request and recovers only by stable query', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andThrow(new ProviderUnknownResultException('Unconfirmed'));
    $provider->shouldReceive('queryCardFunds')->once()->andReturnUsing(fn ($id, $request, $kind) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-RECOVERY', '20.00000000', '20.00000000', '0.00000000'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('UNKNOWN');
    $overview = app(UserCardOverviewQuery::class);
    expect($overview->get($this->tenant->id, $this->user->id)['pending'])->toBe(1);
    $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/cards/'.$card->id.'/management', ['action' => 'history'])
        ->assertOk()->assertJsonPath('orders.0.id', $order->id)->assertJsonPath('orders.0.state', 'confirming');
    expect(fn () => $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20'))->toThrow(DomainException::class);
    expect($action->sync($this->tenant->id, $order->id)->status)->toBe('SUCCEEDED');
    expect($overview->get($this->tenant->id, $this->user->id)['pending'])->toBe(0);
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('returns only confirmed net card funds and never replays a return', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('returnCardFunds')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-RETURN', '10.00000000', '9.00000000', '1.00000000'));
    $id = (string) Str::uuid();
    $order = $action->operate($this->tenant->id, $this->user->id, $card->id, $id, 'RETURN', '10');
    expect($order->status)->toBe('SUCCEEDED')->and($order->arrival_amount)->toBe('9.00000000')
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->add(Money::of('9', 'USDT'))->amount());
    expect($action->operate($this->tenant->id, $this->user->id, $card->id, $id, 'RETURN', '10')->id)->toBe($order->id);
    $card->forceFill(['provider_balance'=>'10'])->save();
    $summary = app(\App\Application\User\PlatformUserCardsSummary::class)->read($this->tenant->id,$this->user->id,false,1);
    expect($summary['items'][0]->returned)->toBe('9.00000000')->and($summary['items'][0]->consumed)->toBe('1.00000000');
    expect(fn () => $action->operate($this->tenant->id, $this->user->id, $card->id, $id, 'RETURN', '11'))->toThrow(DomainException::class);
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('shows settled returns without synchronization and replaces them once provider history arrives', function (): void {
    [$card, $provider, $action] = managedCardFixture($this);
    $provider->shouldReceive('returnCardFunds')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'RETURN-HISTORY', '10.00000000', '9.00000000', '1.00000000'));
    $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'RETURN', '10');
    $tables = ['ledger_entries', 'ledger_postings', 'ledger_accounts', 'card_management_orders'];
    $before = collect($tables)->mapWithKeys(fn ($table) => [$table => DB::table($table)->orderBy('id')->get()->toJson()]);
    Http::preventStrayRequests();
    $query = app(UserCardTransactionsQuery::class);
    $read = fn () => $query->get($this->tenant->id, $this->user->id, $card->id, 1);
    $initial = $read()['items'];
    expect($initial)->toHaveCount(1)
        ->and($initial[0]['amount'])->toBe('-10.00000000')
        ->and($initial[0]['type'])->toBe('transfer_out')
        ->and($initial[0]['state'])->toBe('completed')
        ->and($initial[0]['timeKind'])->toBe('completed')
        ->and($initial[0]['feeAmount'])->toBe('-1.00000000')
        ->and(CardTransaction::count())->toBe(0);
    $platform = app(PlatformCardTransactionsQuery::class)->get($this->tenant->id, $card->id, 1);
    expect($platform['items'])->toBe($initial);
    $other = User::where('tenant_id', '!=', $this->tenant->id)->firstOrFail();
    expect(fn () => $query->get($other->tenant_id, $other->id, $card->id, 1))->toThrow(ModelNotFoundException::class);
    $this->travel(1)->minutes();
    app(RecordCardTransactionsAction::class)->execute($card, [
        new ProviderCardTransactionDTO('RETURN-HISTORY', '-10.00000000', 'USD', 'transfer_out', 'completed', '2026-10-10T13:01:00', null, '-1.00000000', 'USD'),
    ], CarbonImmutable::now());
    expect($read()['items'])->toBe($initial)->and($query->get($this->tenant->id, $this->user->id, $card->id, 2)['items'])->toBe([]);
    foreach ($tables as $table) {
        expect(DB::table($table)->orderBy('id')->get()->toJson())->toBe($before[$table]);
    }
    Http::assertNothingSent();
});

it('releases a reload hold only on a definitive rejection', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andThrow(new ProviderRejectedException('Declined'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $result = $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    expect(DB::table('inbox_events')->where('event_key', 'card_load_failed:'.$order->id)->count())->toBe(1);
    expect($result->status)->toBe('FAILED')->and($result->release_entry_id)->not->toBeNull()
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
    $row = collect(app(WalletActivityQuery::class)->get($this->tenant->id, $this->user->id))->firstWhere('reference', $order->id);
    expect($row['amount'])->toBe('0.00000000')->and($row['state'])->toBe('Returned')
        ->and($row['steps'])->toHaveCount(2);
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('requires owner scope and password before revealing ephemeral card number and CVV', function (): void {
    [$card,$provider] = managedCardFixture($this);
    $provider->shouldReceive('revealCard')->once()->andReturn(new ProviderSensitiveCardDTO('411111111111'.$card->last4, '987', false, '08/29'));
    $this->actingAs($this->user, 'tenant_user');
    $url = 'http://a.localhost/cards/'.$card->id.'/management';
    $this->postJson($url, ['action' => 'reveal', 'current_password' => 'incorrect'])->assertUnprocessable();
    $this->postJson($url, ['action' => 'reveal', 'current_password' => 'local-password'])->assertOk()->assertExactJson(['pan' => '411111111111'.$card->last4, 'cvv' => '987'])->assertHeader('Cache-Control', 'max-age=0, no-store, private');
    $this->postJson('http://b.localhost/cards/'.$card->id.'/management', ['action' => 'reveal', 'current_password' => 'local-password'])->assertRedirect();
    expect(json_encode($card->fresh()))->not->toContain('987', '411111111111');
});

it('rejects malformed or mismatched card numbers before revealing sensitive information', function (string $pan): void {
    [$card, $provider] = managedCardFixture($this);
    $provider->shouldReceive('revealCard')->once()->andReturn(new ProviderSensitiveCardDTO($pan, '987', false));
    $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/cards/'.$card->id.'/management', [
        'action' => 'reveal', 'current_password' => 'local-password',
    ])->assertStatus(503)->assertJsonMissingPath('pan')->assertJsonMissingPath('cvv');
})->with(['masked' => ['************1234'], 'too short' => ['1234'], 'wrong card' => ['4111111111119999']]);

it('rejects legacy callbacks whose products have no saved account even with the global key', function (int $keyBits): void {
    [$card] = managedCardFixture($this);
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $key = openssl_pkey_new(['private_key_bits' => $keyBits]);
    config(['card-provider.photonpay.webhook_public_key' => openssl_pkey_get_details($key)['key']]);
    $body = json_encode(['cardId' => $card->provider_card_id]);
    openssl_sign($body, $signature, $key, OPENSSL_ALGO_MD5);
    $this->call('POST', 'http://callback.example/webhooks/card-provider', [], [], [], [
        'CONTENT_TYPE' => 'application/json', 'HTTP_X_PD_SIGN' => base64_encode($signature),
        'HTTP_X_PD_NOTIFICATION_CATAGORY' => 'issuing', 'HTTP_X_PD_NOTIFICATION_TYPE' => 'auth'], $body)->assertNotFound();
    expect(CardProviderEvent::count())->toBe(0)->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
})->with([1024, 2048]);

it('diagnoses queued and retried notifications without processing them or leaking identifiers', function (): void {
    [$card, $provider] = managedCardFixture($this);
    $event = new CardProviderEvent;
    $event->forceFill(['tenant_id' => $this->tenant->id, 'user_id' => $this->user->id,
        'card_id' => $card->id, 'event_digest' => hash('sha256', 'diagnostic-test'),
        'category' => 'issuing', 'event_type' => 'auth', 'transaction_id' => 'PRIVATE-TX-ID', 'status' => 'PENDING'])->save();
    $before = $card->fresh()->getAttributes();
    $this->withoutMockingConsoleOutput();
    expect(Artisan::call('cards:notification-inspect', ['tenant' => $event->tenant_id, 'event' => $event->id]))->toBe(0);
    expect(Artisan::output())->toContain('"event_status": "PENDING"', '"attempts": 0')
        ->not->toContain('PRIVATE-TX-ID', $card->provider_card_id);
    expect($card->fresh()->getAttributes())->toBe($before)->and($event->fresh()->attempts)->toBe(0);
    expect(Artisan::call('cards:notification-inspect', ['tenant' => (string) Str::uuid(), 'event' => $event->id]))->toBe(1);
    expect(Artisan::output())->toContain('Notification not found in the selected company.');
    $provider->shouldReceive('getTransaction')->once()->andThrow(new ProviderUnknownResultException('private-error'));
    $handler = new TestHandler;
    Log::extend('notification_test', fn () => new Logger('photonpay', [$handler]));
    config(['logging.channels.photonpay' => ['driver' => 'notification_test']]);
    Log::forgetChannel('photonpay');
    app(ProcessCardNotificationAction::class)->execute($event->tenant_id, $event->id);
    expect($event->fresh()->status)->toBe('RETRY')->and($event->fresh()->attempts)->toBe(1)
        ->and($card->fresh()->provider_balance)->toBe($before['provider_balance']);
    $records = collect($handler->getRecords());
    expect($records->contains(fn ($r) => $r->message === 'photonpay.notification.processing'))->toBeTrue()
        ->and($records->contains(fn ($r) => $r->message === 'photonpay.card_refresh.applied'))->toBeFalse();
    $retry = $records->first(fn ($r) => $r->message === 'photonpay.notification.retry');
    expect($retry->context['event_id'])->toBe($event->id)
        ->and($retry->context['failure'])->toBe('unknown_result')
        ->and($retry->context['stage'])->toBe('card_refresh');
    $stage = $records->first(fn ($r) => $r->message === 'photonpay.card_refresh.stage');
    expect($stage->context['stage'])->toBe('transaction_lookup')
        ->and(json_encode($handler->getRecords()))->not->toContain('PRIVATE-TX-ID', 'private-error');
});

it('keeps failed inline notification reads for explicit follow-up without dispatching a retry', function (): void {
    [$card] = managedCardFixture($this, fn () => throw new ProviderUnknownResultException('private-provider-error'));
    $before = $card->fresh()->getAttributes();
    $entries = LedgerEntry::query()->count();
    $event = storedCardNotificationFixture($card, 'card_id');
    app(ProcessCardNotificationAction::class)->execute($event->tenant_id, $event->id);
    $event->refresh();
    expect($event->status)->toBe('RETRY')->and($event->attempts)->toBe(1)
        ->and($card->fresh()->provider_balance)->toBe($before['provider_balance'])
        ->and($card->fresh()->getRawOriginal('provider_balance_synced_at'))->toBe($before['provider_balance_synced_at'])
        ->and(LedgerEntry::query()->count())->toBe($entries);
    Queue::assertNotPushed(ProcessCardNotification::class);

    // A stale serialized job or old cron entry cannot perform another provider read.
    (new ProcessCardNotification($event->tenant_id, $event->id))->handle();
    $this->artisan('cards:recover', ['--tenant' => $event->tenant_id])->assertFailed();
    expect($event->fresh()->attempts)->toBe(1)->and($card->fresh()->refresh_generation)->toBe(1);
    $schedule = app(Schedule::class);
    expect(collect($schedule->events())->contains(fn ($entry) => str_contains($entry->command ?? '', 'cards:recover')))->toBeFalse();
});

it('does not log an applied balance when an outer transaction rolls back', function (): void {
    [$card] = managedCardFixture($this);
    $handler = new TestHandler;
    Log::extend('notification_test', fn () => new Logger('photonpay', [$handler]));
    config(['logging.channels.photonpay' => ['driver' => 'notification_test']]);
    Log::forgetChannel('photonpay');
    $before = $card->fresh()->getAttributes();
    DB::beginTransaction();
    try {
        app(RefreshManagedCardAction::class)->execute($this->tenant->id, $this->user->id, $card->id);
    } finally {
        DB::rollBack();
    }
    expect($card->fresh()->getAttributes())->toBe($before)
        ->and(collect($handler->getRecords())->contains(fn ($r) => $r->message === 'photonpay.card_refresh.applied'))->toBeFalse();
});

it('retries holder notifications when the provider lookup preserves stale ready state', function (): void {
    [$card, $provider] = managedCardFixture($this);
    $this->holder->forceFill(['synced_at' => now()->subMinute()])->save();
    $provider->shouldReceive('getCardholder')->once()->andThrow(new ProviderUnknownResultException('Unconfirmed'));
    $event = storedCardNotificationFixture($this->holder, 'cardholder_id');
    app(ProcessCardNotificationAction::class)->execute($event->tenant_id, $event->id);
    expect($event->fresh()->status)->toBe('RETRY')->and($event->fresh()->attempts)->toBe(1)->and($event->fresh()->processed_at)->toBeNull();
    $provider->shouldReceive('getCardholder')->once()->andReturn(new ProviderCardholderDTO($this->holder->provider_cardholder_id, ProviderCardholderReviewStatus::Ready, 'normal', 'passed'));
    app(ProcessCardNotificationAction::class)->execute($event->tenant_id, $event->id);
    expect($event->fresh()->status)->toBe('PROCESSED')->and($event->fresh()->attempts)->toBe(2);
});

it('settles cancellation automatic return once without changing the security deposit', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $deposit = phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance;
    $provider->shouldReceive('cancelCard')->once()->andReturnUsing(fn ($id, $request) => new ProviderOperationDTO($request, ProviderOperationStatus::Processing, $id));
    $cancel = $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'CANCEL');
    expect($cancel->status)->toBe('UNKNOWN');
    $provider->shouldReceive('queryCardFunds')->twice()->with($card->provider_card_id, 'TX-CANCEL-RETURN', 'CANCEL_RETURN')
        ->andReturn(new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $card->provider_card_id, 'TX-CANCEL-RETURN', 'TX-CANCEL-RETURN', '20.00000000', '19.00000000', '1.00000000'));
    $result = $action->settleCancellationReturn($this->tenant->id, $this->user->id, $card->id, 'TX-CANCEL-RETURN');
    expect($result->status)->toBe('SUCCEEDED');
    expect($action->settleCancellationReturn($this->tenant->id, $this->user->id, $card->id, 'TX-CANCEL-RETURN')->id)->toBe($result->id);
    expect(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->add(Money::of('19', 'USDT'))->amount())
        ->and(phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance)->toBe($deposit)
        ->and(LedgerEntry::query()->where('reference_id', $result->id)->count())->toBe(1);
    $history = app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1)['items'];
    expect($history)->toHaveCount(1)->and($history[0]['amount'])->toBe('-20.00000000')->and($history[0]['type'])->toBe('transfer_out');
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('blocks mismatched return evidence without crediting or releasing anything', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('returnCardFunds')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, 'FOREIGN-CARD', $request, 'TX-WRONG', '10.00000000', '9.00000000', '1.00000000'));
    $result = $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'RETURN', '10');
    expect($result->status)->toBe('UNKNOWN')->and($result->settlement_entry_id)->toBeNull()
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
    expect(app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1)['items'])->toBe([]);
});

it('expires unused quotations without calling recharge or creating holds', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $this->travel(31)->seconds();
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('EXPIRED')
        ->and(LedgerEntry::query()->where('reference_id', $order->id)->count())->toBe(0);
});

it('encrypts holder changes and recovers unconfirmed edits by readback not replay', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $original = $this->holder->materials_encrypted;
    $provider->shouldReceive('editCardholderFields')->once()->andThrow(new ProviderUnknownResultException('Unconfirmed'));
    $provider->shouldReceive('cardholderFieldsMatch')->once()->andReturn(true);
    $order = $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'HOLDER_UPDATE', null, ['email' => 'new-holder@example.test']);
    expect($order->status)->toBe('UNKNOWN')->and(json_encode($order))->not->toContain('new-holder@example.test', 'holder_changes_encrypted')
        ->and($order->holder_changes_encrypted)->not->toContain('new-holder@example.test');
    expect($action->sync($this->tenant->id, $order->id)->status)->toBe('SUCCEEDED')
        ->and($this->holder->fresh()->materials_encrypted)->toBe($original);
});

it('enforces card owner and money confirmation even when tenant host matches', function (): void {
    [$card,$provider] = managedCardFixture($this);
    $other = $this->user->replicate(['account_id']);
    $other->forceFill(['email' => 'management-other@example.test'])->save();
    $this->actingAs($other, 'tenant_user')->postJson('http://a.localhost/cards/'.$card->id.'/management', ['action' => 'refresh'])->assertNotFound();
    $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/cards/'.$card->id.'/management', ['action' => 'cancel', 'request_id' => (string) Str::uuid(), 'current_password' => 'local-password'])->assertUnprocessable();
    expect(CardManagementOrder::query()->count())->toBe(0);
});

it('rejects overwritten terminal management history in PostgreSQL', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $provider->shouldReceive('returnCardFunds')->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-SEALED', '10.00000000', '10.00000000', '0.00000000'));
    $order = $action->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'RETURN', '10');
    expect(fn () => DB::transaction(fn () => DB::table('card_management_orders')->where('tenant_id', $this->tenant->id)->where('id', $order->id)->update(['arrival_amount' => '99'])))->toThrow(QueryException::class);
});

it('lets a paid card operation settle after user suspension', function (): void {
    [$card,$provider,$action] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andThrow(new ProviderUnknownResultException('Unconfirmed'));
    $provider->shouldReceive('queryCardFunds')->once()->andReturnUsing(fn ($id, $request, $kind) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-SUSPENDED', '20.00000000', '20.00000000', '0.00000000'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    $this->user->forceFill(['status' => 'SUSPENDED'])->save();
    expect($action->sync($this->tenant->id, $order->id)->status)->toBe('SUCCEEDED');
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('rejects a late balance response after a newer refresh has completed', function (): void {
    $card = null;
    $calls = 0;
    [$card] = managedCardFixture($this, function () use (&$card, &$calls) {
        $calls++;
        if ($calls === 1) {
            app(RefreshManagedCardAction::class)->execute($this->tenant->id, $this->user->id, $card->id);
            $balance = '18.00000000';
        } else {
            $balance = '15.00000000';
        }

        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'normal', false, $balance);
    });
    expect(fn () => app(RefreshManagedCardAction::class)->execute($this->tenant->id, $this->user->id, $card->id))->toThrow(DomainException::class);
    expect($card->fresh()->provider_balance)->toBe('15.00000000')->and($card->fresh()->refresh_generation)->toBe(2);
});

it('rejects unconfigured refund timing and client attempts to set the deadline or manually settle', function (): void {
    phaseTenReadyUser($this);
    $this->tenant->businessSettings()->update(['security_deposit_refund_wait_days' => null]);
    expect(fn () => app(RefundSecurityDepositAction::class)->request($this->tenant->id, $this->user->id, (string) Str::uuid()))->toThrow(DomainException::class);
    expect(SecurityDepositRefundRequest::query()->count())->toBe(0);
    $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/security-deposit/refund', [
        'action' => 'check', 'refund_id' => (string) Str::uuid(), 'current_password' => 'password', 'confirmed' => true,
        'refund_wait_days' => 0, 'refund_eligible_at' => now()->toIso8601String(),
    ])->assertUnprocessable()->assertJsonValidationErrors(['action', 'refund_wait_days', 'refund_eligible_at']);
});

it('keeps refund snapshots immutable and prevents early completion', function (): void {
    phaseTenReadyUser($this);
    $this->tenant->businessSettings()->update(['security_deposit_refund_wait_days' => 2]);
    $refund = app(RefundSecurityDepositAction::class)->request($this->tenant->id, $this->user->id, (string) Str::uuid());
    foreach ([['refund_wait_days' => 0, 'refund_eligible_at' => $refund->created_at],
        ['status' => 'COMPLETED', 'progress' => 'completed', 'completed_at' => now()]] as $mutation) {
        expect(fn () => DB::transaction(fn () => DB::table('security_deposit_refund_requests')->where('id', $refund->id)->update($mutation)))->toThrow(QueryException::class);
    }
    $this->artisan('deposits:process-refunds', ['--tenant' => (string) Str::uuid()])->assertSuccessful();
    expect($refund->fresh()->progress)->toBe('freezing');
    $this->artisan('deposits:process-refunds', ['--tenant' => $this->tenant->id])->assertSuccessful();
    expect($refund->fresh()->status)->toBe('CHECKING')->and($refund->fresh()->progress)->toBe('waiting')
        ->and(phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance)->toBe('10.00000000');
});

it('retains refund principal until frozen or cancelled card status is authoritative', function (string $state, ?string $balance, bool $unknown): void {
    $card = null;
    $depth = DB::transactionLevel();
    [$card] = managedCardFixture($this, function () use (&$card, $state, $balance, $unknown, $depth) {
        expect(DB::transactionLevel())->toBe($depth);
        if ($unknown) {
            throw new ProviderUnknownResultException('Unconfirmed card lookup');
        }

        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', $state, false, $balance);
    });
    $action = app(RefundSecurityDepositAction::class);
    $refund = $action->request($this->tenant->id, $this->user->id, (string) Str::uuid());
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->status)->toBe('CHECKING')
        ->and(phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance)->toBe('10.00000000')
        ->and(LedgerEntry::query()->where('event_type', 'SECURITY_DEPOSIT_REFUND')->count())->toBe(0);
})->with([['normal', '0.00000000', false], ['cancelled', null, false], ['cancelled', '0.00000000', true]]);

it('snapshots company refund days freezes nonzero cards and blocks every action except transactions', function (): void {
    $state = 'normal';
    $card = null;
    [$card, $provider, $manage] = managedCardFixture($this, function () use (&$state, &$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', $state, false, '20.00000000');
    });
    $provider->shouldReceive('freezeCard')->once()->andReturnUsing(function () use (&$state) {
        $state = 'frozen';

        return new ProviderOperationDTO('freeze', ProviderOperationStatus::Succeeded);
    });
    $provider->shouldReceive('unfreezeCard')->once()->andReturnUsing(function () use (&$state) {
        $state = 'normal';

        return new ProviderOperationDTO('unfreeze', ProviderOperationStatus::Succeeded);
    });
    $this->tenant->businessSettings()->update(['security_deposit_refund_wait_days' => 1]);
    $refunds = app(RefundSecurityDepositAction::class);
    $requestId = (string) Str::uuid();
    $refund = $refunds->request($this->tenant->id, $this->user->id, $requestId);
    $this->tenant->businessSettings()->update(['security_deposit_refund_wait_days' => 7]);
    expect($refunds->request($this->tenant->id, $this->user->id, $requestId)->id)->toBe($refund->id);
    $refunds->settle($this->tenant->id, $this->user->id, $refund->id);
    expect([$state, $card->fresh()->provider_status, CardManagementOrder::query()->where('card_id', $card->id)->get(['kind', 'status'])->toArray()])->toBe(['frozen', 'frozen', [['kind' => 'FREEZE', 'status' => 'SUCCEEDED']]]);
    expect($refund->fresh()->progress)->toBe('waiting')->and($refund->fresh()->refund_wait_days)->toBe(1)
        ->and($card->fresh()->provider_status)->toBe('frozen')
        ->and(phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance)->toBe('10.00000000');
    $view = app(UserCardCenterQuery::class)->get($this->tenant->id, $this->user->id);
    expect($view['refundPending'])->toBeTrue()->and($view['cards'][0]['refundLocked'])->toBeTrue();
    foreach (['reveal', 'holder_details', 'history', 'refresh', 'sync', 'quote', 'confirm', 'holder', 'return', 'freeze', 'unfreeze', 'cancel'] as $action) {
        expect(fn () => app(UserCardManagementAction::class)->execute($this->tenant->id, $this->user->id, $card->id,
            CardManagementInput::fromValidated(['action' => $action])))->toThrow(DomainException::class);
    }
    expect(fn () => $manage->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'UNFREEZE'))->toThrow(DomainException::class);
    $refunds->cancel($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->status)->toBe('CHECKING');
    $refunds->settle($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->status)->toBe('CANCELLED')->and($state)->toBe('normal')
        ->and(LedgerEntry::query()->where('event_type', 'SECURITY_DEPOSIT_REFUND')->count())->toBe(0);
});

it('refunds automatically after the deadline without requiring a zero card balance and does not replay', function (): void {
    $state = 'normal';
    $card = null;
    [$card, $provider] = managedCardFixture($this, function () use (&$state, &$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', $state, false, '20.00000000');
    });
    $provider->shouldReceive('freezeCard')->once()->andReturnUsing(function () use (&$state) {
        $state = 'frozen';

        return new ProviderOperationDTO('freeze', ProviderOperationStatus::Succeeded);
    });
    $action = app(RefundSecurityDepositAction::class);
    $refund = $action->request($this->tenant->id, $this->user->id, (string) Str::uuid());
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->status)->toBe('COMPLETED')->and($card->fresh()->provider_balance)->toBe('20.00000000')
        ->and(phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance)->toBe('0.00000000')
        ->and(LedgerEntry::query()->where('event_type', 'SECURITY_DEPOSIT_REFUND')->count())->toBe(1);
    expect(RefundCardPolicy::blocked($this->tenant->id, $this->user->id, $card->id))->toBeTrue();
});

it('does not refund on a freeze timeout or replay it with another request and safely restores after cancellation', function (): void {
    $state = 'normal';
    $card = null;
    [$card, $provider] = managedCardFixture($this, function () use (&$state, &$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', $state, false, '20.00000000');
    });
    $provider->shouldReceive('freezeCard')->once()->andThrow(new ProviderUnknownResultException('Timeout'));
    $provider->shouldReceive('unfreezeCard')->once()->andReturnUsing(function () use (&$state) {
        $state = 'normal';

        return new ProviderOperationDTO('unfreeze', ProviderOperationStatus::Succeeded);
    });
    $action = app(RefundSecurityDepositAction::class);
    $refund = $action->request($this->tenant->id, $this->user->id, (string) Str::uuid());
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->progress)->toBe('blocked');
    $action->cancel($this->tenant->id, $this->user->id, $refund->id);
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->status)->toBe('CHECKING')
        ->and(fn () => $action->request($this->tenant->id, $this->user->id, (string) Str::uuid()))->toThrow(DomainException::class);
    $state = 'frozen';
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    expect([$state, CardManagementOrder::query()->where('card_id', $card->id)->get(['kind', 'status'])->toArray()])->toBe(['normal', [['kind' => 'FREEZE', 'status' => 'SUCCEEDED'], ['kind' => 'UNFREEZE', 'status' => 'SUCCEEDED']]]);
    expect($refund->fresh()->status)->toBe('CANCELLED')->and($state)->toBe('normal')
        ->and(LedgerEntry::query()->where('event_type', 'SECURITY_DEPOSIT_REFUND')->count())->toBe(0);
});

it('leaves originally frozen cards frozen on cancellation and never assigns a deadline to legacy requests', function (): void {
    $card = null;
    [$card, $provider] = managedCardFixture($this, function () use (&$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'frozen', false, '20.00000000');
    });
    $provider->shouldNotReceive('freezeCard');
    $provider->shouldNotReceive('unfreezeCard');
    $this->tenant->businessSettings()->update(['security_deposit_refund_wait_days' => 3]);
    $action = app(RefundSecurityDepositAction::class);
    $refund = $action->request($this->tenant->id, $this->user->id, (string) Str::uuid());
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    $action->cancel($this->tenant->id, $this->user->id, $refund->id);
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->status)->toBe('CANCELLED')->and($card->fresh()->provider_status)->toBe('frozen');
    $legacy = SecurityDepositRefundRequest::query()->create([
        'tenant_id' => $this->tenant->id, 'user_id' => $this->user->id, 'wallet_id' => Wallet::query()->where('tenant_id', $this->tenant->id)->where('user_id', $this->user->id)->value('id'),
        'request_id' => (string) Str::uuid(), 'amount' => '10', 'asset_code' => 'USDT', 'status' => 'CHECKING',
    ]);
    $action->settle($this->tenant->id, $this->user->id, $legacy->id);
    expect($legacy->fresh()->status)->toBe('CHECKING')->and($legacy->fresh()->refund_eligible_at)->toBeNull();
    $action->cancel($this->tenant->id, $this->user->id, $legacy->id);
    expect($legacy->fresh()->status)->toBe('CANCELLED');
});

it('refunds a guarantee once after confirmed cancelled-card status without re-awarding commission', function (): void {
    [$card] = managedCardFixture($this);
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('getCard')->once()->andReturn(new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'cancelled', false, '0.00000000'));
    app()->instance(CardProviderInterface::class, $provider);
    $action = app(RefundSecurityDepositAction::class);
    $refund = $action->request($this->tenant->id, $this->user->id, (string) Str::uuid());
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    $action->settle($this->tenant->id, $this->user->id, $refund->id);
    expect($refund->fresh()->status)->toBe('COMPLETED')
        ->and(phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance)->toBe('0.00000000')
        ->and(LedgerEntry::query()->where('event_type', 'SECURITY_DEPOSIT_REFUND')->count())->toBe(1);
});

beforeEach(function (): void {
    $this->seed();
    Storage::fake('private');
    Queue::fake();
    $this->tenant = Tenant::query()->where('slug', 'tenant-a')->firstOrFail();
    $this->tenant->businessSettings()->update(['security_deposit_refund_wait_days' => 0]);
    $this->user = User::query()->where('tenant_id', $this->tenant->id)->firstOrFail();
    $this->owner = AdminUser::query()->where('email', 'owner@a.localhost')->firstOrFail();
    $this->product = CardProduct::query()->where('provider', 'PHOTONPAY')->firstOrFail();
    phaseTenProvider($this, MockProviderMode::Success, 'READY');
});

it('blocks unconfigured product setup and issue before uploads provider calls or holds', function (): void {
    phaseTenReadyUser($this);
    $owner = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $product = legacyCardProductFixture([
        'name' => 'No API', 'minimum_initial_load' => '20', 'opening_fee' => '5.00000000', 'minimum_reload' => '20', 'status' => 'ACTIVE',
    ]);
    $config = TenantCardProductConfig::query()->where('tenant_id', $this->tenant->id)->where('card_product_id', $this->product->id)->sole()->replicate();
    $config->card_product_id = $product->id;
    $config->save();
    $this->product = $product;
    $entries = LedgerEntry::query()->count();
    $holders = ProviderCardholder::query()->count();
    $files = count(Storage::disk('private')->allFiles());
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldNotReceive('createCardholder');
    $provider->shouldNotReceive('issueCard');
    app()->instance(CardProviderInterface::class, $provider);
    expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this)))
        ->toThrow(DomainException::class, 'currently unavailable');
    expect(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'currently unavailable');
    $catalog = app(CardProductCatalogQuery::class)->user($this->tenant->id, $this->user->id);
    $row = collect($catalog['products'])->firstWhere('id', $product->id);
    expect($row['readyForSetup'])->toBeFalse()->and($row['guidance'])->toBe('Card setup is currently unavailable.')
        ->and(LedgerEntry::query()->count())->toBe($entries)->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(ProviderCardholder::query()->count())->toBe($holders)->and(count(Storage::disk('private')->allFiles()))->toBe($files);
});

it('preserves historical product routing while allowing non-routing configuration edits', function (): void {
    phaseTenReadyUser($this);
    $owner = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $data = ['name' => 'Updated name', 'provider_product_ref' => $this->product->provider_product_ref,
        'minimum_initial_load' => '20', 'opening_fee' => '5.00000000', 'minimum_reload' => '20', 'status' => 'ACTIVE'];
    $action = app(UpdateCardProductAction::class);
    $action->execute($this->product->id, $data, $owner);
    expect(fn () => $action->execute($this->product->id, [...$data, 'provider_product_ref' => '123456'], $owner))
        ->toThrow(DomainException::class, 'card history');
    expect(fn () => DB::transaction(fn () => $this->product->forceFill(['provider' => 'UNCONFIGURED'])->save()))->toThrow(QueryException::class);
    expect($this->product->fresh()->provider)->toBe('PHOTONPAY')->and($this->product->fresh()->name)->toBe('Updated name');
    $this->product->refresh();
    expect(phaseTenIssue($this)->status)->toBe(CardIssueStatus::Succeeded);
});

function phaseTenProvider($test, MockProviderMode $mode, string $cardholderMode = 'READY'): void
{
    app()->instance(CardProviderInterface::class, new MockCardProvider($mode, $cardholderMode));
}

function localSimulationReadyCard($test, bool $merchant = false): UserCard
{
    phaseTenReadyUser($test, '200.00000000');
    // Preserve the historical fixture as-is; the local simulator creates independent new identities.
    phaseTenIssue($test);
    config(['card-provider.driver' => 'mock', 'card-provider.mock_mode' => 'SUCCESS', 'card-provider.mock_cardholder_mode' => 'READY']);
    app()->detectEnvironment(fn () => 'local');
    app()->forgetInstance(CardProviderInterface::class);
    Http::preventStrayRequests();
    if ($merchant) {
        $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
        $reference = app(SaveCardProviderReferenceAction::class)->execute(null,
            ['request_id' => (string) Str::uuid(), 'name' => 'test', 'reference_balance' => '0'], $platform);
        expect($reference->runtime_driver)->toBe('LOCAL_MOCK');
        $product = legacyCardProductFixture([
            'name' => 'Test merchant product', 'card_provider_reference_id' => $reference->id, 'provider_product_ref' => '123456',
            'minimum_initial_load' => '20', 'opening_fee' => '5.00000000', 'minimum_reload' => '20', 'status' => 'ACTIVE',
        ]);
        $config = TenantCardProductConfig::query()->where('tenant_id', $test->tenant->id)->where('card_product_id', $test->product->id)->sole()->replicate();
        $config->card_product_id = $product->id;
        $config->save();
        $test->product = $product;
        $catalog = app(CardProductCatalogQuery::class)->user($test->tenant->id, $test->user->id);
        expect(collect($catalog['products'])->firstWhere('id', $product->id)['readyForSetup'])->toBeTrue();
    }
    $test->holder = app(SubmitProviderCardholderAction::class)->execute($test->tenant->id, $test->user->id, independentCardMaterials($test));
    expect($test->holder->provider_cardholder_id)->toStartWith('MOCK-LOCAL-HOLDER-');
    $issue = phaseTenIssue($test);
    expect($issue->status)->toBe(CardIssueStatus::Succeeded);
    if ($merchant) {
        expect($issue->provider_product_ref)->toBe('MOCK-LOCAL-PRODUCT-'.$test->product->id)
            ->and($reference->fresh()->reference_balance)->toBe('0.00000000');
    }

    return UserCard::query()->where('tenant_id', $test->tenant->id)->where('card_issue_order_id', $issue->id)->firstOrFail();
}

it('archives only confirmed cleared cards after their cancellation return settles', function (): void {
    try {
        $card = localSimulationReadyCard($this, true);
        $request = (string) Str::uuid();
        app(AuditLogger::class)->record($this->tenant->id, 'USER', $this->user->id,
            'CARD_CLEANUP_REQUESTED', 'user_card', $card->id, null, ['balance_before_cancellation' => '20.00000000'], $request);
        $archive = app(ArchiveClearedUserCardAction::class);
        expect(fn () => $archive->execute($this->tenant->id, $this->user->id, $card->id, $request))->toThrow(DomainException::class);
        $manage = app(ManageCardAction::class);
        expect($manage->operate($this->tenant->id, $this->user->id, $card->id, $request, 'CANCEL')->status)->toBe('SUCCEEDED');
        expect(fn () => $archive->execute($this->tenant->id, $this->user->id, $card->id, $request))->toThrow(DomainException::class);
        $tx = app(CardProviderInterface::class)->getTransactionPage($card->provider_card_id, 1, 20)->items[0]->providerTransactionId;
        $manage->settleCancellationReturn($this->tenant->id, $this->user->id, $card->id, $tx);
        $before = [UserCard::query()->count(), CardIssueOrder::query()->count(), LedgerEntry::query()->count(), phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance];
        expect(fn () => $archive->execute($this->tenant->id, (string) Str::uuid(), $card->id, $request))->toThrow(ModelNotFoundException::class);
        $archive->execute($this->tenant->id, $this->user->id, $card->id, $request);
        $archive->execute($this->tenant->id, $this->user->id, $card->id, $request);
        expect($card->fresh()->archived_at)->not->toBeNull()
            ->and([UserCard::query()->count(), CardIssueOrder::query()->count(), LedgerEntry::query()->count(), phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance])->toBe($before)
            ->and(collect(app(UserCardCenterQuery::class)->get($this->tenant->id, $this->user->id)['cards'])->pluck('id')->all())->not->toContain($card->id)
            ->and(DB::table('audit_logs')->where('action', 'USER_CARD_ARCHIVED')->where('resource_id', $card->id)->count())->toBe(1);
    } finally {
        app()->detectEnvironment(fn () => 'testing');
        app()->forgetInstance(CardProviderInterface::class);
    }
});

it('freezes supported cards even when a historical card blocks refund and keeps transaction reads available', function (): void {
    try {
        $card = localSimulationReadyCard($this, true);
        $this->tenant->businessSettings()->update(['security_deposit_refund_wait_days' => 1]);
        $refunds = app(RefundSecurityDepositAction::class);
        $refund = $refunds->request($this->tenant->id, $this->user->id, (string) Str::uuid());
        $refunds->settle($this->tenant->id, $this->user->id, $refund->id);
        expect($refund->fresh()->progress)->toBe('blocked')->and($card->fresh()->provider_status)->toBe('frozen');
        $view = app(UserCardCenterQuery::class)->get($this->tenant->id, $this->user->id);
        expect(collect($view['cards'])->firstWhere('id', $card->id)['management'])->toBe(['transactions']);
        expect(app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1))
            ->toBe(['page' => 1, 'hasMore' => false, 'items' => []]);
        expect(LedgerEntry::query()->where('event_type', 'SECURITY_DEPOSIT_REFUND')->count())->toBe(0);
        $refunds->cancel($this->tenant->id, $this->user->id, $refund->id);
        $refunds->settle($this->tenant->id, $this->user->id, $refund->id);
        expect($refund->fresh()->status)->toBe('CANCELLED')->and($card->fresh()->provider_status)->toBe('normal');
    } finally {
        app()->detectEnvironment(fn () => 'testing');
    }
});

it('runs the local simulator through card management ledger reveal and authenticated notification flows', function (bool $merchant): void {
    try {
        $card = localSimulationReadyCard($this, $merchant);
        $provider = app(CardProviderInterface::class);
        $manage = app(ManageCardAction::class);
        $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
        $quote = $manage->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20.01');
        expect($quote->status)->toBe('QUOTED');
        $loaded = $manage->confirmLoad($this->tenant->id, $this->user->id, $card->id, $quote->id);
        expect($loaded->status)->toBe('SUCCEEDED');
        $manage->confirmLoad($this->tenant->id, $this->user->id, $card->id, $quote->id);
        $returned = $manage->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'RETURN', '5.01');
        expect($returned->status)->toBe('SUCCEEDED');
        foreach (['FREEZE' => 'frozen', 'UNFREEZE' => 'normal'] as $kind => $status) {
            expect($manage->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), $kind)->status)->toBe('SUCCEEDED');
            expect($card->fresh()->provider_status)->toBe($status);
        }
        expect($manage->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'HOLDER_UPDATE', holderFields: ['email' => 'mock-change@example.test'])->status)->toBe('SUCCEEDED');
        $this->actingAs($this->user, 'tenant_user')->withSession(['_token' => 'local-test-csrf'])->postJson('http://a.localhost/cards/'.$card->id.'/management', [
            'action' => 'reveal', 'current_password' => 'local-password', '_token' => 'local-test-csrf',
        ])->assertStatus(503)->assertJsonMissingPath('pan')->assertJsonMissingPath('cvv'); // The simulator deliberately returns a non-PAN placeholder.
        $tx = $provider->simulatePurchase($card->provider_card_id, 'local-purchase', '3.25');
        $walletBeforeNotification = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
        $event = storedCardNotificationFixture($card, 'card_id', $tx);
        for ($i = 0; $i < 2; $i++) {
            app(ProcessCardNotificationAction::class)->execute($event->tenant_id, $event->id);
        }
        expect($event->fresh()->status)->toBe('PROCESSED')
            ->and($card->fresh()->provider_balance)->toBe('31.75000000')
            ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($walletBeforeNotification)
            ->and(CardTransaction::query()->where('card_id', $card->id)->count())->toBe(1);
        app(SyncUserCardTransactionsAction::class)->execute($this->tenant->id, $this->user->id, $card->id, 1);
        expect(app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1)['items'])->toHaveCount(3);
        expect(fn () => app(UserCardTransactionsQuery::class)->get($this->otherTenantId ?? (string) Str::uuid(), $this->user->id, $card->id, 1))->toThrow(ModelNotFoundException::class);
        expect($manage->operate($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), 'CANCEL')->status)->toBe('SUCCEEDED');
        $returnTx = $provider->getTransactionPage($card->provider_card_id, 1, 20)->items[0]->providerTransactionId;
        $cancelReturn = $manage->settleCancellationReturn($this->tenant->id, $this->user->id, $card->id, $returnTx);
        $manage->settleCancellationReturn($this->tenant->id, $this->user->id, $card->id, $returnTx);
        expect($cancelReturn->status)->toBe('SUCCEEDED')->and($card->fresh()->provider_status)->toBe('cancelled')
            ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->add(Money::of('16.75', 'USDT'))->amount());
        Http::assertNothingSent();
    } finally {
        app()->detectEnvironment(fn () => 'testing');
        app()->forgetInstance(CardProviderInterface::class);
    }
})->with([false, true]);

it('retains or releases local mock recharge holds only after stable provider evidence', function (string $mode): void {
    try {
        $card = localSimulationReadyCard($this);
        $manage = app(ManageCardAction::class);
        $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
        $quote = $manage->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
        config(['card-provider.mock_mode' => $mode]);
        $order = $manage->confirmLoad($this->tenant->id, $this->user->id, $card->id, $quote->id);
        expect($order->status)->toBeIn(['UNKNOWN', 'PROCESSING']);
        expect(phaseTenAccount($this, LedgerAccountType::UserCardFundingHold)->balance)->toBe('20.00000000');
        config(['card-provider.mock_mode' => 'SUCCESS']);
        $result = $manage->sync($this->tenant->id, $order->id);
        $failed = $mode === 'DELAYED_FAILURE';
        expect($result->status)->toBe($failed ? 'FAILED' : 'SUCCEEDED')
            ->and(phaseTenAccount($this, LedgerAccountType::UserCardFundingHold)->balance)->toBe('0.00000000')
            ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($failed ? $before : Money::of($before, 'USDT')->subtract(Money::of('20', 'USDT'))->amount());
        $entries = LedgerEntry::query()->count();
        $manage->sync($this->tenant->id, $order->id);
        expect(LedgerEntry::query()->count())->toBe($entries);
        Http::assertNothingSent();
    } finally {
        app()->detectEnvironment(fn () => 'testing');
        app()->forgetInstance(CardProviderInterface::class);
    }
})->with(['UNKNOWN', 'TIMEOUT', 'DELAYED_SUCCESS', 'DELAYED_FAILURE']);

it('simulates duplicate consumption notifications through the isolated local CLI only', function (): void {
    try {
        $card = localSimulationReadyCard($this);
        $request = (string) Str::uuid();
        $args = ['card' => $card->id, 'amount' => '1.25', 'request' => $request];
        $this->artisan('cards:mock-purchase', $args)->assertSuccessful();
        $this->artisan('cards:mock-purchase', $args)->assertSuccessful();
        $event = CardProviderEvent::query()->where('card_id', $card->id)->sole();
        app(ProcessCardNotificationAction::class)->execute($event->tenant_id, $event->id);
        expect($event->fresh()->status)->toBe('PROCESSED')->and($card->fresh()->provider_balance)->toBe('18.75000000');
        app()->detectEnvironment(fn () => 'production');
        $this->artisan('cards:mock-purchase', $args)->assertFailed();
        expect(CardProviderEvent::query()->where('card_id', $card->id)->count())->toBe(1);
        Http::assertNothingSent();
    } finally {
        app()->detectEnvironment(fn () => 'testing');
        app()->forgetInstance(CardProviderInterface::class);
    }
});

/** @return array{wallet:Wallet,cardholder:ProviderCardholder} */
function phaseTenReadyUser($test, string $available = '100.00000000', ProviderCardholderStatus $holderStatus = ProviderCardholderStatus::Ready): array
{
    DB::transaction(function () use ($test): void {
        DB::table('tenants')->where('id', $test->tenant->id)->update(['default_asset' => 'USDT']);
        $test->tenant->refresh();
        app(UpdateTenantBusinessSettingsAction::class)->execute($test->tenant, [
            'required_security_deposit_amount' => '10',
            'required_security_deposit_asset' => 'USDT',
            'allow_wallet_topup' => true,
            'allow_withdrawal' => true,
        ], AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail());
    });
    $test->tenant->refresh();
    $ocr = Mockery::mock(KycOcrProviderInterface::class);
    $ocr->shouldReceive('name')->andReturn('TEST');
    $ocr->shouldReceive('extractIdentityDocument')->andReturn(new KycOcrResultDTO(
        KycOcrOutcome::Success, 'PHASE-TEN-'.$test->user->id,
    ));
    app()->instance(KycOcrProviderInterface::class, $ocr);
    $application = app(SubmitKycApplicationAction::class)->execute(
        $test->tenant,
        $test->user,
        'CN',
        'PHASE-TEN-'.$test->user->id,
        kycTestImage('phase-ten-front.png'),
        kycTestImage('phase-ten-back.png'),
    );
    app(ApproveKycAction::class)->execute($test->tenant->id, $application->id, $test->owner, identityNumber: '11010519491231002X');
    $wallet = app(ActivateUserWalletAction::class)->execute($test->tenant->id, $test->user->id)->wallet;
    $accounts = LedgerAccount::query()->where('tenant_id', $test->tenant->id)->where('wallet_id', $wallet->id)->get()
        ->keyBy(fn (LedgerAccount $account): string => $account->account_type->value);
    $clearing = LedgerAccount::query()->where('tenant_id', $test->tenant->id)->whereNull('wallet_id')
        ->where('account_type', LedgerAccountType::TenantTopupClearing->value)->firstOrFail();
    $total = Money::of($available, 'USDT')->add(Money::of('10', 'USDT'));
    app(LedgerWriter::class)->post(new LedgerPostingPlan(
        $test->tenant->id,
        'USDT',
        'phase-ten:test-credit:'.$test->user->id,
        'TEST_WALLET_CREDIT',
        null,
        null,
        null,
        [
            new LedgerPostingInstruction($clearing->id, Money::of('-'.$total->amount(), 'USDT')),
            new LedgerPostingInstruction($accounts[LedgerAccountType::UserAvailable->value]->id, $total),
        ],
    ));
    app(FundSecurityDepositAction::class)->execute($test->tenant->id, $test->user->id, (string) Str::uuid(), '10.00000000');
    $holder = phaseTenHolder($test, $holderStatus);

    return ['wallet' => $wallet, 'cardholder' => $holder];
}

function phaseTenHolder($test, ProviderCardholderStatus $holderStatus = ProviderCardholderStatus::Ready): ProviderCardholder
{
    $holder = new ProviderCardholder;
    $holder->forceFill([
        'tenant_id' => $test->tenant->id,
        'user_id' => $test->user->id,
        'provider' => 'PHOTONPAY',
        'provider_cardholder_id' => 'MOCK-HOLDER-'.Str::uuid(),
        'request_id' => (string) Str::uuid(), 'request_hash' => str_repeat('a', 64),
        'card_product_id' => $test->product->id, 'submission_version' => 1,
        'materials_encrypted' => app(CardholderMaterials::class)->encrypt(json_encode($test->holderMaterials ?? ['test' => 'independent-card-materials'], JSON_THROW_ON_ERROR)),
        'status' => $holderStatus,
        'provider_status' => strtolower($holderStatus->value),
        'provider_review_status' => strtolower($holderStatus->value),
        'submitted_at' => now(),
        'synced_at' => now(),
    ])->save();

    $test->holder = $holder;

    return $holder;
}

function phaseTenIssue($test, string $amount = '20.00', ?string $requestId = null): CardIssueOrder
{
    return app(CreateCardIssueAction::class)->execute(
        $test->tenant->id,
        $test->user->id,
        $requestId ?? (string) Str::uuid(),
        $test->product->id,
        $amount,
        $test->holder->id,
    );
}

function phaseTenAccount($test, LedgerAccountType $type): LedgerAccount
{
    return LedgerAccount::query()->where('tenant_id', $test->tenant->id)->where('user_id', $test->user->id)
        ->where('account_type', $type->value)->firstOrFail();
}

it('blocks live use of mock materials and demo products before holds or uploads', function (bool $liveProduct): void {
    if ($liveProduct) {
        $this->product->forceFill(['provider_product_ref' => 'OPAQUE-LIVE-PRODUCT'])->save();
    }
    phaseTenReadyUser($this);
    $entryCount = LedgerEntry::query()->count();
    $holderCount = ProviderCardholder::query()->count();
    $fileCount = count(Storage::disk('private')->allFiles());
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldNotReceive('createCardholder');
    $provider->shouldNotReceive('issueCard');
    $provider->shouldNotReceive('getCardholder');
    app()->instance(CardProviderInterface::class, $provider);
    $this->app->detectEnvironment(fn (): string => 'local');
    try {
        expect(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'test card setup');
        if (! $liveProduct) {
            expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this)))
                ->toThrow(DomainException::class, 'test card setup');
        }
        expect(fn () => app(SyncProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $this->holder->id))
            ->toThrow(DomainException::class, 'test card setup');
        // Even a genuinely configured product cannot authorize an old Mock holder.
        expect(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'test card setup');
        expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id,
            array_replace(independentCardMaterials($this), ['request_id' => $this->holder->request_id])))
            ->toThrow(DomainException::class, 'test card setup');
        expect(app(UserCardCenterQuery::class)->get($this->tenant->id, $this->user->id)['cardholder']['state'])->toBe('setup');
        expect(CardIssueOrder::query()->count())->toBe(0)
            ->and(LedgerEntry::query()->count())->toBe($entryCount)
            ->and(ProviderCardholder::query()->count())->toBe($holderCount)
            ->and(count(Storage::disk('private')->allFiles()))->toBe($fileCount);
    } finally {
        $this->app->detectEnvironment(fn (): string => 'testing');
    }
})->with([false, true]);

it('uses each PhotonPay add response identity for exactly its corresponding live issue', function (): void {
    $this->product->forceFill(['provider_product_ref' => 'OPAQUE-LIVE-PRODUCT'])->save();
    phaseTenReadyUser($this);
    $historicHolderId = $this->holder->id;
    $key = openssl_pkey_new(['private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA]);
    openssl_pkey_export($key, $privateKey);
    config()->set('card-provider.driver', 'photonpay');
    config()->set('card-provider.photonpay', [
        'base_url' => 'https://x-api.photonpay.com', 'app_id' => 'offline-app', 'app_secret' => 'offline-secret',
        'private_key' => $privateKey, 'account_id_usd' => 'FA-OFFLINE', 'member_id' => null, 'matrix_account' => null, 'timeout_seconds' => 10,
    ]);
    app()->forgetInstance(CardProviderInterface::class);
    $calls = [];
    $additions = 0;
    $testTransactionLevel = DB::transactionLevel();
    Http::preventStrayRequests();
    Http::fake(function ($request) use (&$calls, &$additions, $testTransactionLevel) {
        // RefreshDatabase owns an outer test transaction; no business transaction may remain open.
        expect(DB::transactionLevel())->toBe($testTransactionLevel);
        expect(parse_url($request->url(), PHP_URL_HOST))->toBe('x-api.photonpay.com');
        $endpoint = basename(parse_url($request->url(), PHP_URL_PATH));
        $payload = $request->data();
        $data = match ($endpoint) {
            'issuing_cardholder_identity_certificate' => 'FILE-OFFLINE',
            'addCardholder' => ['cardholderId' => 'CH-RETURNED-'.(++$additions)],
            'getCardBin' => [['cardBin' => 'OPAQUE-LIVE-PRODUCT', 'cardCurrency' => 'USD', 'cardType' => 'recharge', 'cardFormFactor' => 'virtual_card']],
            'openCard' => ['requestId' => $payload['requestId'], 'status' => 'succeed', 'cardDetail' => [
                'cardId' => 'XR-RETURNED-'.$additions, 'maskCardNo' => '**** 4321', 'cardCurrency' => 'USD',
                'cardType' => 'recharge', 'cardFormFactor' => 'virtual_card', 'cardBalance' => '20.00',
            ]],
            default => throw new RuntimeException('Unexpected offline Provider request.'),
        };
        if (in_array($endpoint, ['addCardholder', 'openCard'], true)) {
            $calls[] = [$endpoint, $endpoint === 'addCardholder' ? $data['cardholderId'] : $payload['cardholderId']];
        }

        return Http::response(['code' => '0000', 'data' => $data]);
    });
    $this->app->detectEnvironment(fn (): string => 'local');
    try {
        foreach (['Alice', 'Bob'] as $index => $person) {
            $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this, $person));
            expect($holder->status)->toBe(ProviderCardholderStatus::Ready)
                ->and($holder->provider_cardholder_id)->toBe('CH-RETURNED-'.($index + 1));
            $this->holder = $holder;
            expect(phaseTenIssue($this)->status)->toBe(CardIssueStatus::Succeeded);
        }
        expect($calls)->toBe([
            ['addCardholder', 'CH-RETURNED-1'], ['openCard', 'CH-RETURNED-1'],
            ['addCardholder', 'CH-RETURNED-2'], ['openCard', 'CH-RETURNED-2'],
        ])->and(ProviderCardholder::query()->findOrFail($historicHolderId)->provider_cardholder_id)->toStartWith('MOCK-')
            ->and(UserCard::query()->count())->toBe(2);
    } finally {
        $this->app->detectEnvironment(fn (): string => 'testing');
    }
});

it('keeps null identity unknown applications blocking new live submissions', function (): void {
    $this->product->forceFill(['provider_product_ref' => 'OPAQUE-LIVE-PRODUCT'])->save();
    phaseTenReadyUser($this);
    phaseTenProvider($this, MockProviderMode::Success, 'UNKNOWN');
    // Finish preparing a genuine uncertain addition without deleting the historical Mock row.
    $this->app->detectEnvironment(fn (): string => 'local');
    try {
        $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this));
        expect($holder->provider_cardholder_id)->toBeNull()
            ->and($holder->status)->toBe(ProviderCardholderStatus::Unknown)
            ->and(app(UserCardCenterQuery::class)->get($this->tenant->id, $this->user->id)['cardholder']['state'])->toBe('unknown');
        expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this, 'Bob')))
            ->toThrow(DomainException::class, 'Complete the current card application');
        expect(CardIssueOrder::query()->count())->toBe(0);
    } finally {
        $this->app->detectEnvironment(fn (): string => 'testing');
    }
});

it('does not query or release unresolved mock issue holds after a live switch', function (): void {
    phaseTenReadyUser($this);
    phaseTenProvider($this, MockProviderMode::Unknown);
    $order = phaseTenIssue($this);
    $entryCount = LedgerEntry::query()->count();
    $balance = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldNotReceive('queryOperation');
    $provider->shouldNotReceive('issueCard');
    app()->instance(CardProviderInterface::class, $provider);
    $this->app->detectEnvironment(fn (): string => 'local');
    try {
        expect(fn () => app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id))
            ->toThrow(DomainException::class, 'test card setup');
        expect(phaseTenIssue($this, requestId: $order->request_id)->id)->toBe($order->id)
            ->and($order->fresh()->status)->toBe(CardIssueStatus::Unknown)
            ->and(LedgerEntry::query()->count())->toBe($entryCount)
            ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($balance)
            ->and(UserCard::query()->count())->toBe(0);
    } finally {
        $this->app->detectEnvironment(fn (): string => 'testing');
    }
});

it('requires approved KYC and validates all card setup fields before creating a Provider Cardholder', function (): void {
    expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, []))
        ->toThrow(DomainException::class, 'Approved identity verification');

    $this->actingAs($this->user, 'tenant_user')->post('http://a.localhost/cards/cardholder', [
        'legal_first_name' => '', 'tenant_id' => $this->tenant->id, 'identity_number' => 'must-not-be-accepted',
    ])->assertSessionHasErrors(['legal_first_name', 'legal_last_name', 'date_of_birth', 'tenant_id', 'front', 'back', 'request_id']);
    expect(ProviderCardholder::query()->count())->toBe(0);
});

it('submits independently uploaded cardholder materials without changing account identity', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $data = [
        'request_id' => (string) Str::uuid(), 'card_product_id' => $this->product->id,
        'email' => 'different-person@example.test', 'document_type' => 'id_card', 'document_country' => 'MY', 'identity_number' => 'DIFFERENT-HOLDER-001',
        'front' => kycTestImage(), 'back' => kycTestImage(),
        'legal_first_name' => 'Demo', 'legal_last_name' => 'User', 'date_of_birth' => '1990-01-02',
        'nationality_country_code' => 'MY', 'residential_address' => '1 Demo Street', 'residential_city' => 'Kuala Lumpur',
        'residential_state' => 'Kuala Lumpur', 'residential_country_code' => 'MY', 'residential_postal_code' => '50000',
    ];
    $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    $application = KycApplication::query()->where('tenant_id', $this->tenant->id)->firstOrFail();

    expect($holder->status)->toBe(ProviderCardholderStatus::Ready)
        ->and($holder->provider_cardholder_id)->toStartWith('MOCK-HOLDER-')
        ->and(Storage::disk('private')->exists($application->front_object_key))->toBeTrue()
        ->and(Storage::disk('public')->exists($application->front_object_key))->toBeFalse()
        ->and(DB::getSchemaBuilder()->hasColumns('provider_cardholders', ['identity_number', 'front_object_key', 'back_object_key']))->toBeFalse()
        ->and(app(CardholderMaterials::class)->decrypt($holder->materials_encrypted))->toContain('DIFFERENT-HOLDER-001')
        ->and($holder->toJson())->not->toContain('DIFFERENT-HOLDER-001', 'materials_encrypted', 'request_hash')
        ->and(AuditLog::query()->where('action', 'PHOTONPAY_CARDHOLDER_SUBMITTED')->count())->toBe(1);
});

it('does not issue for pending or rejected Cardholders and issues only when ready', function (ProviderCardholderStatus $status): void {
    phaseTenReadyUser($this, holderStatus: $status);
    if ($status === ProviderCardholderStatus::Ready) {
        expect(phaseTenIssue($this)->status)->toBe(CardIssueStatus::Succeeded);
    } else {
        expect(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'The cardholder must be added successfully');
        expect(CardIssueOrder::query()->count())->toBe(0);
    }
})->with([ProviderCardholderStatus::Pending, ProviderCardholderStatus::Rejected, ProviderCardholderStatus::Ready]);

it('does not blindly recreate an unknown Cardholder and keeps linkage tenant scoped', function (): void {
    phaseTenProvider($this, MockProviderMode::Success, 'TIMEOUT');
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $data = [
        'request_id' => (string) Str::uuid(), 'card_product_id' => $this->product->id,
        'email' => 'different-person@example.test', 'document_type' => 'id_card', 'document_country' => 'MY', 'identity_number' => 'DIFFERENT-HOLDER-002',
        'front' => kycTestImage(), 'back' => kycTestImage(),
        'legal_first_name' => 'Demo', 'legal_last_name' => 'User', 'date_of_birth' => '1990-01-02',
        'nationality_country_code' => 'MY', 'residential_address' => '1 Demo Street', 'residential_city' => 'Kuala Lumpur',
        'residential_state' => 'Kuala Lumpur', 'residential_country_code' => 'MY', 'residential_postal_code' => '50000',
    ];
    $first = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    expect($first->status)->toBe(ProviderCardholderStatus::Unknown)
        ->and(app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data)->id)->toBe($first->id)
        ->and(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, array_replace($data, ['request_id' => (string) Str::uuid()])))->toThrow(DomainException::class, 'current card application')
        ->and(ProviderCardholder::query()->count())->toBe(1);

    $tenantB = Tenant::query()->where('slug', 'tenant-b')->firstOrFail();
    expect(fn () => app(SyncProviderCardholderAction::class)->execute($tenantB->id, $this->user->id, $first->id))->toThrow(ModelNotFoundException::class);
});

it('rejects below-minimum loads and insufficient combined Wallet balance', function (): void {
    phaseTenReadyUser($this, '24.99999999');
    expect(fn () => phaseTenIssue($this, '19.99'))->toThrow(DomainException::class, 'minimum');
    expect(fn () => phaseTenIssue($this, '20.00'))->toThrow(DomainException::class, 'not enough');
    expect(CardIssueOrder::query()->count())->toBe(0)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_ISSUE_FEE_HOLD')->count())->toBe(0);
});

it('rejects every client-supplied Card issue authority field', function (): void {
    phaseTenReadyUser($this);

    $this->actingAs($this->user, 'tenant_user')->post('http://a.localhost/cards/issues', [
        'request_id' => (string) Str::uuid(),
        'card_product_id' => $this->product->id,
        'initial_load_amount' => '20.00',
        'opening_fee' => '0.00',
        'provider' => 'MOCK',
        'cardBin' => 'CLIENT-BIN',
        'cardCurrency' => 'EUR',
        'cardholderId' => 'CLIENT-HOLDER',
        'wallet_id' => (string) Str::uuid(),
        'tenant_id' => Tenant::query()->where('slug', 'tenant-b')->value('id'),
        'user_id' => (string) Str::uuid(),
    ])->assertSessionHasErrors([
        'opening_fee', 'provider', 'cardBin', 'cardCurrency', 'cardholderId', 'wallet_id', 'tenant_id', 'user_id',
    ]);

    expect(CardIssueOrder::query()->count())->toBe(0)
        ->and(LedgerEntry::query()->whereIn('event_type', ['CARD_ISSUE_FEE_HOLD', 'CARD_INITIAL_LOAD_HOLD'])->count())->toBe(0);
});

it('creates exact separate holds and settles them once on trusted provider success', function (): void {
    phaseTenReadyUser($this, '100');
    $order = phaseTenIssue($this, '20.00');

    expect($order->status)->toBe(CardIssueStatus::Succeeded)
        ->and($order->opening_fee)->toBe('5.00000000')
        ->and($order->initial_load_amount)->toBe('20.00000000')
        ->and($order->fee_hold_ledger_entry_id)->not->toBeNull()
        ->and($order->funding_hold_ledger_entry_id)->not->toBeNull()
        ->and($order->fee_settlement_ledger_entry_id)->not->toBeNull()
        ->and($order->funding_settlement_ledger_entry_id)->not->toBeNull()
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('75.00000000')
        ->and(phaseTenAccount($this, LedgerAccountType::UserCardIssueHold)->balance)->toBe('0.00000000')
        ->and(phaseTenAccount($this, LedgerAccountType::UserCardFundingHold)->balance)->toBe('0.00000000')
        ->and(LedgerEntry::query()->where('event_type', 'CARD_ISSUE_FEE_HOLD')->count())->toBe(1)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_INITIAL_LOAD_HOLD')->count())->toBe(1)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_ISSUE_FEE_SETTLE')->count())->toBe(1)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_INITIAL_LOAD_SETTLE')->count())->toBe(1)
        ->and(UserCard::query()->count())->toBe(1);
});

it('skips every zero-value fee event while retaining exact initial-funding accounting', function (): void {
    phaseTenReadyUser($this, '50');
    $this->product->forceFill(['opening_fee' => '0.00000000'])->save();
    $order = phaseTenIssue($this);

    expect($order->status)->toBe(CardIssueStatus::Succeeded)
        ->and($order->fee_hold_ledger_entry_id)->toBeNull()
        ->and($order->fee_settlement_ledger_entry_id)->toBeNull()
        ->and(LedgerEntry::query()->whereIn('event_type', ['CARD_ISSUE_FEE_HOLD', 'CARD_ISSUE_FEE_SETTLE'])->count())->toBe(0)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_INITIAL_LOAD_HOLD')->count())->toBe(1)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_INITIAL_LOAD_SETTLE')->count())->toBe(1)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('30.00000000');
});

it('releases both holds on definitive failure and keeps both holds on timeout', function (MockProviderMode $mode, CardIssueStatus $status, string $available, string $feeHold, string $fundingHold): void {
    phaseTenProvider($this, $mode);
    phaseTenReadyUser($this, '100');
    $order = phaseTenIssue($this);

    expect($order->status)->toBe($status)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($available)
        ->and(phaseTenAccount($this, LedgerAccountType::UserCardIssueHold)->balance)->toBe($feeHold)
        ->and(phaseTenAccount($this, LedgerAccountType::UserCardFundingHold)->balance)->toBe($fundingHold)
        ->and(UserCard::query()->count())->toBe(0);
})->with([
    'definitive failure' => [MockProviderMode::Failed, CardIssueStatus::Failed, '100.00000000', '0.00000000', '0.00000000'],
    'timeout' => [MockProviderMode::Timeout, CardIssueStatus::Unknown, '75.00000000', '5.00000000', '20.00000000'],
]);

it('keeps both holds when a claimed success has a mismatched provider balance', function (): void {
    phaseTenProvider($this, MockProviderMode::Unknown);
    phaseTenReadyUser($this, '100');
    $order = phaseTenIssue($this);
    $card = new ProviderCardDTO('MOCK-MISMATCHED-CARD', '', 'TEST •••• 1234', '1234', 8, 2029, 'USD', 'normal', true, '19.99000000');
    $result = new ProviderOperationDTO($order->provider_request_id, ProviderOperationStatus::Succeeded, $card->providerCardId, null, $card);

    $applied = app(ApplyCardIssueResultAction::class)->succeed($this->tenant->id, $order->id, $result);

    expect($applied->status)->toBe(CardIssueStatus::Unknown)
        ->and(phaseTenAccount($this, LedgerAccountType::UserCardIssueHold)->balance)->toBe('5.00000000')
        ->and(phaseTenAccount($this, LedgerAccountType::UserCardFundingHold)->balance)->toBe('20.00000000')
        ->and(UserCard::query()->count())->toBe(0);
});

it('is idempotent and conflicts when the same request changes amount', function (): void {
    phaseTenReadyUser($this);
    $requestId = (string) Str::uuid();
    $first = phaseTenIssue($this, '20.00', $requestId);
    $again = phaseTenIssue($this, '20.0', $requestId);

    expect($again->id)->toBe($first->id)
        ->and(CardIssueOrder::query()->count())->toBe(1)
        ->and(UserCard::query()->count())->toBe(1)
        ->and(fn () => phaseTenIssue($this, '21.00', $requestId))->toThrow(DomainException::class, 'different Card details');
});

it('resolves an unknown issue through the same provider request exactly once', function (MockProviderMode $queryMode, CardIssueStatus $expected): void {
    phaseTenProvider($this, MockProviderMode::Unknown);
    phaseTenReadyUser($this);
    $order = phaseTenIssue($this);
    expect($order->status)->toBe(CardIssueStatus::Unknown);

    phaseTenProvider($this, $queryMode);
    $resolved = app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id);
    $again = app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id);
    expect($resolved->status)->toBe($expected)
        ->and($again->status)->toBe($expected)
        ->and(CardIssueOrder::query()->count())->toBe(1)
        ->and(UserCard::query()->count())->toBe($expected === CardIssueStatus::Succeeded ? 1 : 0)
        ->and(LedgerEntry::query()->whereIn('event_type', ['CARD_ISSUE_FEE_SETTLE', 'CARD_ISSUE_FEE_RELEASE'])->count())->toBe(1);
})->with([
    'success' => [MockProviderMode::DelayedSuccess, CardIssueStatus::Succeeded],
    'failure' => [MockProviderMode::DelayedFailure, CardIssueStatus::Failed],
]);

it('continues trusted recovery after later User and Tenant suspension', function (): void {
    phaseTenProvider($this, MockProviderMode::Unknown);
    phaseTenReadyUser($this);
    $order = phaseTenIssue($this);
    $this->user->forceFill(['status' => 'SUSPENDED'])->save();
    $this->tenant->forceFill(['status' => 'SUSPENDED', 'suspended_at' => now()])->save();
    phaseTenProvider($this, MockProviderMode::DelayedSuccess);

    expect(app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id)->status)
        ->toBe(CardIssueStatus::Succeeded)
        ->and(UserCard::query()->count())->toBe(1);
});

it('never duplicates a card or settlement while processing the same success result', function (): void {
    phaseTenProvider($this, MockProviderMode::Unknown);
    phaseTenReadyUser($this);
    $order = phaseTenIssue($this);
    $card = new ProviderCardDTO('MOCK-DUPLICATE-CARD', '', 'TEST •••• 1234', '1234', 8, 2029, 'USD', 'normal', true, '20.00000000');
    $result = new ProviderOperationDTO($order->provider_request_id, ProviderOperationStatus::Succeeded, $card->providerCardId, null, $card);
    app(ApplyCardIssueResultAction::class)->succeed($this->tenant->id, $order->id, $result);
    app(ApplyCardIssueResultAction::class)->succeed($this->tenant->id, $order->id, $result);

    expect(UserCard::query()->count())->toBe(1)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_ISSUE_FEE_SETTLE')->count())->toBe(1)
        ->and(LedgerEntry::query()->where('event_type', 'CARD_INITIAL_LOAD_SETTLE')->count())->toBe(1);
});

it('enforces max cards and tenant-scoped issue recovery', function (): void {
    phaseTenReadyUser($this, '100');
    $config = TenantCardProductConfig::query()->where('tenant_id', $this->tenant->id)->firstOrFail();
    $config->forceFill(['max_cards_per_user' => 1])->save();
    $order = phaseTenIssue($this);

    phaseTenHolder($this);
    expect(fn () => phaseTenIssue($this, requestId: (string) Str::uuid()))->toThrow(DomainException::class, 'maximum')
        ->and(fn () => app(SyncCardIssueAction::class)->execute(Tenant::query()->where('slug', 'tenant-b')->value('id'), $order->id, $this->user->id))->toThrow(ModelNotFoundException::class);
});

it('reserves max-card capacity while an issue outcome remains unresolved', function (): void {
    phaseTenProvider($this, MockProviderMode::Unknown);
    phaseTenReadyUser($this, '100');
    TenantCardProductConfig::query()->where('tenant_id', $this->tenant->id)
        ->where('card_product_id', $this->product->id)
        ->update(['max_cards_per_user' => 1]);

    expect(phaseTenIssue($this)->status)->toBe(CardIssueStatus::Unknown);
    phaseTenHolder($this);
    expect(fn () => phaseTenIssue($this, requestId: (string) Str::uuid()))
        ->toThrow(DomainException::class, 'maximum')
        ->and(CardIssueOrder::query()->count())->toBe(1);
});

it('never exposes injected PAN or CVV through storage audit or the normal Inertia page', function (): void {
    phaseTenReadyUser($this);
    phaseTenIssue($this);
    $serialized = UserCard::query()->get()->toJson().' '.AuditLog::query()->get()->toJson();
    $queuedPayloads = json_encode(Queue::pushedJobs(), JSON_THROW_ON_ERROR);
    $logs = collect(glob(storage_path('logs/*.log')) ?: [])
        ->map(fn (string $path): string => file_get_contents($path))
        ->implode("\n");

    expect($serialized)->not->toContain('TEST-MOCK-FULL-PAN-1234', 'TEST-MOCK-CVV')
        ->and($queuedPayloads)->not->toContain('TEST-MOCK-FULL-PAN-1234', 'TEST-MOCK-CVV')
        ->and($logs)->not->toContain('TEST-MOCK-FULL-PAN-1234', 'TEST-MOCK-CVV')
        ->and(UserCard::query()->firstOrFail()->masked_pan)->toBe('TEST •••• 1234');
    $this->actingAs($this->user, 'tenant_user')->get('http://a.localhost/cards')->assertOk()->assertInertia(fn (Assert $page) => $page
        ->component('user/Cards')->where('cards.0.maskedPan', 'TEST •••• 1234')->missing('cards.0.providerCardId'));
});

it('exposes only read-only tenant and platform card operations routes', function (): void {
    phaseTenReadyUser($this);
    phaseTenIssue($this);
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();

    $this->actingAs($this->owner, 'tenant_admin')->get('http://a.localhost/admin/cards')->assertOk()->assertInertia(fn (Assert $page) => $page->component('tenant-admin/Cards')->has('cards', 1));
    $this->actingAs($platform, 'platform_admin')->get('http://admin.localhost/platform/cards')->assertOk()->assertInertia(fn (Assert $page) => $page->component('platform/Cards')->has('cards.data', 1)->has('orders.data', 1));
    $this->get('http://admin.localhost/platform/cards?company='.$this->tenant->id)->assertOk()->assertInertia(fn (Assert $page) => $page
        ->has('cards.data', 1)->where('cards.data.0.tenantId', $this->tenant->id)->where('cards.data.0.companyName', $this->tenant->name));
    $otherCompany = Tenant::query()->where('slug', 'tenant-b')->firstOrFail();
    $this->get('http://admin.localhost/platform/cards?company='.$otherCompany->id)->assertOk()->assertInertia(fn (Assert $page) => $page->has('cards.data', 0)->has('orders.data', 0));
    $uris = collect(Route::getRoutes())->map(fn ($route): string => implode('|', $route->methods()).' '.$route->uri());
    expect($uris->filter(fn (string $route): bool => ! in_array($route, ['PUT platform/tenants/{tenant}/cards/{card}/balance-limit', 'POST platform/tenants/{tenant}/cards/{card}/reveal'], true) && preg_match('/cards.*(manual|success|settle|release|balance|reveal|freeze|cancel|reload)/i', $route) === 1)->all())->toBe([]);
});

it('enforces issue financial state and terminal immutability at the database boundary', function (): void {
    phaseTenReadyUser($this);
    $order = phaseTenIssue($this);

    expect(fn () => DB::transaction(function () use ($order): void {
        DB::table('card_issue_orders')->where('id', $order->id)->update(['status' => 'FAILED']);
        DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
    }))->toThrow(QueryException::class)
        ->and(fn () => DB::transaction(function () use ($order): void {
            DB::table('user_cards')->where('card_issue_order_id', $order->id)->update(['provider_card_id' => 'XR-CONFLICTING-CARD']);
            DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
        }))->toThrow(QueryException::class)
        ->and(fn () => DB::transaction(function () use ($order): void {
            DB::table('user_cards')->where('card_issue_order_id', $order->id)->update(['masked_pan' => '4111111111111111']);
        }))->toThrow(QueryException::class);

    expect(DB::getSchemaBuilder()->hasColumns('user_cards', ['pan', 'card_number', 'card_no', 'cvv']))->toBeFalse();
});

function independentCardMaterials($test, string $person = 'Alice'): array
{
    return [
        'request_id' => (string) Str::uuid(), 'card_product_id' => $test->product->id,
        'legal_first_name' => $person, 'legal_last_name' => 'Holder', 'date_of_birth' => '1992-03-04',
        'email' => 'holder-contact@example.test', 'nationality_country_code' => 'MY',
        'mobile' => '13800138000', 'mobile_country_code' => 'CN',
        'residential_address' => '9 Holder Road', 'residential_city' => 'Kuala Lumpur',
        'residential_state' => 'Kuala Lumpur', 'residential_country_code' => 'MY', 'residential_postal_code' => '50000',
        'document_type' => 'id_card', 'identity_number' => 'PERSON-'.$person,
        'front' => kycTestImage(), 'back' => kycTestImage(),
    ];
}

it('derives the issuing country from this cardholders nationality without a separate input', function (string $nationality): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('createCardholder')->once()->andReturnUsing(function ($request) use ($nationality) {
        expect($request->nationalityCountryCode)->toBe($nationality)
            ->and($request->identityDocument->countryCode)->toBe($nationality)
            ->and($request->residentialCountryCode)->toBe('MY')
            ->and($request->identityDocument->identityNumber)->toBe('PERSON-Alice');

        return (new MockCardProvider)->createCardholder($request);
    });
    $provider->shouldNotReceive('issueCard');
    app()->instance(CardProviderInterface::class, $provider);
    $data = array_replace(independentCardMaterials($this), ['nationality_country_code' => $nationality]);
    expect($data)->not->toHaveKey('document_country');
    $this->actingAs($this->user, 'tenant_user')->from('http://a.localhost/cards')
        ->post('http://a.localhost/cards/cardholder', $data)->assertSessionHasNoErrors()->assertRedirect('http://a.localhost/cards');
    $holder = ProviderCardholder::query()->firstOrFail();
    $envelope = json_decode(app(CardholderMaterials::class)->decrypt($holder->materials_encrypted), true, flags: JSON_THROW_ON_ERROR);
    expect($envelope['fields']['document_country'])->toBe($nationality)
        ->and($envelope['fields']['nationality_country_code'])->toBe($nationality);
    // Even a direct Application caller cannot override the derived value or bypass replay protection.
    $replay = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, array_replace($data, ['document_country' => 'US']));
    expect($replay->id)->toBe($holder->id)
        ->and($replay->request_hash)->toBe($holder->request_hash)
        ->and(ProviderCardholder::query()->count())->toBe(1)
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
})->with(['MY', 'CN']);

it('rejects a client supplied issuing country before any cardholder submission', function (): void {
    phaseTenReadyUser($this);
    $beforeHolders = ProviderCardholder::query()->count();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldNotReceive('createCardholder');
    $provider->shouldNotReceive('issueCard');
    app()->instance(CardProviderInterface::class, $provider);
    $data = array_replace(independentCardMaterials($this), ['document_country' => 'US']);
    $this->actingAs($this->user, 'tenant_user')->post('http://a.localhost/cards/cardholder', $data)
        ->assertSessionHasErrors(['document_country']);
    expect(ProviderCardholder::query()->count())->toBe($beforeHolders)
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
});

it('submits cardholder materials without an identity number and never falls back to account identity', function (string $mode): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $identityBefore = DB::table('identity_records')->where('tenant_id', $this->tenant->id)->where('user_id', $this->user->id)->first();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('createCardholder')->once()->andReturnUsing(function ($request) {
        expect($request->identityDocument->identityNumber)->toBeNull()
            ->and($request->identityDocument->countryCode)->toBe($request->nationalityCountryCode)
            ->and($request->identityDocument->frontContents)->not->toBeEmpty();

        return (new MockCardProvider)->createCardholder($request);
    });
    $provider->shouldNotReceive('issueCard');
    app()->instance(CardProviderInterface::class, $provider);
    $data = independentCardMaterials($this);
    unset($data['identity_number']);
    if ($mode !== 'omitted') {
        $data['identity_number'] = $mode === 'null' ? null : '';
    }
    $this->actingAs($this->user, 'tenant_user')->from('http://a.localhost/cards')
        ->post('http://a.localhost/cards/cardholder', $data)->assertSessionHasNoErrors()->assertRedirect('http://a.localhost/cards');
    $holder = ProviderCardholder::query()->firstOrFail();
    $envelope = json_decode(app(CardholderMaterials::class)->decrypt($holder->materials_encrypted), true, flags: JSON_THROW_ON_ERROR);
    expect($envelope['fields']['identity_number'])->toBeNull()
        ->and($envelope['fields']['document_country'])->toBe('MY')
        ->and(DB::table('identity_records')->where('tenant_id', $this->tenant->id)->where('user_id', $this->user->id)->first())->toEqual($identityBefore)
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
    foreach ([null, ''] as $empty) {
        $replayed = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, array_replace($data, ['identity_number' => $empty]));
        expect($replayed->id)->toBe($holder->id)->and($replayed->request_hash)->toBe($holder->request_hash);
    }
})->with(['omitted', 'null', 'blank']);

it('adds one new holder per HTTP card application and issues with its exact returned identity without a review query', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $mock = new MockCardProvider;
    $calls = [];
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldNotReceive('getCardholder');
    $provider->shouldNotReceive('updateCardholder');
    $provider->shouldReceive('createCardholder')->twice()->andReturnUsing(function ($request) use ($mock, &$calls) {
        $result = $mock->createCardholder($request);
        $calls[] = ['add', $result->providerCardholderId];

        return $result;
    });
    $provider->shouldReceive('issueCard')->twice()->andReturnUsing(function ($request) use ($mock, &$calls) {
        $calls[] = ['issue', $request->holderReference];

        return $mock->issueCard($request);
    });
    app()->instance(CardProviderInterface::class, $provider);
    $this->actingAs($this->user, 'tenant_user')->from('http://a.localhost/cards');
    $identities = [];
    foreach (['Alice', 'Bruno'] as $person) {
        $data = independentCardMaterials($this, $person);
        unset($data['identity_number']);
        $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
        $this->post('http://a.localhost/cards/cardholder', $data)->assertSessionHasNoErrors()->assertSessionMissing('success');
        $holder = ProviderCardholder::query()->where('request_id', $data['request_id'])->firstOrFail();
        $identities[] = $holder->provider_cardholder_id;
        expect(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
        $this->get('http://a.localhost/cards')->assertInertia(fn (Assert $page) => $page->component('user/Cards')
            ->where('cardholder.state', 'ready')->where('cardholder.id', $holder->id)->where('cardholder.productId', $this->product->id)
            ->missing('cardholder.provider_cardholder_id'));
        $this->post('http://a.localhost/cards/cardholder', $data)->assertSessionHasNoErrors();
        $this->post('http://a.localhost/cards/issues', [
            'request_id' => (string) Str::uuid(), 'card_product_id' => $this->product->id,
            'initial_load_amount' => '20.00', 'cardholder_application_id' => $holder->id,
        ])->assertSessionHasNoErrors();
        // Consume the issue success flash; an addition must not produce a review banner.
        $this->get('http://a.localhost/cards')->assertOk();
    }
    expect($identities[0])->not->toBe($identities[1])
        ->and($calls)->toBe([['add', $identities[0]], ['issue', $identities[0]], ['add', $identities[1]], ['issue', $identities[1]]])
        ->and(UserCard::query()->count())->toBe(2)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('50.00000000');
});

it('returns addition errors inside the application without a review success flash or funds movement', function (string $mode, string $message): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    phaseTenProvider($this, MockProviderMode::Success, $mode);
    $data = independentCardMaterials($this);
    $this->actingAs($this->user, 'tenant_user')->from('http://a.localhost/cards')
        ->post('http://a.localhost/cards/cardholder', $data)
        ->assertRedirect('http://a.localhost/cards')->assertSessionHasErrors(['form' => $message])->assertSessionMissing('success');
    expect(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
    if ($mode === 'REJECTED') {
        phaseTenProvider($this, MockProviderMode::Success);
        $this->post('http://a.localhost/cards/cardholder', array_replace($data, ['request_id' => (string) Str::uuid()]))->assertSessionHasNoErrors();
        expect(ProviderCardholder::query()->count())->toBe(2);
    } else {
        expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, array_replace($data, ['request_id' => (string) Str::uuid()])))->toThrow(DomainException::class, 'current card application');
    }
})->with([
    ['REJECTED', 'The cardholder could not be added. Check the details and try again.'],
    ['TIMEOUT', 'The cardholder addition could not be confirmed. Do not submit it again.'],
]);

it('keeps a ready claim without the returned identity unconfirmed and unable to issue', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('createCardholder')->once()->andReturn(new ProviderCardholderDTO(null, ProviderCardholderReviewStatus::Ready));
    $provider->shouldNotReceive('issueCard');
    app()->instance(CardProviderInterface::class, $provider);
    $this->actingAs($this->user, 'tenant_user')->post('http://a.localhost/cards/cardholder', independentCardMaterials($this))
        ->assertSessionHasErrors(['form' => 'The cardholder addition could not be confirmed. Do not submit it again.'])->assertSessionMissing('success');
    $this->holder = ProviderCardholder::query()->firstOrFail();
    expect($this->holder->status)->toBe(ProviderCardholderStatus::Unknown)
        ->and(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'must be added successfully')
        ->and(CardIssueOrder::query()->count())->toBe(0);
});

it('rejects malformed holder contacts at the HTTP boundary with field errors and no provider work', function (): void {
    phaseTenReadyUser($this);
    $beforeHolders = ProviderCardholder::query()->count();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldNotReceive('createCardholder');
    $provider->shouldNotReceive('issueCard');
    app()->instance(CardProviderInterface::class, $provider);
    $data = array_replace(independentCardMaterials($this), ['email' => '1111', 'mobile' => '1111', 'mobile_country_code' => 'CN']);
    $this->actingAs($this->user, 'tenant_user')->from('http://a.localhost/cards')->post('http://a.localhost/cards/cardholder', $data)
        ->assertSessionHasErrors(['email' => 'Enter a valid email address.', 'mobile' => 'Select a calling code and enter a valid mobile number.']);
    expect(ProviderCardholder::query()->count())->toBe($beforeHolders)
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000')
        ->and(session()->getOldInput())->not->toHaveKeys(['email', 'mobile', 'front', 'back', 'identity_number']);
});

it('creates two cards for different people in add-holder then issue order without reading or mutating account materials', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $identityBefore = DB::table('identity_records')->where('tenant_id', $this->tenant->id)->where('user_id', $this->user->id)->first();
    $profileBefore = $this->user->profile->getAttributes();
    // The account's original documents are deliberately unavailable; independently uploaded materials still work.
    Storage::disk('private')->deleteDirectory('kyc');
    $calls = [];
    $mockProvider = new MockCardProvider;
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('available')->andReturn(true);
    $outerLevel = DB::transactionLevel();
    $provider->shouldReceive('createCardholder')->twice()->andReturnUsing(function ($request) use (&$calls, $mockProvider, $outerLevel) {
        expect(DB::transactionLevel())->toBe($outerLevel);
        $calls[] = ['add', $request->firstName, $request->identityDocument->identityNumber];

        return $mockProvider->createCardholder($request);
    });
    $provider->shouldReceive('issueCard')->twice()->andReturnUsing(function ($request) use (&$calls, $mockProvider, $outerLevel) {
        expect(DB::transactionLevel())->toBe($outerLevel);
        $calls[] = ['issue', $request->holderReference];

        return $mockProvider->issueCard($request);
    });
    app()->instance(CardProviderInterface::class, $provider);
    $holders = [];
    foreach (['Alice', 'Bruno'] as $name) {
        $data = independentCardMaterials($this, $name);
        unset($data['identity_number']);
        $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
        $holders[] = $holder;
        $this->holder = $holder;
        $order = phaseTenIssue($this);
        expect($order->provider_cardholder_id)->toBe($holder->id)
            ->and($order->cardholder_request_id)->toBe($holder->request_id)
            ->and($order->status)->toBe(CardIssueStatus::Succeeded);
    }
    expect($calls)->toBe([
        ['add', 'Alice', null], ['issue', $holders[0]->provider_cardholder_id],
        ['add', 'Bruno', null], ['issue', $holders[1]->provider_cardholder_id],
    ])->and($holders[0]->provider_cardholder_id)->not->toBe($holders[1]->provider_cardholder_id)
        ->and($this->user->profile->fresh()->getAttributes())->toBe($profileBefore)
        ->and(DB::table('identity_records')->where('tenant_id', $this->tenant->id)->where('user_id', $this->user->id)->first())->toEqual($identityBefore)
        ->and(UserCard::query()->count())->toBe(2)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('50.00000000');
});

it('encrypts per-card data and uploaded files and excludes it from props serialization audit and session', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $data = independentCardMaterials($this);
    $this->actingAs($this->user, 'tenant_user')->post('http://a.localhost/cards/cardholder', $data)->assertSessionHasNoErrors();
    $holder = ProviderCardholder::query()->firstOrFail();
    $cipher = app(CardholderMaterials::class);
    $envelope = json_decode($cipher->decrypt($holder->materials_encrypted), true, flags: JSON_THROW_ON_ERROR);
    expect($holder->materials_encrypted)->not->toContain('PERSON-Alice', 'holder-contact', 'Holder Road');
    foreach ($envelope['documents'] as $path) {
        $encrypted = Storage::disk('private')->get($path);
        expect($encrypted)->not->toBe($data['front']->getContent())
            ->and($cipher->decrypt($encrypted))->toBe($data['front']->getContent());
        Storage::disk('public')->assertMissing($path);
    }
    $query = app(UserCardCenterQuery::class)->get($this->tenant->id, $this->user->id);
    $serialized = json_encode($query).' '.$holder->toJson().' '.AuditLog::query()->get()->toJson().' '.json_encode(session()->all());
    expect($serialized)->not->toContain('PERSON-Alice', 'holder-contact', 'materials_encrypted', 'front_object_key', 'card-materials/')
        ->and($query)->not->toHaveKey('profile')
        ->and($query['cardholder']['id'])->toBe($holder->id);
    $this->post('http://a.localhost/cards/cardholder', array_replace($data, ['legal_first_name' => '']))->assertSessionHasErrors('legal_first_name');
    expect(json_encode(session()->get('_old_input')))->not->toContain('PERSON-Alice', 'holder-contact', 'Holder Road');
});

it('replays one unchanged material request without another provider creation', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $data = independentCardMaterials($this);
    $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    $files = Storage::disk('private')->allFiles('card-materials');
    $replayed = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    expect($replayed->id)->toBe($holder->id)
        ->and($replayed->provider_cardholder_id)->toBe($holder->provider_cardholder_id)
        ->and(ProviderCardholder::query()->count())->toBe(1)
        ->and(Storage::disk('private')->allFiles('card-materials'))->toBe($files)
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
});

it('edits an unissued ready holder with the same identity and scopes private prefill then seals it after issue', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $data = independentCardMaterials($this);
    $action = app(SubmitProviderCardholderAction::class);
    $holder = $action->execute($this->tenant->id, $this->user->id, $data);
    $url = 'http://a.localhost/cards/cardholder/'.$holder->id.'/details';
    $this->actingAs($this->user, 'tenant_user')->postJson($url)->assertOk()
        ->assertJsonPath('fields.legal_first_name', $data['legal_first_name'])
        ->assertJsonPath('fields.email', $data['email'])->assertJsonMissingPath('fields.identity_number')
        ->assertJsonMissingPath('fields.documents')->assertJsonMissingPath('fields.request_id');
    $other = User::query()->where('tenant_id', '!=', $this->tenant->id)->firstOrFail();
    $this->actingAs($other, 'tenant_user')->postJson('http://b.localhost/cards/cardholder/'.$holder->id.'/details')->assertNotFound();
    $before = LedgerEntry::query()->count();
    $this->travel(1)->seconds();
    $changed = array_replace($data, ['residential_address' => 'Updated Holder Road']);
    $edited = $action->execute($this->tenant->id, $this->user->id, $changed);
    expect($edited->id)->toBe($holder->id)->and($edited->provider_cardholder_id)->toBe($holder->provider_cardholder_id)
        ->and($edited->submission_version)->toBe(2)->and($edited->status)->toBe(ProviderCardholderStatus::Ready)
        ->and($action->execute($this->tenant->id, $this->user->id, $changed)->submission_version)->toBe(2)
        ->and(ProviderCardholder::query()->count())->toBe(1)->and(LedgerEntry::query()->count())->toBe($before);
    $this->actingAs($this->user, 'tenant_user')->postJson($url)->assertOk()->assertJsonPath('fields.residential_address', 'Updated Holder Road');
    $this->holder = $edited;
    phaseTenIssue($this);
    $this->postJson($url)->assertStatus(409);
    expect(fn () => $action->execute($this->tenant->id, $this->user->id, $data))->toThrow(DomainException::class, 'different details');
    expect(fn () => DB::transaction(fn () => $edited->forceFill(['status' => 'SUBMITTING', 'submission_version' => 3, 'request_hash' => str_repeat('b', 64)])->save()))->toThrow(QueryException::class);
});

it('keeps an uncertain ready-holder revision locked despite an old ready provider status', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $data = independentCardMaterials($this);
    $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('updateCardholder')->once()->andThrow(new ProviderUnknownResultException('Unconfirmed'));
    $provider->shouldReceive('getCardholder')->once()->andReturn(new ProviderCardholderDTO($holder->provider_cardholder_id, ProviderCardholderReviewStatus::Ready));
    app()->instance(CardProviderInterface::class, $provider);
    $action = app(SubmitProviderCardholderAction::class);
    $changed = array_replace($data, ['residential_address' => 'Changed street']);
    $this->holder = $action->execute($this->tenant->id, $this->user->id, $changed);
    expect($this->holder->status)->toBe(ProviderCardholderStatus::Unknown);
    expect(app(SyncProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $holder->id)->status)->toBe(ProviderCardholderStatus::Unknown);
    expect(fn () => $action->execute($this->tenant->id, $this->user->id, $data))->toThrow(DomainException::class)
        ->and(fn () => $action->execute($this->tenant->id, $this->user->id, array_replace($changed, ['request_id' => (string) Str::uuid()])))->toThrow(DomainException::class)
        ->and(fn () => phaseTenIssue($this))->toThrow(DomainException::class)
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
    expect(fn () => DB::transaction(fn () => $this->holder->forceFill(['status' => 'SUBMITTING', 'submission_version' => 3, 'request_hash' => str_repeat('c', 64)])->save()))->toThrow(QueryException::class);
});

it('permits a fresh application after definitive issue failure but never edits or reuses its old holder', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $data = independentCardMaterials($this);
    $this->holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    phaseTenProvider($this, MockProviderMode::Failed);
    expect(phaseTenIssue($this)->status)->toBe(CardIssueStatus::Failed);
    phaseTenProvider($this, MockProviderMode::Success);
    $fresh = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, array_replace($data, ['request_id' => (string) Str::uuid()]));
    expect($fresh->id)->not->toBe($this->holder->id)->and($fresh->status)->toBe(ProviderCardholderStatus::Ready);
    expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, array_replace($data, ['residential_address' => 'Changed'])))->toThrow(DomainException::class);
});

it('keeps funds untouched until the specific application is ready', function (string $mode): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    phaseTenProvider($this, MockProviderMode::Success, $mode);
    $this->holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this));
    expect(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'must be added successfully')
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(LedgerEntry::query()->whereIn('event_type', ['CARD_ISSUE_FEE_HOLD', 'CARD_INITIAL_LOAD_HOLD'])->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
})->with(['PENDING', 'TIMEOUT', 'ACTION_REQUIRED', 'REJECTED']);

it('allows action-required correction only for the same application and blocks stale review responses', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    phaseTenProvider($this, MockProviderMode::Success, 'ACTION_REQUIRED');
    $data = independentCardMaterials($this);
    $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    $oldId = $holder->provider_cardholder_id;
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('updateCardholder')->once()->andReturn(new ProviderCardholderDTO($oldId, ProviderCardholderReviewStatus::Pending, 'pending', 'pending'));
    $provider->shouldReceive('getCardholder')->once()->andReturnUsing(function () use ($data, $oldId) {
        app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, array_replace($data, ['residential_address' => 'Updated Address']));

        return new ProviderCardholderDTO($oldId, ProviderCardholderReviewStatus::Ready, 'normal', 'approved');
    });
    app()->instance(CardProviderInterface::class, $provider);
    $result = app(SyncProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $holder->id);
    expect($result->submission_version)->toBe(2)->and($result->status)->toBe(ProviderCardholderStatus::Pending)
        ->and($result->provider_cardholder_id)->toBe($oldId)->and(CardIssueOrder::query()->count())->toBe(0);
});

it('rejects reusing materials for a second order in both application and PostgreSQL', function (): void {
    phaseTenReadyUser($this);
    $first = phaseTenIssue($this);
    expect(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'each card');
    $attributes = array_replace($first->getAttributes(), ['id' => (string) Str::uuid(), 'request_id' => (string) Str::uuid(), 'provider_request_id' => (string) Str::uuid()]);
    expect(fn () => DB::transaction(fn () => DB::table('card_issue_orders')->insert($attributes)))->toThrow(QueryException::class)
        ->and(CardIssueOrder::query()->count())->toBe(1)
        ->and(UserCard::query()->count())->toBe(1)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('75.00000000');
});

it('does not allow another tenant or user application to authorize the current card', function (): void {
    phaseTenReadyUser($this);
    $tenantB = Tenant::query()->where('slug', 'tenant-b')->firstOrFail();
    $other = (object) ['tenant' => $tenantB, 'user' => User::query()->where('tenant_id', $tenantB->id)->firstOrFail(), 'product' => $this->product];
    $foreign = phaseTenHolder($other);
    expect(fn () => app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $foreign->id))->toThrow(DomainException::class, 'must be added successfully')
        ->and(fn () => app(SyncProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $foreign->id))->toThrow(ModelNotFoundException::class)
        ->and(CardIssueOrder::query()->count())->toBe(0);
});

it('keeps legacy account-level holders readable but never uses them for a new issue', function (): void {
    phaseTenReadyUser($this);
    $legacy = new ProviderCardholder;
    $legacy->forceFill(['tenant_id' => $this->tenant->id, 'user_id' => $this->user->id, 'provider' => 'PHOTONPAY', 'provider_cardholder_id' => 'MOCK-LEGACY', 'status' => 'READY'])->save();
    expect(fn () => app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $legacy->id))->toThrow(DomainException::class, 'must be added successfully')
        ->and($legacy->fresh()->status)->toBe(ProviderCardholderStatus::Ready)
        ->and($legacy->fresh()->request_id)->toBeNull();
});

it('sends independently selected billing geography and phone through the holder contract', function (): void {
    phaseTenReadyUser($this);
    ProviderCardholder::query()->delete();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('createCardholder')->once()->andReturnUsing(function ($request) {
        expect($request->residentialCountryCode)->toBe('CN')
            ->and($request->residentialState)->toBe('Anhui')
            ->and($request->residentialCity)->toBe('Fuyang')
            ->and($request->mobile)->toBe('2025550123')
            ->and($request->mobilePrefix)->toBe('1');

        return (new MockCardProvider)->createCardholder($request);
    });
    app()->instance(CardProviderInterface::class, $provider);
    $data = array_replace(independentCardMaterials($this), ['residential_country_code' => 'CN', 'residential_state' => 'Anhui', 'residential_city' => 'Fuyang', 'mobile' => '202-555-0123', 'mobile_country_code' => 'US']);
    $holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $data);
    $fields = json_decode(app(CardholderMaterials::class)->decrypt($holder->materials_encrypted), true)['fields'];
    expect($fields['mobile'])->toBe('2025550123')
        ->and($holder->toArray())->not->toHaveKey('materials_encrypted')
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
});

it('rejects same-tenant other-user and other-product holder applications before holds', function (): void {
    phaseTenReadyUser($this);
    $otherUser = $this->user->replicate(['account_id']);
    $otherUser->forceFill(['email' => 'different-holder-owner@example.test', 'phone' => null])->save();
    $scope = (object) ['tenant' => $this->tenant, 'user' => $otherUser, 'product' => $this->product];
    $foreign = phaseTenHolder($scope);
    expect(fn () => app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $foreign->id))->toThrow(DomainException::class)
        ->and(fn () => app(SyncProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, $foreign->id))->toThrow(ModelNotFoundException::class);
    $otherProduct = $this->product->replicate();
    $otherProduct->forceFill(['name' => 'Other regular product', 'provider_product_ref' => 'MOCK-OTHER-PRODUCT'])->save();
    $scope = (object) ['tenant' => $this->tenant, 'user' => $this->user, 'product' => $otherProduct];
    $wrongProduct = phaseTenHolder($scope);
    expect(fn () => app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $wrongProduct->id))->toThrow(DomainException::class)
        ->and(CardIssueOrder::query()->count())->toBe(0)
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe('100.00000000');
});

/** Create through the real business/ledger flow with an isolated test provider result, never by rewriting a legacy card ID. */
function transactionReadFixture($test): array
{
    phaseTenReadyUser($test);
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('productAvailable')->andReturn(true);
    $provider->shouldReceive('issueCard')->once()->andReturnUsing(function ($request): ProviderOperationDTO {
        $card = new ProviderCardDTO('XR-TRANSACTION-FIXTURE', '', '•••• 5678', '5678', 8, 2029, 'USD', 'normal', false, '20.00000000');

        return new ProviderOperationDTO($request->idempotencyKey, ProviderOperationStatus::Succeeded, $card->providerCardId, card: $card);
    });
    app()->instance(CardProviderInterface::class, $provider);
    $order = phaseTenIssue($test);
    $card = UserCard::query()->where('tenant_id', $test->tenant->id)->where('user_id', $test->user->id)->where('card_issue_order_id', $order->id)->firstOrFail();

    return [$card, $provider];
}

it('syncs scoped transaction pages and reads stored data without changing card wallet or ledger data', function (): void {
    [$card, $provider] = transactionReadFixture($this);
    $baseline = DB::transactionLevel();
    $provider->shouldReceive('getTransactionPage')->with('XR-TRANSACTION-FIXTURE', 1, 20)->once()
        ->andReturnUsing(function () use ($baseline): ProviderTransactionPageDTO {
            expect(DB::transactionLevel())->toBe($baseline);

            return new ProviderTransactionPageDTO([
                new ProviderCardTransactionDTO('IT-PRIVATE-REFERENCE', '12.34000000', 'EUR', 'purchase', 'completed', '2026-09-11T09:05:04', 'Example shop'),
            ], 1, true);
        });
    $provider->shouldReceive('getTransactionPage')->with('XR-TRANSACTION-FIXTURE', 2, 20)->once()->andReturn(new ProviderTransactionPageDTO([], 2, false));
    $tables = ['users', 'user_cards', 'card_issue_orders', 'provider_cardholders', 'wallets', 'ledger_accounts', 'ledger_entries', 'ledger_postings'];
    $before = collect($tables)->mapWithKeys(fn ($table) => [$table => DB::table($table)->orderBy('id')->get()->toJson()]);
    $response = $this->actingAs($this->user, 'tenant_user')->postJson("http://a.localhost/cards/{$card->id}/transactions/sync", ['page' => 1])
        ->assertOk()->assertHeader('Cache-Control', 'no-store, private')->assertJsonPath('hasMore', true)
        ->assertJsonPath('items.0.cardId', $card->id)->assertJsonPath('items.0.last4', '5678')->assertJsonPath('items.0.amount', '12.34000000');
    expect($response->getContent())->not->toContain('IT-PRIVATE-REFERENCE', 'XR-TRANSACTION-FIXTURE', 'provider_card_id', 'tenant_id', 'cvv');
    $this->postJson("http://a.localhost/cards/{$card->id}/transactions/sync", ['page' => 2])->assertOk()->assertExactJson(['items' => [], 'page' => 2, 'hasMore' => false]);
    $this->getJson("http://a.localhost/cards/{$card->id}/transactions?page=1")->assertOk()->assertJsonPath('items.0.timeKind', 'recorded')->assertJsonMissingPath('items.0.occurredAt');
    foreach ($tables as $table) {
        expect(DB::table($table)->orderBy('id')->get()->toJson())->toBe($before[$table]);
    }
});

it('checks card tenant user ownership and request selectors before transaction provider calls', function (): void {
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldNotReceive('getTransactionPage');
    $otherTenant = Tenant::query()->where('slug', 'tenant-b')->firstOrFail();
    expect(fn () => app(UserCardTransactionsQuery::class)->get($otherTenant->id, $this->user->id, $card->id, 1))->toThrow(ModelNotFoundException::class);
    $other = $this->user->replicate(['account_id']);
    $other->forceFill(['email' => 'transaction-reader@example.test', 'phone' => null])->save();
    $this->actingAs($other, 'tenant_user')->getJson("http://a.localhost/cards/{$card->id}/transactions")->assertNotFound();
    $this->actingAs($this->user, 'tenant_user')->getJson("http://a.localhost/cards/{$card->id}/transactions?tenant_id={$otherTenant->id}&provider_card_id=XR-FOREIGN")
        ->assertUnprocessable()->assertJsonValidationErrors(['tenant_id', 'provider_card_id']);
    foreach (['0', '-1', '1.5', '100001'] as $page) {
        $this->getJson("http://a.localhost/cards/{$card->id}/transactions?page={$page}")->assertUnprocessable()->assertJsonValidationErrors('page');
    }
    $this->user->forceFill(['status' => 'SUSPENDED'])->save();
    $this->getJson("http://a.localhost/cards/{$card->id}/transactions")->assertRedirect('/account/restricted');
});

it('returns a safe unavailable transaction response for provider failures instead of an empty success', function (): void {
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldReceive('getTransactionPage')->once()->andThrow(new ProviderUnknownResultException('private-provider-error-with-card-data'));
    $balance = $card->provider_balance;
    $response = $this->actingAs($this->user, 'tenant_user')->postJson("http://a.localhost/cards/{$card->id}/transactions/sync")->assertStatus(503);
    expect($response->getContent())->not->toContain('private-provider-error-with-card-data')->and($card->fresh()->provider_balance)->toBe($balance);
});

it('never uses a historical mock card reference to read production transaction history', function (): void {
    phaseTenReadyUser($this);
    $order = phaseTenIssue($this);
    $card = UserCard::query()->where('tenant_id', $this->tenant->id)->where('card_issue_order_id', $order->id)->firstOrFail();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldNotReceive('getTransactionPage');
    app()->instance(CardProviderInterface::class, $provider);
    $this->actingAs($this->user, 'tenant_user')->postJson("http://a.localhost/cards/{$card->id}/transactions/sync")->assertStatus(503);
});

it('snapshots the SaaS price and preserves completed replay after a platform price change', function (): void {
    phaseTenReadyUser($this, '100');
    $this->product->forceFill(['opening_fee' => '7.00000000'])->save();
    $request = (string) Str::uuid();
    $order = phaseTenIssue($this, '20.00', $request);
    expect($order->opening_fee)->toBe('7.00000000');
    $entries = LedgerEntry::query()->count();
    $this->product->forceFill(['opening_fee' => '9.00000000'])->save();
    expect(phaseTenIssue($this, '20.00', $request)->id)->toBe($order->id)
        ->and($order->fresh()->opening_fee)->toBe('7.00000000')
        ->and(LedgerEntry::query()->count())->toBe($entries);
});

it('shows confirmed platform card balances and refreshes only the selected company card without ledger changes', function (): void {
    [$card] = managedCardFixture($this);
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $entries = LedgerEntry::query()->count();
    $other = Tenant::query()->where('id', '!=', $this->tenant->id)->firstOrFail();
    $this->actingAs($platform, 'platform_admin')->get('http://admin.localhost/platform/cards?tab=cards')
        ->assertOk()->assertInertia(fn (Assert $page) => $page->where('cards.data.0.balance', $card->provider_balance)
        ->where('cards.data.0.currency', 'USD')->has('cards.data.0.balanceUpdatedAt'));
    $this->post('http://admin.localhost/platform/tenants/'.$other->id.'/cards/'.$card->id.'/refresh', ['tenant_id' => $this->tenant->id])->assertNotFound();
    $this->from('http://admin.localhost/platform/cards?tab=cards')->post('http://admin.localhost/platform/tenants/'.$this->tenant->id.'/cards/'.$card->id.'/refresh')
        ->assertRedirect('http://admin.localhost/platform/cards?tab=cards')->assertSessionHasNoErrors();
    expect(LedgerEntry::query()->count())->toBe($entries)->and($card->fresh()->provider_balance_synced_at)->not->toBeNull();
});

it('counts card capacity independently for each product during holder submission and issue', function (): void {
    Http::preventStrayRequests();
    phaseTenReadyUser($this, '200');
    $config = TenantCardProductConfig::query()->where('tenant_id', $this->tenant->id)->where('card_product_id', $this->product->id)->sole();
    $config->forceFill(['max_cards_per_user' => 1])->save();
    $first = phaseTenIssue($this);
    $secondProduct = $this->product->replicate();
    $secondProduct->forceFill(['name' => 'Independent capacity product', 'provider_product_ref' => 'MOCK-SECOND-CAPACITY-PRODUCT'])->save();
    $secondConfig = $config->replicate();
    $secondConfig->forceFill(['card_product_id' => $secondProduct->id])->save();
    $this->product = $secondProduct;
    $this->holder = app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this));
    expect($this->holder->status)->toBe(ProviderCardholderStatus::Ready);
    $second = phaseTenIssue($this);
    expect($first->status)->toBe(CardIssueStatus::Succeeded)
        ->and($second->status)->toBe(CardIssueStatus::Succeeded)
        ->and($second->card_product_id)->toBe($secondProduct->id);
    expect(fn () => app(SubmitProviderCardholderAction::class)->execute($this->tenant->id, $this->user->id, independentCardMaterials($this, 'Bob')))->toThrow(DomainException::class, 'maximum');
    Http::assertNothingSent();
});

it('preserves first recorded time across duplicate syncs and ignores overlapping older observations', function (): void {
    [$card] = transactionReadFixture($this);
    $record = app(RecordCardTransactionsAction::class);
    $make = fn ($state) => new ProviderCardTransactionDTO('RECORD-STABLE', '12.34000000', 'USD', 'purchase', $state, '2020-01-01T09:00:00', null);
    $this->travelTo(CarbonImmutable::parse('2026-09-15T15:59:59.123456Z'));
    $record->execute($card, [$make('pending')], CarbonImmutable::now());
    $first = CardTransaction::query()->where('card_id', $card->id)->firstOrFail();
    $firstTime = $first->created_at->format('Y-m-d H:i:s.u');
    $oldStart = CarbonImmutable::now();
    $this->travelTo(CarbonImmutable::parse('2026-09-15T16:00:00.654321Z'));
    $record->execute($card, [$make('completed')], CarbonImmutable::now());
    $record->execute($card, [$make('pending')], $oldStart);
    expect(CardTransaction::query()->where('card_id', $card->id)->count())->toBe(1)
        ->and($first->fresh()->created_at->format('Y-m-d H:i:s.u'))->toBe($firstTime)
        ->and($first->fresh()->state)->toBe('completed');
    $view = app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1);
    expect($view['items'][0]['timeKind'])->toBe('recorded')->and($view['items'][0]['displayAt'])->toBe('2026-09-15T15:59:59+00:00');
});

it('uses an exact transaction match for completion time and never matches only amount', function (): void {
    [$card, $provider, $action] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-SYSTEM-TIME', '20.00000000', '20.00000000', '0.00000000'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $settled = $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    $entry = LedgerEntry::query()->findOrFail($settled->settlement_entry_id);
    $this->travel(1)->hours();
    app(RecordCardTransactionsAction::class)->execute($card, [
        new ProviderCardTransactionDTO('TX-SYSTEM-TIME', '20.00000000', 'USD', 'transfer_in', 'completed', '2020-01-01T00:00:00', null),
        new ProviderCardTransactionDTO('SAME-AMOUNT-DIFFERENT-TX', '20.00000000', 'USD', 'transfer_in', 'completed', '2020-01-01T00:00:00', null),
    ], CarbonImmutable::now());
    $items = collect(app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1)['items']);
    expect($items->where('timeKind', 'completed'))->toHaveCount(1)
        ->and($items->firstWhere('timeKind', 'completed')['displayAt'])->toBe($entry->posted_at->utc()->toIso8601String())
        ->and($items->where('timeKind', 'recorded'))->toHaveCount(1);
});

it('keeps stored records readable after sync fails and blocks foreign sync selectors', function (): void {
    [$card, $provider] = transactionReadFixture($this);
    app(RecordCardTransactionsAction::class)->execute($card, [
        new ProviderCardTransactionDTO('OFFLINE-STORED', '0.01000000', 'USD', 'purchase', 'pending', '2020-01-01T00:00:00', null),
    ], CarbonImmutable::now());
    $other = $this->user->replicate(['account_id']);
    $other->forceFill(['email' => 'sync-foreign@example.test', 'phone' => null])->save();
    $this->actingAs($other, 'tenant_user')->postJson("http://a.localhost/cards/{$card->id}/transactions/sync")->assertNotFound();
    $this->actingAs($this->user, 'tenant_user')->postJson("http://a.localhost/cards/{$card->id}/transactions/sync", ['tenant_id' => $this->tenant->id])->assertUnprocessable();
    $provider->shouldReceive('getTransactionPage')->once()->andThrow(new ProviderUnknownResultException('secret'));
    $this->postJson("http://a.localhost/cards/{$card->id}/transactions/sync")->assertStatus(503);
    $this->getJson("http://a.localhost/cards/{$card->id}/transactions")->assertOk()->assertJsonCount(1, 'items')->assertJsonPath('items.0.amount', '0.01000000');
});

it('lets SaaS read scoped paginated stored card transactions without provider or financial writes', function (): void {
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldNotReceive('getTransactionPage');
    $provider->shouldNotReceive('getTransactions');
    $provider->shouldNotReceive('getCard');
    $this->tenant->update(['timezone' => 'Asia/Shanghai']);
    $rows = [];
    for ($i = 0; $i < 21; $i++) {
        $rows[] = new ProviderCardTransactionDTO('PLATFORM-PRIVATE-'.$i, '123456789012.12345678', 'USD', 'purchase', 'completed', '2020-01-01T00:00:00', 'Example shop');
    }
    app(RecordCardTransactionsAction::class)->execute($card, $rows, CarbonImmutable::now());
    $card->forceFill(['provider_status' => 'cancelled'])->save();
    $tables = ['user_cards', 'card_transactions', 'card_management_orders', 'wallets', 'ledger_accounts', 'ledger_entries', 'ledger_postings'];
    $before = collect($tables)->mapWithKeys(fn ($table) => [$table => DB::table($table)->orderBy('id')->get()->toJson()]);
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $url = "http://admin.localhost/platform/tenants/{$this->tenant->id}/cards/{$card->id}/transactions";
    $first = $this->actingAs($platform, 'platform_admin')->getJson($url)->assertOk()
        ->assertHeader('Cache-Control', 'no-store, private')->assertJsonCount(20, 'items')
        ->assertJsonPath('timezone', 'Asia/Shanghai')->assertJsonPath('page', 1)->assertJsonPath('hasMore', true)
        ->assertJsonPath('items.0.amount', '123456789012.12345678')->assertJsonPath('items.0.timeKind', 'recorded');
    expect($first->getContent())->not->toContain('PLATFORM-PRIVATE-', 'XR-TRANSACTION-FIXTURE', 'provider_card_id', 'provider_transaction_id', 'cvv', 'tenant_id', 'user_id');
    $second = $this->getJson($url.'?page=2')->assertOk()->assertJsonCount(1, 'items')->assertJsonPath('hasMore', false);
    expect(array_intersect(array_column($first->json('items'), 'id'), array_column($second->json('items'), 'id')))->toBe([]);
    $this->getJson($url.'?page=3')->assertOk()->assertJsonCount(0, 'items');
    foreach ($tables as $table) {
        expect(DB::table($table)->orderBy('id')->get()->toJson())->toBe($before[$table]);
    }
});

it('protects SaaS card transaction reads with company scoping and active cards read permission', function (): void {
    [$card] = transactionReadFixture($this);
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $other = Tenant::query()->where('slug', 'tenant-b')->firstOrFail();
    $url = "http://admin.localhost/platform/tenants/{$this->tenant->id}/cards/{$card->id}/transactions";
    $this->getJson($url)->assertRedirect('/platform/login');
    $this->actingAs($this->owner, 'platform_admin')->getJson($url)->assertForbidden();
    $this->actingAs($platform, 'platform_admin');
    $this->getJson("http://admin.localhost/platform/tenants/{$other->id}/cards/{$card->id}/transactions")->assertNotFound();
    $this->getJson("http://admin.localhost/platform/tenants/{$this->tenant->id}/cards/".Str::uuid().'/transactions')->assertNotFound();
    foreach (['page=0', 'page=100001', 'page=1.5', 'tenant_id='.$other->id, 'user_id='.$this->user->id, 'provider_card_id=other', 'page_size=1000'] as $invalid) {
        $this->getJson($url.'?'.$invalid)->assertUnprocessable();
    }
    $this->getJson($url)->assertOk()->assertJsonCount(0, 'items');
    $platform->update(['status' => 'SUSPENDED']);
    $this->getJson($url)->assertForbidden();
    $platform->update(['status' => 'ACTIVE']);
    $this->actingAs($platform->fresh(), 'platform_admin');
    DB::table('admin_memberships')->where('admin_user_id', $platform->id)->update(['status' => 'SUSPENDED']);
    $this->getJson($url)->assertForbidden();
    DB::table('admin_memberships')->where('admin_user_id', $platform->id)->update(['status' => 'ACTIVE']);
    DB::table('role_permissions')->where('permission_id', DB::table('permissions')->where('name', 'cards.read')->value('id'))->delete();
    $this->actingAs($platform->fresh(), 'platform_admin')->getJson($url)->assertForbidden();
});

it('uses paid agent eligibility for issuing and loading without a deposit and stops new actions on expiry', function (): void {
    phaseTenReadyUser($this, '3000');
    $purchase = app(PaidPromotionPurchase::class);
    $level = DB::table('paid_promotion_levels')->where('tenant_id', $this->tenant->id)->where('rank', 1)->value('id');
    $quote = $purchase->quote($this->tenant->id, $this->user->id, $level, (string) Str::uuid());
    $paid = $purchase->confirm($this->tenant->id, $this->user->id, $quote->id);
    expect(phaseTenAccount($this, LedgerAccountType::UserSecurityDeposit)->balance)->toBe('0.00000000');
    expect(phaseTenIssue($this)->status)->toBe(CardIssueStatus::Succeeded);
    $card = UserCard::where('user_id', $this->user->id)->firstOrFail();
    $provider = Mockery::mock(CardProviderInterface::class);
    $provider->shouldReceive('available')->andReturn(true);
    $provider->shouldReceive('name')->andReturn('PHOTONPAY');
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    app()->instance(CardProviderInterface::class, $provider);
    $action = app(ManageCardAction::class);
    $load = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    expect($load->status)->toBe('QUOTED');
    $before = $card->fresh()->getAttributes();
    $this->travelTo(CarbonImmutable::parse(DB::table('paid_promotion_cycles')->where('id', $paid->cycle_id)->value('ends_at')));
    expect(fn () => $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20'))->toThrow(DomainException::class);
    $this->holder = phaseTenHolder($this);
    expect(fn () => phaseTenIssue($this))->toThrow(DomainException::class, 'Activate your account');
    expect($card->fresh()->getAttributes())->toBe($before);
});

it('splits capped recharge into provider and external funding with full wallet debit', function (bool $productDefault): void {
    [$card, $provider, $action] = managedCardFixture($this, function () use (&$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'normal', false, '400.00000000');
    }, '1000.00000000');
    $card->product->forceFill(['balance_limit' => $productDefault ? '500' : '450'])->save();
    if (! $productDefault) {
        $card->forceFill(['balance_limit' => '500'])->save();
    }
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('quoteCardLoad')->once()->withArgs(fn ($id, $amount, $request) => $amount === '100.00000000')
        ->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '101.00000000', $amount, '1.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'CAP-TX', '101.00000000', '100.00000000', '1.00000000'));
    $request = (string) Str::uuid();
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, $request, '500');
    expect($order->status)->toBe('QUOTED')->and($order->amount)->toBe('100.00000000')
        ->and($order->requested_amount)->toBe('500.00000000')->and($order->overflow_amount)->toBe('400.00000000');
    expect($action->quote($this->tenant->id, $this->user->id, $card->id, $request, '500')->id)->toBe($order->id);
    expect(fn () => $action->quote($this->tenant->id, $this->user->id, $card->id, $request, '100'))->toThrow(DomainException::class);
    expect(fn () => $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '500'))->toThrow(DomainException::class);
    $result = $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    expect($result->status)->toBe('SUCCEEDED')->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)
        ->toBe(Money::of($before, 'USDT')->subtract(Money::of('501', 'USDT'))->amount());
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    expect(LedgerEntry::query()->where('reference_id', $order->id)->count())->toBe(2);
    expect(UserCardManagementAction::order($result))->not->toHaveKeys(['overflowAmount', 'overflow_amount', 'balance_limit_snapshot']);
    expect(app(AdminCardLoadsQuery::class)->get($this->tenant->id)->items()[0]->overflowAmount)->toBe('400.00000000');
    $report = app(PlatformDailyFundsQuery::class);
    $date = now('Asia/Kuala_Lumpur')->toDateString();
    $filters = ['start' => $date, 'end' => $date, 'scope' => 'selected', 'companies' => [$this->tenant->id]];
    $summary = $report->execute($filters, ['overflow' => true, 'inflow' => true, 'outflow' => true]);
    expect($summary['totals']['overflow'])->toBe('400.00000000')
        ->and($summary['days'][0]['overflow'])->toBe('400.00000000');
    expect($report->execute($filters, [])['totals'])->toBe([]);
    $filters['companies'] = [Tenant::query()->where('id', '!=', $this->tenant->id)->firstOrFail()->id];
    expect($report->execute($filters, ['overflow' => true])['totals']['overflow'])->toBe('0.00000000');

    expect(app(AdminCardLoadsQuery::class)->get(Tenant::query()->where('id', '!=', $this->tenant->id)->firstOrFail()->id)->total())->toBe(0);
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
    expect(fn () => DB::transaction(fn () => $order->forceFill(['requested_amount' => '600', 'overflow_amount' => '500'])->save()))->toThrow(QueryException::class);
})->with([true, false]);

it('funds external reloads atomically without a provider call when capacity is below minimum', function (string $limit): void {
    [$card, $provider, $action] = managedCardFixture($this, available: '1000.00000000');
    $card->forceFill(['balance_limit' => $limit])->save();
    $entries = LedgerEntry::count();
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldNotReceive('quoteCardLoad');
    $provider->shouldNotReceive('confirmCardLoad');
    $request = (string) Str::uuid();
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, $request, '80');
    expect($order->amount)->toBe('0.00000000')->and($order->manual_funding_amount)->toBe('80.00000000')
        ->and($order->debit_amount)->toBe('80.00000000')->and(LedgerEntry::count())->toBe($entries);
    $done = $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    expect($done->status)->toBe('SUCCEEDED')->and($done->provider_called_at)->toBeNull()
        ->and($done->provider_transaction_id)->toBeNull()
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->subtract(Money::of('80', 'USDT'))->amount());
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    expect($action->quote($this->tenant->id, $this->user->id, $card->id, $request, '80')->id)->toBe($order->id)
        ->and(LedgerEntry::count())->toBe($entries + 3)
        ->and($card->fresh()->overflowBalance())->toBe('80.00000000');
    $items = app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1);
    expect($items['items'])->toHaveCount(1);
    expect($items['items'][0]['amount'])->toBe('80.00000000')->and($items['items'][0]['type'])->toBe('transfer_in');
    DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
})->with(['0', '20', '30']);

it('expires a capped quote without a hold if the fresh balance leaves insufficient capacity', function (): void {
    $balance = '400.00000000';
    [$card, $provider, $action] = managedCardFixture($this, function () use (&$card, &$balance) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'normal', false, $balance);
    });
    $card->forceFill(['balance_limit' => '500'])->save();
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, $amount, $amount, '0.00000000'));
    $provider->shouldNotReceive('confirmCardLoad');
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '500');
    $balance = '450.00000000';
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('EXPIRED');
    expect($order->fresh()->status)->toBe('EXPIRED');
    expect(LedgerEntry::query()->where('reference_id', $order->id)->count())->toBe(0);
});

it('only permits platform product managers to change a scoped idle card limit without moving funds', function (): void {
    [$card, $provider, $action] = managedCardFixture($this);
    $owner = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $url = 'http://admin.localhost/platform/tenants/'.$this->tenant->id.'/cards/'.$card->id.'/balance-limit';
    $entries = LedgerEntry::query()->count();
    $this->actingAs($owner, 'platform_admin')->put($url, ['balance_limit' => '500'])->assertRedirect();
    expect($card->fresh()->balance_limit)->toBe('500.00000000')->and(LedgerEntry::query()->count())->toBe($entries);
    expect(AuditLog::query()->where('action', 'CARD_BALANCE_LIMIT_UPDATED')->count())->toBe(1);
    $this->put($url, ['balance_limit' => '-1'])->assertSessionHasErrors('balance_limit');
    $foreign = Tenant::query()->where('id', '!=', $this->tenant->id)->firstOrFail();
    $this->put(str_replace($this->tenant->id, $foreign->id, $url), ['balance_limit' => '200'])->assertNotFound();
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, $amount, $amount, '0.00000000'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $this->put($url, ['balance_limit' => '100'])->assertSessionHasErrors('balance_limit');
    expect($card->fresh()->balance_limit)->toBe('500.00000000');
    $this->travel(61)->seconds();
    $this->put($url, ['balance_limit' => ''])->assertRedirect()->assertSessionHasNoErrors();
    expect($card->fresh()->balance_limit)->toBeNull()->and($order->fresh()->status)->toBe('EXPIRED');
});

it('retains the full recharge hold on timeout and recovers it once without sending again', function (): void {
    [$card, $provider, $action] = managedCardFixture($this, available: '1000.00000000');
    $card->forceFill(['balance_limit' => '50'])->save();
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '31.00000000', $amount, '1.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andThrow(new ProviderUnknownResultException('timeout'));
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '500');
    expect($order->overflow_amount)->toBe('470.00000000');
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('UNKNOWN');
    expect(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->subtract(Money::of('501', 'USDT'))->amount());
    $provider->shouldReceive('queryCardFunds')->once()->andReturn(new ProviderCardFundsDTO(ProviderOperationStatus::Failed, $card->provider_card_id, $order->provider_request_id));
    expect($action->sync($this->tenant->id, $order->id)->status)->toBe('FAILED');
    expect($action->sync($this->tenant->id, $order->id)->status)->toBe('FAILED');
    expect(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
    expect(LedgerEntry::query()->where('reference_id', $order->id)->count())->toBe(2);
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('refuses capped reload when the current provider balance cannot be read', function (): void {
    [$card, $provider, $action] = managedCardFixture($this, fn () => throw new ProviderUnknownResultException('unavailable'));
    $card->forceFill(['balance_limit' => '500', 'provider_balance' => '20'])->save();
    $provider->shouldNotReceive('quoteCardLoad');
    $before = LedgerEntry::query()->count();
    expect(fn () => $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '500'))->toThrow(ProviderUnknownResultException::class);
    expect(LedgerEntry::query()->count())->toBe($before)->and(CardManagementOrder::query()->count())->toBe(0);
});

it('denies a platform reader the card limit mutation', function (): void {
    [$card] = managedCardFixture($this);
    $auditor = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    DB::table('role_permissions')->where('permission_id', DB::table('permissions')->where('name', 'card_product.manage')->value('id'))->delete();
    $this->actingAs($auditor, 'platform_admin')->put('http://admin.localhost/platform/tenants/'.$this->tenant->id.'/cards/'.$card->id.'/balance-limit', ['balance_limit' => '500'])->assertForbidden();
    expect($card->fresh()->balance_limit)->toBeNull();
});

it('lets platform void an unsubmitted reload quote once and release the card for a new quote', function (): void {
    [$card, $provider, $action] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->twice()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, $amount, $amount, '0.00000000'));
    $provider->shouldNotReceive('confirmCardLoad');
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    $order->forceFill(['status' => 'QUOTING'])->save();
    $entries = LedgerEntry::count();
    $url = 'http://admin.localhost/platform/tenants/'.$this->tenant->id.'/cards/'.$card->id.'/loads/'.$order->id.'/void';
    $owner = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $this->actingAs($owner, 'platform_admin')->post($url)->assertRedirect()->assertSessionHasNoErrors();
    $this->post($url)->assertRedirect()->assertSessionHasNoErrors();
    expect($order->fresh()->status)->toBe('EXPIRED')
        ->and(AuditLog::where('action', 'CARD_LOAD_QUOTE_VOIDED')->count())->toBe(1)
        ->and(LedgerEntry::count())->toBe($entries);
    expect($action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id)->status)->toBe('EXPIRED');
    $next = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    expect($next->status)->toBe('QUOTED');
    $next->forceFill(['provider_called_at' => now()])->save();
    $this->post(str_replace($order->id, $next->id, $url))->assertSessionHasErrors('card_load');
    expect($next->fresh()->status)->toBe('QUOTED')->and(LedgerEntry::count())->toBe($entries);
});

it('rolls back all external funding accounting when the wallet cannot cover the full recharge', function (): void {
    [$card, $provider, $action] = managedCardFixture($this);
    $card->forceFill(['balance_limit' => '0'])->save();
    $provider->shouldNotReceive('quoteCardLoad');
    $provider->shouldNotReceive('confirmCardLoad');
    $quote = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '1000');
    $entries = LedgerEntry::count();
    expect(fn () => $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $quote->id))->toThrow(DomainException::class);
    expect($quote->fresh()->status)->toBe('QUOTED')->and($quote->fresh()->hold_entry_id)->toBeNull()
        ->and(LedgerEntry::count())->toBe($entries);
});

it('releases the complete recharge including external funding when the provider portion fails', function (): void {
    [$card, $provider, $action] = managedCardFixture($this, available: '1000.00000000');
    $card->forceFill(['balance_limit' => '40'])->save();
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '21.00000000', '20.00000000', '1.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Failed, $id, $request));
    $quote = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '100');
    expect($quote->debit_amount)->toBe('101.00000000')->and($quote->manual_funding_amount)->toBe('80.00000000');
    $result = $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $quote->id);
    expect($result->status)->toBe('FAILED')->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
    DB::statement('SET CONSTRAINTS card_management_accounting IMMEDIATE');
});

it('keeps an independent overflow balance across provider refreshes and records idempotent SaaS consumption', function (): void {
    $balance = '20.00000000';
    [$card, $provider, $action] = managedCardFixture($this, function () use (&$card, &$balance) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'normal', false, $balance);
    }, '1000.00000000');
    $card->forceFill(['balance_limit' => '30'])->save();
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '80');
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    expect($card->fresh()->availableBalance())->toBe('100.00000000');
    app(RefreshManagedCardAction::class)->execute($this->tenant->id, $this->user->id, $card->id);
    expect($card->fresh()->availableBalance())->toBe('100.00000000');
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $url = "http://admin.localhost/platform/tenants/{$this->tenant->id}/cards/{$card->id}/overflow-spends";
    $data = ['amount' => '25', 'note' => 'EXT-123', 'request_id' => (string) Str::uuid(), 'confirmed' => true];
    $this->actingAs($platform, 'platform_admin')->postJson($url, $data)->assertUnprocessable();
    expect($card->fresh()->overflowBalance())->toBe('80.00000000');
    $balance = '0.00000000';
    $this->post($url, $data)->assertRedirect();
    expect($card->fresh()->overflowBalance())->toBe('55.00000000')->and($card->fresh()->availableBalance())->toBe('55.00000000');
    $entries = LedgerEntry::count();
    $this->post($url, $data)->assertRedirect();
    expect(LedgerEntry::count())->toBe($entries);
    $this->postJson($url, array_replace($data, ['amount' => '26']))->assertUnprocessable();
    $this->postJson($url, array_replace($data, ['request_id' => (string) Str::uuid(), 'amount' => '56']))->assertUnprocessable();
    $items = app(UserCardTransactionsQuery::class)->get($this->tenant->id, $this->user->id, $card->id, 1)['items'];
    expect($items)->toHaveCount(2)->and(collect($items)->firstWhere('type', 'purchase')['amount'])->toBe('25.00000000');
    expect(collect($items)->firstWhere('type', 'purchase'))->not->toHaveKeys(['note', 'operator']);
    $adminItems = app(PlatformCardTransactionsQuery::class)->get($this->tenant->id, $card->id, 1)['items'];
    expect(collect($adminItems)->firstWhere('type', 'purchase')['operator'])->toBe($platform->email);
    $this->actingAs($this->owner, 'platform_admin')->postJson($url, array_replace($data, ['request_id' => (string) Str::uuid()]))->assertForbidden();
    DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
});

it('calculates reload capacity from combined balance and deduplicates the matching provider funding row', function (): void {
    [$card, $provider, $action] = managedCardFixture($this, available: '1000.00000000');
    $card->forceFill(['balance_limit' => '30'])->save();
    $first = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '80');
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $first->id);
    $this->travel(1)->seconds();
    $card->forceFill(['balance_limit' => '115'])->save();
    $second = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '80');
    expect($second->amount)->toBe('0.00000000');
    $second->forceFill(['status' => 'EXPIRED'])->save();
    $card->forceFill(['balance_limit' => '120'])->save();
    $provider->shouldReceive('quoteCardLoad')->once()->with($card->provider_card_id, '20.00000000', Mockery::any())->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '20.00000000', '20.00000000', '0.00000000'));
    $provider->shouldReceive('confirmCardLoad')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'TX-SPLIT-OVERFLOW', '20.00000000', '20.00000000', '0.00000000'));
    $third = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '80');
    expect($third->amount)->toBe('20.00000000')->and($third->manual_funding_amount)->toBe('60.00000000');
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $third->id);
    $query = app(UserCardTransactionsQuery::class);
    $before = $query->get($this->tenant->id, $this->user->id, $card->id, 1)['items'];
    $ids = app(RecordCardTransactionsAction::class)->execute($card, [new ProviderCardTransactionDTO('TX-SPLIT-OVERFLOW', '20.00000000', 'USD', 'transfer_in', 'completed', now()->format('Y-m-d H:i:s'), null, '-0.20000000', 'USD')], CarbonImmutable::now());
    $after = $query->get($this->tenant->id, $this->user->id, $card->id, 1)['items'];
    $withoutFees = fn (array $items) => array_map(fn ($item) => array_diff_key($item, array_flip(['feeAmount', 'feeCurrency'])), $items);
    expect($withoutFees($after))->toBe($withoutFees($before));
    expect(collect($after)->where('feeAmount', '-0.20000000'))->toHaveCount(1);
    $synced = $query->items($this->tenant->id, $this->user->id, $card->id, $ids);
    expect($synced[0]['feeAmount'])->toBe('-0.20000000')->and($synced[0]['feeCurrency'])->toBe('USD');
    expect($synced[0]['amount'])->toBe('80.00000000')->and(collect($before)->pluck('id')->all())->toContain($synced[0]['id']);
    expect($card->fresh()->overflowBalance())->toBe('140.00000000');
    DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
});

// Physical-card fixtures use fake HTTP only; no external card or wallet is touched.
function physicalCardFixture($test): array
{
    $test->product->forceFill(['provider_product_ref' => '53493435'])->save();
    phaseTenReadyUser($test);
    $test->product->forceFill(['supported_form_factors' => ['virtual_card', 'physical_card']])->save();
    $holder = $test->holder->replicate();
    $holder->forceFill(['form_factor' => 'physical_card', 'request_id' => (string) Str::uuid(), 'provider_cardholder_id' => 'CH-PHYSICAL-OWNED'])->save();
    $test->holder = $holder;
    $key = openssl_pkey_new(['private_key_bits' => 2048]);
    openssl_pkey_export($key, $private);
    app()->instance(CardProviderInterface::class, new PhotonPayCardProvider(
        'https://x-api.photonpay.com', 'test-app', 'test-secret', $private, 'USD-ACCOUNT', null, null, 10, new PhotonPayCardResponseNormalizer));
    Http::preventStrayRequests();

    return ['request_id' => (string) Str::uuid(), 'cardholder_application_id' => $holder->id,
        'recipientFirstName' => 'Sandbox', 'recipientLastName' => 'Test', 'mobilePrefix' => '1', 'mobile' => '2025550100',
        'country' => 'US', 'state' => 'NY', 'city' => 'New York', 'addressLine1' => '1 Test Street', 'postalCode' => '10001'];
}

function fakePhysicalHttp(string $status = 'unactivated'): void
{
    Http::fake([
        '*addRecipient' => Http::response(['code' => '0000', 'data' => ['recipientId' => 'RI-PHYSICAL', 'recipientStatus' => 'Normal']]),
        '*pagingRecipient*' => Http::response(['code' => '0000', 'data' => [['recipientId' => 'RI-PHYSICAL', 'recipientStatus' => 'Normal']]]),
        '*getCardBin*' => Http::response(['code' => '0000', 'data' => [['cardBin' => CardProduct::where('provider', 'PHOTONPAY')->firstOrFail()->provider_product_ref, 'cardScheme' => 'MasterCard', 'cardType' => 'recharge', 'cardCurrency' => 'USD', 'cardFormFactor' => 'physical_card,virtual_card']]]),
        '*openCard' => function ($r) {
            return Http::response(['code' => '0000', 'data' => ['status' => 'succeed', 'requestId' => $r['requestId'], 'cardDetail' => [
                'cardId' => 'XR-PHYSICAL', 'cardType' => 'recharge', 'cardFormFactor' => 'physical_card', 'cardCurrency' => 'USD', 'maskCardNo' => '**** 1234', 'cardStatus' => 'unactivated', 'cardBalance' => '20']]]);
        },
        '*getCardDetail*' => Http::response(['code' => '0000', 'data' => ['cardId' => 'XR-PHYSICAL', 'cardType' => 'recharge', 'cardFormFactor' => 'physical_card', 'cardCurrency' => 'USD', 'maskCardNo' => '**** 1234', 'cardStatus' => $status, 'cardBalance' => '20', 'produceStatus' => 'produced']]),
        '*activateCard' => Http::response(['code' => '0000']),
    ]);
}

it('scopes and snapshots physical recipients and refuses identity rewrites', function () {
    $input = physicalCardFixture($this);
    fakePhysicalHttp();
    $action = app(CreateCardRecipientAction::class);
    $recipient = $action->execute($this->tenant->id, $this->user->id, $input);
    expect($recipient->status)->toBe('READY')->and($recipient->materials_encrypted)->not->toContain('Test Street');
    expect($action->execute($this->tenant->id, $this->user->id, $input)->id)->toBe($recipient->id);
    Http::assertSentCount(2);
    expect(fn () => $action->execute($this->tenant->id, $this->user->id, [...$input, 'city' => 'Other']))->toThrow(DomainException::class);
    $order = app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $this->holder->id, null, 'physical_card', $recipient->id);
    expect($order->status)->toBe(CardIssueStatus::Succeeded)->and($order->recipient_snapshot_encrypted)->toBe($recipient->materials_encrypted);
    $card = UserCard::where('card_issue_order_id', $order->id)->sole();
    expect($card->form_factor)->toBe('physical_card')->and($card->provider_status)->toBe('unactivated');
    expect(fn () => DB::transaction(fn () => DB::table('user_cards')->where('id', $card->id)->update(['form_factor' => 'virtual_card'])))->toThrow(QueryException::class);
    expect(fn () => DB::transaction(fn () => DB::table('card_issue_orders')->where('id', $order->id)->update(['provider_recipient_id' => 'RI-FOREIGN'])))->toThrow(QueryException::class);
    expect(fn () => DB::transaction(fn () => DB::table('card_recipient_applications')->where('id', $recipient->id)->update(['materials_encrypted' => 'changed'])))->toThrow(QueryException::class);
});

it('retains unknown recipient creation and blocks a new UUID without another upstream submission', function () {
    $input = physicalCardFixture($this);
    Http::fake(['*addRecipient' => Http::response(['code' => 'system-error'], 503)]);
    $action = app(CreateCardRecipientAction::class);
    $r = $action->execute($this->tenant->id, $this->user->id, $input);
    expect($r->status)->toBe('UNKNOWN');
    expect($action->execute($this->tenant->id, $this->user->id, $input)->id)->toBe($r->id);
    expect(fn () => $action->execute($this->tenant->id, $this->user->id, [...$input, 'request_id' => (string) Str::uuid()]))->toThrow(DomainException::class);
    Http::assertSentCount(1);
});

it('blocks physical issue without an owned ready recipient before financial holds', function () {
    physicalCardFixture($this);
    fakePhysicalHttp();
    $entries = LedgerEntry::count();
    expect(fn () => app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $this->holder->id, null, 'physical_card', (string) Str::uuid()))->toThrow(DomainException::class);
    expect(LedgerEntry::count())->toBe($entries);
    Http::assertNothingSent();
});

it('never resends an accepted but unconfirmed physical activation and completes by authoritative read', function () {
    $input = physicalCardFixture($this);
    fakePhysicalHttp();
    $r = app(CreateCardRecipientAction::class)->execute($this->tenant->id, $this->user->id, $input);
    $order = app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $this->holder->id, null, 'physical_card', $r->id);
    $card = UserCard::where('card_issue_order_id', $order->id)->sole();
    $action = app(ActivatePhysicalCardAction::class);
    expect($action->execute($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '05/29', '246810', '246810'))->toBe('UNKNOWN');
    expect($action->execute($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '05/29', '135790', '135790'))->toBe('UNKNOWN');
    expect(Http::recorded(fn ($r) => str_ends_with($r->url(), '/activateCard'))->count())->toBe(1);
    $saved = json_encode(DB::table('card_activation_attempts')->first());
    expect($saved)->not->toContain('246810')->not->toContain('135790');
    Http::swap(new Factory);
    Http::preventStrayRequests();
    fakePhysicalHttp('normal');
    app(RefreshManagedCardAction::class)->execute($this->tenant->id, $this->user->id, $card->id);
    expect(DB::table('card_activation_attempts')->where('card_id', $card->id)->value('status'))->toBe('SUCCEEDED');
});

it('validates recipient fields and rejects upstream references without calling the provider', function () {
    physicalCardFixture($this);
    $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/cards/recipients', [
        'request_id' => (string) Str::uuid(), 'cardholder_application_id' => $this->holder->id, 'recipientId' => 'RI-FOREIGN',
    ])->assertUnprocessable()->assertJsonValidationErrors(['recipientFirstName', 'addressLine1', 'recipientId']);
    Http::assertNothingSent();
});

it('requires sensitive authentication for activation and never flashes PIN inputs', function () {
    physicalCardFixture($this);
    $pin = '76543210';
    $response = $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/cards/'.Str::uuid().'/activate', [
        'request_id' => (string) Str::uuid(), 'pin' => $pin, 'pin_confirmation' => $pin, 'expiration_date' => '05/29',
    ]);
    $response->assertUnprocessable()->assertJsonValidationErrors(['current_password', 'confirmed']);
    expect($response->getContent())->not->toContain($pin);
    expect(json_encode(session()->all()))->not->toContain($pin);
    Http::assertNothingSent();
});

it('keeps physical issue holds on uncertain results and releases explicit rejection', function (string $outcome) {
    $input = physicalCardFixture($this);
    fakePhysicalHttp();
    $r = app(CreateCardRecipientAction::class)->execute($this->tenant->id, $this->user->id, $input);
    Http::swap(new Factory);
    Http::preventStrayRequests();
    Http::fake(['*getCardBin*' => Http::response(['code' => '0000', 'data' => [['cardBin' => '53493435', 'cardScheme' => 'MasterCard', 'cardType' => 'recharge', 'cardCurrency' => 'USD', 'cardFormFactor' => 'physical_card']]]),
        '*openCard' => $outcome === 'rejected' ? Http::response(['code' => 'VCC1010', 'message' => 'rejected']) : Http::failedConnection()]);
    $order = app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $this->holder->id, null, 'physical_card', $r->id);
    expect($order->status->value)->toBe($outcome === 'rejected' ? 'FAILED' : 'UNKNOWN');
    expect(phaseTenAccount($this, LedgerAccountType::UserCardFundingHold)->balance)->toBe($outcome === 'rejected' ? '0.00000000' : '20.00000000');
    expect(UserCard::where('card_issue_order_id', $order->id)->exists())->toBeFalse();
})->with(['rejected', 'timeout']);

it('preserves physical activation timeout and explicit rejection without a repeated upstream call', function (string $outcome) {
    $input = physicalCardFixture($this);
    fakePhysicalHttp();
    $r = app(CreateCardRecipientAction::class)->execute($this->tenant->id, $this->user->id, $input);
    $order = app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $this->holder->id, null, 'physical_card', $r->id);
    $card = UserCard::where('card_issue_order_id', $order->id)->sole();
    Http::swap(new Factory);
    Http::preventStrayRequests();
    Http::fake(['*getCardDetail*' => Http::response(['code' => '0000', 'data' => ['cardId' => 'XR-PHYSICAL', 'cardType' => 'recharge', 'cardFormFactor' => 'physical_card', 'cardCurrency' => 'USD', 'maskCardNo' => '**** 1234', 'cardStatus' => 'unactivated', 'cardBalance' => '20']]),
        '*activateCard' => $outcome === 'rejected' ? Http::response(['code' => 'VCC1010', 'message' => 'rejected']) : Http::failedConnection()]);
    $action = app(ActivatePhysicalCardAction::class);
    $request = (string) Str::uuid();
    $expected = $outcome === 'rejected' ? 'FAILED' : 'UNKNOWN';
    expect($action->execute($this->tenant->id, $this->user->id, $card->id, $request, '05/29', '234567', '234567'))->toBe($expected);
    expect($action->execute($this->tenant->id, $this->user->id, $card->id, $request, '05/29', '234567', '234567'))->toBe($expected);
    expect(Http::recorded(fn ($r) => str_ends_with($r->url(), '/activateCard'))->count())->toBe(1);
    expect($card->fresh()->provider_status)->toBe('unactivated');
})->with(['rejected', 'timeout']);

it('rejects foreign physical holder ownership and recipient merchant identity changes', function () {
    $input = physicalCardFixture($this);
    fakePhysicalHttp();
    $r = app(CreateCardRecipientAction::class)->execute($this->tenant->id, $this->user->id, $input);
    $this->actingAs($this->user, 'tenant_user')->postJson('http://a.localhost/cards/recipients', [...$input, 'request_id' => (string) Str::uuid(), 'cardholder_application_id' => (string) Str::uuid()])->assertNotFound();
    expect(fn () => DB::transaction(fn () => DB::table('card_recipient_applications')->where('id', $r->id)->update(['card_provider_reference_id' => (string) Str::uuid()])))->toThrow(QueryException::class);
    expect(fn () => DB::transaction(fn () => DB::table('card_recipient_applications')->where('id', $r->id)->update(['user_id' => (string) Str::uuid()])))->toThrow(QueryException::class);
    expect(fn () => DB::transaction(fn () => DB::table('card_recipient_applications')->where('id', $r->id)->update(['tenant_id' => (string) Str::uuid()])))->toThrow(QueryException::class);
});

it('refreshes physical cards from verified notification records without changing Ledger', function () {
    $input = physicalCardFixture($this);
    fakePhysicalHttp();
    $r = app(CreateCardRecipientAction::class)->execute($this->tenant->id, $this->user->id, $input);
    $order = app(CreateCardIssueAction::class)->execute($this->tenant->id, $this->user->id, (string) Str::uuid(), $this->product->id, '20', $this->holder->id, null, 'physical_card', $r->id);
    $card = UserCard::where('card_issue_order_id', $order->id)->sole();
    $event = new CardProviderEvent;
    $event->forceFill(['tenant_id' => $this->tenant->id, 'user_id' => $this->user->id, 'card_id' => $card->id, 'event_digest' => hash('sha256', 'physical-notification'), 'category' => 'issuing_card', 'event_type' => 'activate', 'status' => 'PENDING'])->save();
    $entries = LedgerEntry::count();
    Http::swap(new Factory);
    fakePhysicalHttp('normal');
    app(ProcessCardNotificationAction::class)->execute($this->tenant->id, $event->id);
    expect($event->fresh()->status)->toBe('PROCESSED')->and($card->fresh()->provider_status)->toBe('normal')->and(LedgerEntry::count())->toBe($entries);
});

it('reads platform operation history without provider availability and preserves ownership and mutation guards', function (): void {
    [$card,$provider,$manage] = managedCardFixture($this);
    $provider->shouldReceive('quoteCardLoad')->once()->andReturnUsing(fn ($id, $amount, $request) => new ProviderCardQuoteDTO($request, '21.00000000', '20.00000000', '1.00000000'));
    $order = $manage->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '20');
    app()->instance(CardProviderInterface::class, new UnavailableCardProvider);
    Http::preventStrayRequests();
    $entries = LedgerEntry::count();
    $url = 'http://a.localhost/cards/'.$card->id.'/management';
    $this->actingAs($this->user, 'tenant_user')->postJson($url, ['action' => 'history'])
        ->assertOk()->assertJsonPath('orders.0.id', $order->id)->assertJsonPath('orders.0.state', 'quoted');
    $this->postJson($url, ['action' => 'refresh'])->assertStatus(503);
    $other = User::where('tenant_id', '!=', $this->tenant->id)->firstOrFail();
    $this->actingAs($other, 'tenant_user')->postJson('http://b.localhost/cards/'.$card->id.'/management', ['action' => 'history'])->assertNotFound();
    expect(LedgerEntry::count())->toBe($entries)->and($order->fresh()->status)->toBe('QUOTED');
    Http::assertNothingSent();
});

it('allows password verified platform card reveal with scoped no store and safe audit', function (): void {
    [$card, $provider] = managedCardFixture($this);
    $provider->shouldReceive('revealCard')->once()->andReturn(new ProviderSensitiveCardDTO('411111111111'.$card->last4, '987', false, '08/29'));
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $this->actingAs($actor, 'platform_admin');
    $url = 'http://admin.localhost/platform/tenants/'.$card->tenant_id.'/cards/'.$card->id.'/reveal';
    $this->postJson($url, ['password' => 'incorrect'])->assertForbidden();
    $other = Tenant::where('id', '<>', $card->tenant_id)->firstOrFail();
    $this->postJson('http://admin.localhost/platform/tenants/'.$other->id.'/cards/'.$card->id.'/reveal', ['password' => 'local-password'])->assertNotFound();
    $this->postJson($url, ['password' => 'local-password'])->assertOk()
        ->assertExactJson(['pan' => '411111111111'.$card->last4, 'cvv' => '987', 'expiry' => '08/29'])
        ->assertHeader('Cache-Control', 'no-store, private');
    expect(json_encode(AuditLog::where('action', 'CARD_CVV_VIEWED')->get()))->not->toContain('411111111111', '987');
});

it('includes confirmed card balances and overflow once in assets without provider reads', function (): void {
    [$card, $provider, $action] = managedCardFixture($this, available: '200');
    $card->forceFill(['balance_limit' => '20'])->save();
    $order = $action->quote($this->tenant->id, $this->user->id, $card->id, (string) Str::uuid(), '80');
    $action->confirmLoad($this->tenant->id, $this->user->id, $card->id, $order->id);
    $provider->shouldNotReceive('getCard');
    Http::fake();
    $entries = LedgerEntry::count();
    $query = app(AssetOverviewQuery::class);
    $wallet = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $expected = Money::of($wallet, 'USDT')->add(Money::of('110', 'USDT'))->amount(); // 10 deposit + 20 provider + 80 overflow.
    expect($query->get($this->tenant->id, $this->user->id, [])['estimate'])->toBe($expected);
    $card->forceFill(['provider_status' => 'frozen'])->save();
    expect($query->get($this->tenant->id, $this->user->id, [])['estimate'])->toBe($expected);
    $other = Tenant::where('slug', 'tenant-b')->firstOrFail();
    $otherUser = User::where('tenant_id', $other->id)->firstOrFail();
    expect($query->get($other->id, $otherUser->id, [])['estimate'])->toBe('0.00000000');
    expect(fn () => $query->get($other->id, $this->user->id, []))->toThrow(ModelNotFoundException::class);
    $card->forceFill(['provider_balance' => null])->save();
    expect($query->get($this->tenant->id, $this->user->id, [])['estimate'])->toBeNull();
    $card->forceFill(['archived_at' => now()])->save();
    expect($query->get($this->tenant->id, $this->user->id, [])['estimate'])->toBe(Money::of($wallet, 'USDT')->add(Money::of('10', 'USDT'))->amount());
    expect(LedgerEntry::count())->toBe($entries);
    Http::assertNothingSent();
});

it('persists provider fees and returns them on read-only scoped card history', function (): void {
    [$card] = transactionReadFixture($this);
    app(RecordCardTransactionsAction::class)->execute($card, [
        new ProviderCardTransactionDTO('FEE-READ', '25.00000000', 'CNY', 'purchase', 'completed', '2026-09-29T09:00:00', null, '-0.12345678', 'USD', '0.01000000', 'CNY'),
    ], CarbonImmutable::now());
    Http::preventStrayRequests();
    $this->actingAs($this->user, 'tenant_user')->getJson("http://a.localhost/cards/{$card->id}/transactions")
        ->assertOk()->assertJsonPath('items.0.feeAmount', '-0.12345678')->assertJsonPath('items.0.feeCurrency', 'USD')
        ->assertJsonPath('items.0.feeReturnAmount', '0.01000000')->assertJsonPath('items.0.feeReturnCurrency', 'CNY')
        ->assertJsonPath('items.0.currency', 'CNY');
    Http::assertNothingSent();
});

it('manually syncs platform card transaction pages with audit and without money changes', function (): void {
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldReceive('getTransactionPage')->with('XR-TRANSACTION-FIXTURE', 1, 20)->twice()
        ->andReturn(new ProviderTransactionPageDTO([
            new ProviderCardTransactionDTO('PLATFORM-SYNC', '12.34000000', 'USD', 'purchase', 'completed', '2026-09-11T09:05:04', 'Example shop'),
        ], 1, true));
    $provider->shouldReceive('getTransactionPage')->with('XR-TRANSACTION-FIXTURE', 2, 20)->once()
        ->andReturn(new ProviderTransactionPageDTO([], 2, false));
    $tables = ['user_cards', 'wallets', 'ledger_accounts', 'ledger_entries', 'ledger_postings'];
    $before = collect($tables)->mapWithKeys(fn ($table) => [$table => DB::table($table)->orderBy('id')->get()->toJson()]);
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $url = "http://admin.localhost/platform/tenants/{$this->tenant->id}/cards/{$card->id}/transactions";
    $this->actingAs($platform, 'platform_admin')->getJson($url)->assertOk()->assertJsonCount(0, 'items');
    foreach ([1, 1, 2] as $page) {
        $this->postJson($url.'/sync', ['page' => $page])->assertOk()
            ->assertHeader('Cache-Control', 'no-store, private')->assertExactJson(['page' => $page, 'hasMore' => $page === 1]);
    }
    $this->getJson($url)->assertOk()->assertJsonCount(1, 'items')->assertJsonPath('items.0.amount', '12.34000000');
    expect(DB::table('audit_logs')->where('action', 'CARD_TRANSACTIONS_SYNCED')->where('actor_id', $platform->id)->where('resource_id', $card->id)->count())->toBe(3);
    foreach ($tables as $table) {
        expect(DB::table($table)->orderBy('id')->get()->toJson())->toBe($before[$table]);
    }
});

it('guards platform transaction sync scope selectors and management permission', function (): void {
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldNotReceive('getTransactionPage');
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $url = "http://admin.localhost/platform/tenants/{$this->tenant->id}/cards/{$card->id}/transactions/sync";
    $this->actingAs($platform, 'platform_admin');
    $other = Tenant::query()->where('id', '!=', $this->tenant->id)->firstOrFail();
    $this->postJson("http://admin.localhost/platform/tenants/{$other->id}/cards/{$card->id}/transactions/sync")->assertNotFound();
    foreach (['page' => 0, 'tenant_id' => $other->id, 'user_id' => $this->user->id, 'provider_card_id' => 'other', 'page_size' => 1000] as $key => $value) {
        $this->postJson($url, [$key => $value])->assertUnprocessable();
    }
    DB::table('role_permissions')->where('permission_id', DB::table('permissions')->where('name', 'card_product.manage')->value('id'))->delete();
    $this->actingAs($platform->fresh(), 'platform_admin')->postJson($url)->assertForbidden();
});

it('keeps stored platform transactions readable when manual provider sync fails', function (): void {
    Log::spy();
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldReceive('getTransactionPage')->once()->andThrow(new ProviderUnknownResultException('secret-provider-details'));
    app(RecordCardTransactionsAction::class)->execute($card, [
        new ProviderCardTransactionDTO('PLATFORM-OFFLINE', '1.00000000', 'USD', 'purchase', 'completed', '2026-09-11T09:05:04', null),
    ], CarbonImmutable::now());
    $platform = AdminUser::query()->where('email', 'owner@platform.local')->firstOrFail();
    $url = "http://admin.localhost/platform/tenants/{$this->tenant->id}/cards/{$card->id}/transactions";
    $response = $this->actingAs($platform, 'platform_admin')->postJson($url.'/sync')->assertStatus(503);
    expect($response->getContent())->not->toContain('secret-provider-details');
    Log::shouldHaveReceived('warning')->once()->with('Card transaction sync failed', Mockery::on(fn (array $context): bool => $context['card_id'] === $card->id && $context['failure'] === 'unknown_result' && is_string($context['request_id']) && ! str_contains(json_encode($context), 'secret-provider-details')));
    $this->getJson($url)->assertOk()->assertJsonCount(1, 'items');
});

function transactionBatchInput($test): array
{
    return ['tenant_id' => $test->tenant->id, 'date_from' => '2026-10-03', 'date_to' => '2026-10-03', 'request_id' => (string) Str::uuid()];
}

it('bulk syncs every page with Beijing boundaries and resumes without financial side effects', function () {
    $this->travelTo(CarbonImmutable::parse('2026-10-04T08:00:00+08:00'));
    [$card, $provider] = transactionReadFixture($this);
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $input = transactionBatchInput($this);
    $batch = $sync->create($actor, $input);
    expect($sync->create($actor, $input))->toBe($batch);
    $id = DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id');
    $tables = ['user_cards', 'wallets', 'ledger_accounts', 'ledger_entries', 'ledger_postings'];
    $before = collect($tables)->mapWithKeys(fn ($table) => [$table => DB::table($table)->orderBy('id')->get()->toJson()]);
    $baseLevel = DB::transactionLevel();
    $provider->shouldReceive('getTransactionPage')->with($card->provider_card_id, 1, 20)->once()->andReturnUsing(function () use ($baseLevel) {
        expect(DB::transactionLevel())->toBe($baseLevel);

        return new ProviderTransactionPageDTO([
            new ProviderCardTransactionDTO('BATCH-OLD', '1.00000000', 'USD', 'purchase', 'completed', '2026-10-02T23:59:59', null),
            new ProviderCardTransactionDTO('BATCH-START', '2.00000000', 'USD', 'purchase', 'completed', '2026-10-03T00:00:00', null, '-0.10000000', 'USD'),
            ...array_map(fn ($n) => new ProviderCardTransactionDTO('BATCH-OUTSIDE-'.$n, '1.00000000', 'USD', 'purchase', 'completed', '2026-10-01T00:00:00', null), range(1, 18)),
        ], 1, true);
    });
    $provider->shouldReceive('getTransactionPage')->with($card->provider_card_id, 2, 20)->once()->andReturn(new ProviderTransactionPageDTO([
        new ProviderCardTransactionDTO('BATCH-END', '3.00000000', 'EUR', 'purchase', 'completed', '2026-10-03T23:59:59', null),
        new ProviderCardTransactionDTO('BATCH-NEXT', '4.00000000', 'USD', 'purchase', 'completed', '2026-10-04T00:00:00', null),
    ], 2, false));
    $sync->process($id);
    $sync->process($id); // Immediate duplicate cannot skip the one-second gate.
    expect(DB::table('card_transaction_sync_items')->where('id', $id)->value('next_page'))->toBe(2);
    $this->travel(2)->seconds();
    $sync->process($id);
    $sync->process($id); // A completed item never replays.
    $row = DB::table('card_transaction_sync_items')->where('id', $id)->first();
    expect($row->status)->toBe('SUCCEEDED')->and($row->pages_processed)->toBe(2)->and($row->records_written)->toBe(2)
        ->and(CardTransaction::where('card_id', $card->id)->pluck('provider_transaction_id')->all())->toEqualCanonicalizing(['BATCH-START', 'BATCH-END']);
    foreach ($tables as $table) {
        expect(DB::table($table)->orderBy('id')->get()->toJson())->toBe($before[$table]);
    }
    $this->actingAs($actor, 'platform_admin')->getJson('http://admin.localhost/platform/card-transaction-batches/'.$batch)
        ->assertOk()->assertJsonPath('status', 'COMPLETED')->assertJsonPath('counts.succeeded', 1);
});

it('bulk sync retries transient reads with persisted delays and manual retry starts failed cards at page one', function () {
    $this->travelTo(CarbonImmutable::now()->startOfSecond());
    [$card, $provider] = transactionReadFixture($this);
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $batch = $sync->create($actor, transactionBatchInput($this));
    $id = DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id');
    $provider->shouldReceive('getTransactionPage')->times(4)->andThrow(new ProviderRateLimitException('PRIVATE-TOKEN'));
    foreach ([30, 120, 300] as $delay) {
        $started = CarbonImmutable::now();
        $sync->process($id);
        $row = DB::table('card_transaction_sync_items')->where('id', $id)->first();
        expect($row->status)->toBe('PENDING')->and($row->error_code)->toBe('provider_rate_limit');
        expect((int) $started->diffInSeconds(CarbonImmutable::parse($row->next_attempt_at)))->toBe($delay);
        $this->travelTo(CarbonImmutable::parse($row->next_attempt_at)->addSecond());
    }
    $sync->process($id);
    expect(DB::table('card_transaction_sync_items')->where('id', $id)->value('status'))->toBe('FAILED');
    $sync->retry($actor, $batch);
    $this->travel(2)->seconds();
    $provider->shouldReceive('getTransactionPage')->once()->andReturn(new ProviderTransactionPageDTO([], 1, false));
    $sync->process($id);
    expect(DB::table('card_transaction_sync_items')->where('id', $id)->value('status'))->toBe('SUCCEEDED');
});

it('bulk sync endpoints validate scope dates permissions and idempotency', function () {
    $this->withoutMiddleware(ThrottleRequests::class);
    $this->travelTo(CarbonImmutable::parse('2026-10-04T08:00:00+08:00'));
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldNotReceive('getTransactionPage');
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $base = 'http://admin.localhost/platform/card-transaction-batches';
    $input = transactionBatchInput($this);
    $this->actingAs($this->owner, 'platform_admin')->postJson($base, $input)->assertForbidden();
    $this->actingAs($actor, 'platform_admin')->getJson($base.'/preview?tenant_id='.$this->tenant->id)->assertOk()->assertJsonPath('eligible', 1);
    $other = Tenant::where('id', '<>', $this->tenant->id)->firstOrFail();
    $this->getJson($base.'/preview?tenant_id='.$other->id)->assertOk()->assertJsonPath('total', 0);
    $this->postJson($base, array_replace($input, ['date_to' => '2026-10-05']))->assertUnprocessable();
    $this->postJson($base, array_replace($input, ['date_from' => '2025-01-01']))->assertUnprocessable();
    $batch = $this->postJson($base, $input)->assertStatus(202)->json('id');
    $this->postJson($base, $input)->assertStatus(202)->assertJsonPath('id', $batch);
    $this->postJson($base, array_replace($input, ['date_from' => '2026-10-02']))->assertStatus(409);
    $this->getJson($base.'/'.$batch)->assertOk()->assertJsonPath('counts.total', 1);
    $sync = app(BatchCardTransactionSync::class);
    $actor->update(['status' => 'SUSPENDED']);
    $sync->process(DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id'));
    expect(DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('error_code'))->toBe('permission_revoked');
});

it('bulk sync skips unsupported bindings and rejects invalid provider transaction dates without writing a page', function () {
    [$card, $provider] = transactionReadFixture($this);
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $unbound = new UserCard;
    $unbound->forceFill(['provider' => 'OTHER', 'provider_card_id' => '']);
    expect($sync->eligible($unbound))->toBeFalse();
    $batch = $sync->create($actor, transactionBatchInput($this));
    $provider->shouldReceive('getTransactionPage')->once()->andReturn(new ProviderTransactionPageDTO([
        new ProviderCardTransactionDTO('BATCH-BAD', '1.00000000', 'USD', 'purchase', 'completed', '2026-02-30T12:00:00', null),
    ], 1, false));
    $sync->process(DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id'));
    expect(DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('error_code'))->toBe('invalid_transaction_time')
        ->and(CardTransaction::where('card_id', $card->id)->count())->toBe(0);
});

it('bulk sync includes frozen and cancelled cards and serializes overlapping batches', function () {
    [$card, $provider] = transactionReadFixture($this);
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $card->forceFill(['provider_status' => 'frozen'])->save();
    $first = $sync->create($actor, transactionBatchInput($this));
    $card->forceFill(['provider_status' => 'cancelled', 'archived_at' => now()])->save();
    $second = $sync->create($actor, array_replace(transactionBatchInput($this), ['tenant_id' => null]));
    expect($sync->preview(null)['eligible'])->toBe(1);
    $ids = collect([$first, $second])->map(fn ($batch) => DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id'));
    $provider->shouldReceive('getTransactionPage')->twice()->andReturn(new ProviderTransactionPageDTO([
        new ProviderCardTransactionDTO('BATCH-REPEAT', '1.00000000', 'USD', 'purchase', 'completed', '2026-10-03T12:00:00', null),
    ], 1, false));
    $sync->process($ids[0]);
    $sync->process($ids[1]);
    expect(DB::table('card_transaction_sync_items')->where('id', $ids[1])->value('status'))->toBe('PENDING');
    $this->travel(2)->seconds();
    $sync->process($ids[1]);
    expect(DB::table('card_transaction_sync_items')->where('id', $ids[1])->value('status'))->toBe('SUCCEEDED')
        ->and(CardTransaction::where('card_id', $card->id)->count())->toBe(1);
});

it('bulk sync stops changed bindings and exhausted interrupted workers before provider calls', function () {
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldNotReceive('getTransactionPage');
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    foreach (['binding_changed', 'worker_timeout'] as $reason) {
        $batch = $sync->create($actor, transactionBatchInput($this));
        $id = DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id');
        DB::table('card_transaction_sync_items')->where('id', $id)->update($reason === 'binding_changed' ? ['binding_hash' => str_repeat('0', 64)] : ['failures' => 4]);
        $sync->process($id);
        expect(DB::table('card_transaction_sync_items')->where('id', $id)->value('error_code'))->toBe($reason);
    }
});

it('bulk sync rejects incomplete pagination without treating it as empty success', function () {
    [$card, $provider] = transactionReadFixture($this);
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $batch = $sync->create($actor, transactionBatchInput($this));
    $provider->shouldReceive('getTransactionPage')->once()->andReturn(new ProviderTransactionPageDTO([], 1, true));
    $sync->process(DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id'));
    expect(DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('error_code'))->toBe('invalid_pagination');
});

it('selected card sync validates exact scope and persists canonical idempotent selection', function () {
    $this->withoutMiddleware(ThrottleRequests::class);
    $this->travelTo(CarbonImmutable::parse('2026-10-04T08:00:00+08:00'));
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldReceive('issueCard')->once()->andReturnUsing(function ($request) {
        $result = new ProviderCardDTO('XR-SECOND-TRANSACTION-FIXTURE', '', '•••• 8888', '8888', 8, 2029, 'USD', 'normal', false, '20.00000000');

        return new ProviderOperationDTO($request->idempotencyKey, ProviderOperationStatus::Succeeded, $result->providerCardId, card: $result);
    });
    $this->holder = phaseTenHolder($this);
    $secondOrder = phaseTenIssue($this);
    $second = UserCard::where('card_issue_order_id', $secondOrder->id)->firstOrFail();
    $provider->shouldNotReceive('getTransactionPage');
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $base = 'http://admin.localhost/platform/card-transaction-batches';
    $input = transactionBatchInput($this) + ['card_ids' => [$card->id]];
    $this->actingAs($actor, 'platform_admin');
    $this->postJson($base.'/preview', ['tenant_id' => $this->tenant->id, 'card_ids' => [$card->id]])->assertOk()->assertJsonPath('total', 1);
    expect(DB::table('card_transaction_sync_batches')->count())->toBe(0);
    $otherTenant = Tenant::where('id', '<>', $this->tenant->id)->firstOrFail();
    $this->postJson($base, array_replace($input, ['tenant_id' => $otherTenant->id]))->assertUnprocessable();
    $this->postJson($base, array_replace($input, ['card_ids' => []]))->assertUnprocessable();
    $this->postJson($base, array_replace($input, ['card_ids' => [$card->id, strtoupper($card->id)]]))->assertUnprocessable();
    $this->postJson($base, array_replace($input, ['card_ids' => [(string) Str::uuid()]]))->assertUnprocessable();
    $batch = $this->postJson($base, $input)->assertAccepted()->json('id');
    expect(DB::table('card_transaction_sync_items')->where('batch_id', $batch)->pluck('card_id')->all())->toBe([$card->id]);
    $this->postJson($base, array_replace($input, ['card_ids' => [strtoupper($card->id)]]))->assertAccepted()->assertJsonPath('id', $batch);
    $this->postJson($base, array_replace($input, ['card_ids' => [$second->id]]))->assertStatus(409);
    $this->postJson($base, array_diff_key($input, ['card_ids' => true]))->assertStatus(409);
    $input['request_id'] = (string) Str::uuid();
    $input['card_ids'] = [$second->id, $card->id];
    $both = $this->postJson($base, $input)->assertAccepted()->json('id');
    $input['card_ids'] = array_reverse($input['card_ids']);
    $this->postJson($base, $input)->assertAccepted()->assertJsonPath('id', $both);
    $listed = collect($this->getJson($base)->assertOk()->json('items'))->firstWhere('id', $both);
    expect($listed['scope'])->toBe('selected')->and($listed['counts']['total'])->toBe(2)->and($listed['status'])->toBe('RUNNING');
});

it('selected card sync restores progress and reports last success without changing funds', function () {
    $this->travelTo(CarbonImmutable::parse('2026-10-04T08:00:00+08:00'));
    [$card, $provider] = transactionReadFixture($this);
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $batch = $sync->create($actor, transactionBatchInput($this) + ['card_ids' => [$card->id]]);
    $item = DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id');
    $before = LedgerEntry::count();
    $wallet = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $provider->shouldReceive('getTransactionPage')->once()->andReturn(new ProviderTransactionPageDTO([], 1, false));
    $query = app(PlatformCardQuery::class);
    expect($query->get($this->tenant->id)['cards']->items()[0]['lastTransactionSyncAt'])->toBeNull();
    $sync->process($item);
    $last = $query->get($this->tenant->id)['cards']->items()[0]['lastTransactionSyncAt'];
    expect($last)->toBe(CarbonImmutable::now()->toIso8601String());
    $this->actingAs($actor, 'platform_admin')->getJson('http://admin.localhost/platform/card-transaction-batches')->assertOk()
        ->assertJsonPath('items.0.status', 'COMPLETED')->assertJsonPath('items.0.counts.succeeded', 1)->assertJsonPath('items.0.counts.pages', 1);
    $failed = $sync->create($actor, transactionBatchInput($this) + ['card_ids' => [$card->id]]);
    DB::table('card_transaction_sync_items')->where('batch_id', $failed)->update(['status' => 'FAILED', 'updated_at' => now()->addMinute(), 'error_code' => 'provider_read_failed']);
    expect($query->get($this->tenant->id)['cards']->items()[0]['lastTransactionSyncAt'])->toBe($last)
        ->and(LedgerEntry::count())->toBe($before)->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($wallet);
    DB::table('card_transaction_sync_batches')->where('id', $failed)->update(['actor_id' => $this->owner->id]);
    $this->getJson('http://admin.localhost/platform/card-transaction-batches')->assertOk()->assertJsonCount(1, 'items');
    $this->getJson('http://admin.localhost/platform/card-transaction-batches/'.$failed)->assertNotFound();
    $this->postJson('http://admin.localhost/platform/card-transaction-batches/'.$failed.'/retry')->assertNotFound();
});

it('browser sync advances one checkpoint at a time and never dispatches queue work', function () {
    $this->withoutMiddleware(ThrottleRequests::class);
    $this->travelTo(CarbonImmutable::parse('2026-10-04T08:00:00+08:00'));
    [$card, $provider] = transactionReadFixture($this);
    Queue::fake();
    $calls = 0;
    $provider->shouldReceive('getTransactionPage')->twice()->andReturnUsing(function ($id, $page) use (&$calls) {
        $calls++;

        return new ProviderTransactionPageDTO([
            new ProviderCardTransactionDTO('BROWSER-'.$page, '1.00000000', 'USD', 'purchase', 'completed', '2026-10-03T12:00:00', null),
        ], $page, $page === 1);
    });
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $base = 'http://admin.localhost/platform/card-transaction-batches';
    $batch = $this->actingAs($actor, 'platform_admin')->postJson($base, transactionBatchInput($this) + ['card_ids' => [$card->id]])->assertAccepted()->json('id');
    $sync = app(BatchCardTransactionSync::class);
    $item = DB::table('card_transaction_sync_items')->where('batch_id', $batch)->value('id');
    $this->getJson($base)->assertOk()->assertJsonPath('items.0.execution_mode', 'browser');
    $this->getJson($base.'/'.$batch)->assertOk()->assertJsonPath('counts.pages', 0);
    expect($calls)->toBe(0);
    Queue::assertNothingPushed();
    $this->postJson($base.'/'.$batch.'/advance')->assertOk()->assertJsonPath('status', 'RUNNING');
    $this->postJson($base.'/'.$batch.'/advance')->assertOk()->assertJsonPath('status', 'RUNNING');
    expect($calls)->toBe(1);
    $this->travel(2)->seconds();
    // A new request resumes from the database, without the browser submitting a page number.
    $this->postJson($base.'/'.$batch.'/advance')->assertOk()->assertJsonPath('status', 'COMPLETED');
    $this->postJson($base.'/'.$batch.'/advance')->assertOk()->assertJsonPath('status', 'COMPLETED');
    expect($calls)->toBe(2)->and(CardTransaction::where('card_id', $card->id)->count())->toBe(2);
    Queue::assertNothingPushed();
    $this->actingAs($this->owner, 'platform_admin')->postJson($base.'/'.$batch.'/advance')->assertForbidden();
});

it('browser sync leaves rate limit backoff persisted for manual continuation without workers', function () {
    $this->travelTo(CarbonImmutable::parse('2026-10-04T08:00:00+08:00'));
    [$card, $provider] = transactionReadFixture($this);
    Queue::fake();
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $batch = $sync->create($actor, transactionBatchInput($this));
    $provider->shouldReceive('getTransactionPage')->once()->andThrow(new ProviderRateLimitException('synthetic'));
    $result = $sync->advance($actor, $batch);
    expect($result)->toMatchArray(['status' => 'RUNNING', 'waitMs' => 30000]);
    $sync->advance($actor, $batch); // Does not read again before the persisted backoff.
    $this->travel(31)->seconds();
    $provider->shouldReceive('getTransactionPage')->once()->andReturn(new ProviderTransactionPageDTO([], 1, false));
    expect($sync->advance($actor, $batch)['status'])->toBe('COMPLETED');
    Queue::assertNothingPushed();
});

it('retires legacy queue sync without changing historical checkpoints or dispatching jobs', function (string $status) {
    $this->travelTo(CarbonImmutable::parse('2026-10-10T08:00:00+08:00'));
    [$card, $provider] = transactionReadFixture($this);
    $provider->shouldNotReceive('getTransactionPage');
    Queue::fake();
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $sync = app(BatchCardTransactionSync::class);
    $input = transactionBatchInput($this) + ['card_ids' => [$card->id]];
    $batch = $sync->create($actor, $input);
    DB::table('card_transaction_sync_batches')->where('id', $batch)->update(['execution_mode' => 'queue']);
    DB::table('card_transaction_sync_items')->where('batch_id', $batch)->update(['status' => $status, 'next_page' => 3, 'pages_processed' => 2]);
    $item = DB::table('card_transaction_sync_items')->where('batch_id', $batch)->first();
    $before = (array) $item;
    $entries = LedgerEntry::count();
    $accounts = DB::table('card_transaction_sync_accounts')->get()->toJson();
    $audits = AuditLog::count();
    $sync->process($item->id); // Also rejects a call from an old still-present serialized handler.
    $base = 'http://admin.localhost/platform/card-transaction-batches';
    $this->actingAs($actor, 'platform_admin')->getJson($base)->assertOk()
        ->assertJsonPath('items.0.status', 'RETIRED')->assertJsonPath('items.0.execution_mode', 'queue');
    $this->getJson($base.'/'.$batch)->assertOk()->assertJsonPath('status', 'RETIRED')->assertJsonPath('counts.pages', 2);
    $this->postJson($base.'/'.$batch.'/advance')->assertStatus(409);
    $this->postJson($base.'/'.$batch.'/retry')->assertStatus(409);
    // Replaying the original request retains its binding; it never creates a replacement task.
    $this->postJson($base, $input)->assertAccepted()->assertJsonPath('id', $batch);
    expect((array) DB::table('card_transaction_sync_items')->where('id', $item->id)->first())->toBe($before)
        ->and(DB::table('card_transaction_sync_accounts')->get()->toJson())->toBe($accounts)
        ->and(LedgerEntry::count())->toBe($entries)->and(AuditLog::count())->toBe($audits);
    Queue::assertNothingPushed();
    expect(array_key_exists('cards:recover-transaction-sync', Artisan::all()))->toBeFalse();
    $commands = collect(app(Schedule::class)->events())->pluck('command')->implode('\n');
    expect($commands)->not->toContain('cards:recover-transaction-sync')->toContain('topups:scan-trc20');
})->with(['PENDING', 'FAILED']);

it('reads card layout funding returns consumption and archive totals without calling providers', function () {
    [$card,$provider,$action] = managedCardFixture($this, available: '200');
    $card->forceFill(['balance_limit'=>'20'])->save();
    $load = $action->quote($this->tenant->id,$this->user->id,$card->id,(string) Str::uuid(),'80');
    $action->confirmLoad($this->tenant->id,$this->user->id,$card->id,$load->id);
    $provider->shouldNotReceive('getCard');
    $query = app(\App\Application\User\PlatformUserCardsSummary::class);
    $v = $query->read($this->tenant->id,$this->user->id,false,1);
    $initial = $card->issueOrder->initial_load_amount;
    $funded = (string) \Brick\Math\BigDecimal::of($initial)->plus('80')->toScale(8);
    expect($v['items'][0]->funded)->toBe($funded);
    expect($v['items'][0]->balance)->toBe('100.00000000');
    expect($v['items'][0]->consumed)->toBe((string) \Brick\Math\BigDecimal::of($funded)->minus('100')->toScale(8));
    expect($query->read($this->tenant->id,$this->user->id,false,2)['totals'])->toBe($v['totals']);
    $entries = LedgerEntry::count();
    $this->actingAs(AdminUser::where('email','owner@platform.local')->firstOrFail(),'platform_admin');
    $url = 'http://admin.localhost/platform/tenants/'.$this->tenant->id.'/users/'.$this->user->id;
    $this->getJson($url.'/funds-summary')->assertOk()->assertJsonPath('estimate',app(AssetOverviewQuery::class)->get($this->tenant->id,$this->user->id,[])['estimate']);
    $this->getJson($url.'/cards-summary')->assertOk()->assertJsonPath('items.0.funded',$funded);
    $card->forceFill(['provider_balance'=>null])->save();
    expect($query->read($this->tenant->id,$this->user->id,false,1)['totals']['consumed'])->toBeNull();
    $card->forceFill(['archived_at'=>now()])->save();
    expect($query->read($this->tenant->id,$this->user->id,false,1)['total'])->toBe(0);
    expect($query->read($this->tenant->id,$this->user->id,true,1)['total'])->toBe(1);
    expect(LedgerEntry::count())->toBe($entries); Http::assertNothingSent();
});

it('keeps selected card scope totals across real pagination and retains negative net usage', function () {
    phaseTenReadyUser($this, '2000');
    TenantCardProductConfig::where('tenant_id',$this->tenant->id)->where('card_product_id',$this->product->id)->update(['max_cards_per_user'=>30]);
    for ($i=0; $i<21; $i++) { phaseTenHolder($this); phaseTenIssue($this); }
    $card = UserCard::where('tenant_id',$this->tenant->id)->where('user_id',$this->user->id)->firstOrFail();
    $card->forceFill(['provider_balance'=>'21'])->save();
    $query = app(\App\Application\User\PlatformUserCardsSummary::class);
    $first = $query->read($this->tenant->id,$this->user->id,false,1);
    $second = $query->read($this->tenant->id,$this->user->id,false,2);
    expect($first['items'])->toHaveCount(20)->and($second['items'])->toHaveCount(1)->and($first['total'])->toBe(21)->and($first['totals'])->toBe($second['totals']);
    expect((string) \Brick\Math\BigDecimal::of($first['totals']['funded'])->toScale(8))->toBe('420.00000000');
    expect((string) \Brick\Math\BigDecimal::of($first['totals']['consumed'])->toScale(8))->toBe('-1.00000000');
    $card->forceFill(['archived_at'=>now()])->save();
    expect($query->read($this->tenant->id,$this->user->id,false,1)['total'])->toBe(20);
    expect($query->read($this->tenant->id,$this->user->id,true,1)['items'][0]->consumed)->toBe('-1.00000000');
    Http::assertNothingSent();
});

function cardVoidFixture($test, bool $unknownReturn = false, bool $remainingBalance = false): array
{
    $state = (object) ['status' => 'normal', 'balance' => '20.00000000'];
    $card = null;
    [$card, $provider, $manage] = managedCardFixture($test, function () use ($state, &$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', $state->status, false, $state->balance);
    }, available: '1000');
    $provider->shouldReceive('freezeCard')->once()->andReturnUsing(function ($id, $request) use ($state) {
        $state->status = 'frozen';

        return new ProviderOperationDTO($request, ProviderOperationStatus::Succeeded, $id);
    });
    $provider->shouldReceive('returnCardFunds')->once()->andReturnUsing(function ($id, $amount, $request) use ($state, $unknownReturn, $remainingBalance) {
        expect($amount)->toBe('20.00000000');
        $state->balance = $remainingBalance ? '1.00000000' : '0.00000000';
        if ($unknownReturn) {
            throw new ProviderUnknownResultException('Timeout');
        }

        return new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'VOID-RETURN', '20.00000000', '19.00000000', '1.00000000');
    });
    if ($unknownReturn) {
        $provider->shouldReceive('queryCardFunds')->once()->andReturnUsing(fn ($id, $request) => new ProviderCardFundsDTO(ProviderOperationStatus::Succeeded, $id, $request, 'VOID-RETURN', '20.00000000', '19.00000000', '1.00000000'));
    }
    if ($remainingBalance) {
        $provider->shouldNotReceive('cancelCard');
    } else {
        $provider->shouldReceive('cancelCard')->once()->andReturnUsing(function ($id, $request) use ($state) {
            $state->status = 'cancelled';

            return new ProviderOperationDTO($request, ProviderOperationStatus::Succeeded, $id);
        });
    }
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();

    return [$card, $actor, $manage, $state];
}

function completeCardVoid($test, $service, $actor, string $batch): array
{
    for ($i = 0; $i < 12; $i++) {
        $data = $service->advance($actor, $batch);
        if ($data['counts']['SUCCEEDED'] + $data['counts']['FAILED'] === count($data['items'])) {
            return $data;
        }
        $test->travel(11)->seconds();
    }

    return $data;
}

it('card void refunds verified net provider and overflow funds once before cancellation with read-only history', function (bool $unknown): void {
    [$card, $actor, $manage] = cardVoidFixture($this, unknownReturn: $unknown);
    $card->forceFill(['balance_limit' => '0'])->save();
    $quote = $manage->quote($card->tenant_id, $card->user_id, $card->id, (string) Str::uuid(), '80');
    $manage->confirmLoad($card->tenant_id, $card->user_id, $card->id, $quote->id);
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $entries = LedgerEntry::count();
    $service = app(CardVoidBatch::class);
    $input = ['card_ids' => [$card->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true, 'tenant_id' => $card->tenant_id];
    $batch = $service->create($actor, $input);
    expect($service->create($actor, $input))->toBe($batch)->and(LedgerEntry::count())->toBe($entries);
    $this->actingAs($actor, 'platform_admin')->getJson('http://admin.localhost/platform/card-void-batches/'.$batch)->assertOk()->assertJsonPath('counts.PENDING', 1);
    expect(LedgerEntry::count())->toBe($entries);
    expect(fn () => $manage->quote($card->tenant_id, $card->user_id, $card->id, (string) Str::uuid(), '50'))->toThrow(DomainException::class);
    expect(fn () => app(RefundSecurityDepositAction::class)->request($card->tenant_id, $card->user_id, (string) Str::uuid()))->toThrow(DomainException::class, 'being voided');
    if ($unknown) {
        for ($i = 0; $i < 3; $i++) {
            $result = $service->advance($actor, $batch);
        }
        expect($result['counts']['UNKNOWN'])->toBe(1);
        $this->user->forceFill(['status' => 'SUSPENDED'])->save();
        $this->travel(11)->seconds();
        expect($service->advance($actor, $batch)['counts']['UNKNOWN'])->toBe(1);
        $this->user->forceFill(['status' => 'ACTIVE'])->save();
        $this->travel(11)->seconds();
    }
    $result = completeCardVoid($this, $service, $actor, $batch);
    expect($result['counts']['SUCCEEDED'])->toBe(1)->and($result['counts']['UNKNOWN'])->toBe(0)
        ->and($card->fresh()->provider_status)->toBe('cancelled')->and($card->fresh()->archived_at)->not->toBeNull()
        ->and($card->fresh()->overflowBalance())->toBe('0.00000000')
        ->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->add(Money::of('99', 'USDT'))->amount())
        ->and($result['items'][0]->returned)->toBe('99.00000000')->and($result['items'][0]->fee)->toBe('1.00000000');
    $summary = app(PlatformUserCardsSummary::class)->read($card->tenant_id, $card->user_id, true, 1);
    expect($summary['items'][0]->returned)->toBe('99.00000000')->and($summary['items'][0]->consumed)->toBe('1.00000000');
    $settled = LedgerEntry::count();
    $service->advance($actor, $batch);
    $service->retry($actor, $batch, ['confirmed' => true]);
    $service->show($actor, $batch);
    expect(LedgerEntry::count())->toBe($settled)->and(DB::table('card_overflow_movements')->where('kind', 'RETURN')->count())->toBe(1);
    DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
})->with([false, true]);

it('card void never cancels while a verified provider balance remains', function (): void {
    [$card, $actor] = cardVoidFixture($this, remainingBalance: true);
    $service = app(CardVoidBatch::class);
    $batch = $service->create($actor, ['card_ids' => [$card->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true]);
    $result = completeCardVoid($this, $service, $actor, $batch);
    expect($result['counts']['UNKNOWN'])->toBe(1)->and($result['items'][0]->error_code)->toBe('CARD_VOID_BALANCE_REMAINS')
        ->and($card->fresh()->archived_at)->toBeNull()->and($card->fresh()->provider_status)->toBe('frozen');
    expect(fn () => $service->create($actor, ['card_ids' => [$card->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true]))->toThrow(DomainException::class);
    DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
});

it('card void validates explicit confirmation scope identity and active administrators without provider reads', function (): void {
    [$card] = managedCardFixture($this);
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $this->actingAs($actor, 'platform_admin');
    $url = 'http://admin.localhost/platform/card-void-batches';
    $input = ['card_ids' => [$card->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true];
    $this->postJson($url, [...$input, 'confirmed' => false])->assertUnprocessable();
    $this->postJson($url, [...$input, 'tenant_id' => Tenant::where('id', '!=', $card->tenant_id)->firstOrFail()->id])->assertNotFound();
    $batch = $this->postJson($url, $input)->assertAccepted()->json('id');
    $this->postJson($url, $input)->assertAccepted()->assertJsonPath('id', $batch);
    $this->postJson($url, [...$input, 'tenant_id' => $card->tenant_id])->assertConflict();
    $this->getJson($url)->assertOk()->assertJsonCount(1, 'items');
    $this->getJson($url.'/'.$batch)->assertOk()->assertHeader('Cache-Control', 'no-store, private');
    $this->postJson($url.'/'.$batch.'/retry', [])->assertUnprocessable();
    $actor->forceFill(['status' => AdminUserStatus::Suspended])->save();
    $this->getJson($url.'/'.$batch)->assertForbidden();
});

it('card void cancellation timeout only queries the existing intent and keeps the balance reservation', function (): void {
    $state = 'frozen';
    $card = null;
    [$card, $provider] = managedCardFixture($this, function () use (&$state, &$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', $state, false, '0.00000000');
    });
    $provider->shouldNotReceive('returnCardFunds');
    $provider->shouldNotReceive('freezeCard');
    $provider->shouldReceive('cancelCard')->once()->andThrow(new ProviderUnknownResultException('Timeout'));
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $service = app(CardVoidBatch::class);
    $batch = $service->create($actor, ['card_ids' => [$card->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true]);
    for ($i = 0; $i < 4; $i++) {
        $result = $service->advance($actor, $batch);
    }
    expect($result['counts']['UNKNOWN'])->toBe(1)->and($card->fresh()->archived_at)->toBeNull();
    $service->retry($actor, $batch, ['confirmed' => true]);
    expect(DB::table('card_void_items')->where('batch_id', $batch)->value('attempt'))->toBe(1);
    $state = 'cancelled';
    $this->travel(11)->seconds();
    $result = completeCardVoid($this, $service, $actor, $batch);
    expect($result['counts']['SUCCEEDED'])->toBe(1)->and(CardManagementOrder::where('card_id', $card->id)->where('kind', 'CANCEL')->count())->toBe(1);
    DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
});

it('card void partial batches continue other cards and retry only definitive failures with new intents', function (): void {
    $states = [];
    $card = null;
    [$card, $provider] = managedCardFixture($this, function ($providerId) use (&$states, &$card) {
        return new ProviderCardDTO($providerId, '', $providerId === $card->provider_card_id ? $card->masked_pan : '•••• 8888', $providerId === $card->provider_card_id ? $card->last4 : '8888', 8, 2029, 'USD', $states[$providerId] ?? 'normal', false, '0.00000000');
    });
    $provider->shouldReceive('issueCard')->once()->andReturnUsing(fn ($request) => new ProviderOperationDTO($request->idempotencyKey, ProviderOperationStatus::Succeeded, 'XR-VOID-SECOND', card: new ProviderCardDTO('XR-VOID-SECOND', '', '•••• 8888', '8888', 8, 2029, 'USD', 'normal', false, '20.00000000')));
    $this->holder = phaseTenHolder($this);
    $order = phaseTenIssue($this);
    $second = UserCard::where('card_issue_order_id', $order->id)->firstOrFail();
    $reject = true;
    $provider->shouldReceive('freezeCard')->times(3)->andReturnUsing(function ($id, $request) use (&$states, &$reject, $card) {
        if ($id === $card->provider_card_id && $reject) {
            throw new ProviderRejectedException('rejected');
        }
        $states[$id] = 'frozen';

        return new ProviderOperationDTO($request, ProviderOperationStatus::Succeeded, $id);
    });
    $provider->shouldNotReceive('returnCardFunds');
    $provider->shouldReceive('cancelCard')->twice()->andReturnUsing(function ($id, $request) use (&$states) {
        $states[$id] = 'cancelled';

        return new ProviderOperationDTO($request, ProviderOperationStatus::Succeeded, $id);
    });
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $service = app(CardVoidBatch::class);
    $batch = $service->create($actor, ['card_ids' => [$card->id, $second->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true]);
    for ($i = 0; $i < 20; $i++) {
        $result = $service->advance($actor, $batch);
        $this->travel(11)->seconds();
    }
    expect($result['counts']['SUCCEEDED'])->toBe(1)->and($result['counts']['FAILED'])->toBe(1)->and($second->fresh()->archived_at)->not->toBeNull()->and($card->fresh()->archived_at)->toBeNull();
    $reject = false;
    $service->retry($actor, $batch, ['confirmed' => true]);
    $result = completeCardVoid($this, $service, $actor, $batch);
    expect($result['counts']['SUCCEEDED'])->toBe(2)
        ->and(CardManagementOrder::where('card_id', $card->id)->where('kind', 'FREEZE')->count())->toBe(2)
        ->and(CardManagementOrder::where('card_id', $second->id)->where('kind', 'FREEZE')->count())->toBe(1);
    DB::statement('SET CONSTRAINTS ALL IMMEDIATE');
});

it('card void refuses non-cent provider balances without truncation or cancellation', function (): void {
    $card = null;
    [$card, $provider] = managedCardFixture($this, function () use (&$card) {
        return new ProviderCardDTO($card->provider_card_id, '', $card->masked_pan, $card->last4, 8, 2029, 'USD', 'frozen', false, '20.12345678');
    });
    $provider->shouldNotReceive('returnCardFunds');
    $provider->shouldNotReceive('cancelCard');
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $service = app(CardVoidBatch::class);
    $before = LedgerEntry::count();
    $batch = $service->create($actor, ['card_ids' => [$card->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true]);
    $result = completeCardVoid($this, $service, $actor, $batch);
    expect($result['counts']['FAILED'])->toBe(1)->and($result['items'][0]->error_code)->toBe('CARD_VOID_PRECISION')
        ->and(LedgerEntry::count())->toBe($before)->and($card->fresh()->archived_at)->toBeNull();
});


it('provider removal blocks only current cards and retains archived card recovery bindings', function (string $status, bool $archived, bool $blocked): void {
    $card = localSimulationReadyCard($this, merchant: true);
    $card->forceFill(['provider_status' => $status, 'archived_at' => $archived ? now() : null])->save();
    $product = $card->product;
    $reference = $product->card_provider_reference_id;
    $actor = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $before = DB::table('ledger_entries')->count();
    $this->actingAs($actor, 'platform_admin')->get('http://admin.localhost/platform/card-providers')->assertOk()
        ->assertInertia(fn ($p) => $p->where('providers.data.0.canDelete', ! $blocked));
    $url = 'http://admin.localhost/platform/card-providers/'.$reference;
    $this->withSession(['_token' => 'provider-deletion-test']);
    $input = ['_token' => 'provider-deletion-test', 'version' => $product->cardProviderReference->version, 'confirmed' => true, 'request_id' => (string) Str::uuid()];
    if ($blocked) {
        $this->deleteJson($url, $input)->assertConflict()->assertJsonPath('error.code', 'CARD_PROVIDER_REFERENCE_IN_USE');
    } else {
        $this->deleteJson($url, $input)->assertRedirect();
        expect($product->fresh()->cardProviderReference->id)->toBe($reference)
            ->and(\App\Domain\CardProviderDirectory\Models\CardProviderReference::find($reference))->toBeNull()
            ->and(app(CardProductProviderRouter::class)->forCard($card->fresh())->available())->toBeTrue();
        expect(fn () => app(CardProductProviderRouter::class)->assertNewBusiness($product->fresh()))->toThrow(DomainException::class);
    }
    expect(DB::table('ledger_entries')->count())->toBe($before)->and($card->fresh()->card_product_id)->toBe($product->id);
    Http::assertNothingSent();
})->with([['normal', false, true], ['frozen', false, true], ['expired', false, true], ['unknown', false, true], ['cancelled', false, false], ['cancelled', true, false], ['normal', true, false]]);

function u1StandardFixture($test, bool $fees = true): object
{
    phaseTenReadyUser($test, '300.00000000', ProviderCardholderStatus::Rejected);
    $admin = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $service = app(U1Accounts::class);
    $ref = $service->save(null, ['name' => 'U1 standard offline', 'customer_no' => 'OFFLINE-CUSTOMER', 'api_key' => 'offline-u1-key',
        'base_url' => U1ApiClient::BASE_URL, 'enabled' => true, 'zero_fees_confirmed' => $fees, 'request_id' => (string) Str::uuid()], $admin);
    Http::preventStrayRequests();
    u1StandardFake();
    $service->check($ref->id, $admin);
    $previous = $test->product;
    $test->product = app(CreateCardProductAction::class)->execute([
        'name' => 'U1 USD', 'card_provider_reference_id' => $ref->id, 'provider_product_ref' => 'GROUP-SHARE', 'opening_fee' => '5',
        'minimum_initial_load' => '20', 'minimum_reload' => '20', 'status' => 'ACTIVE'], $admin);
    $config = TenantCardProductConfig::where('tenant_id', $test->tenant->id)->where('card_product_id', $previous->id)->sole()->replicate();
    $config->card_product_id = $test->product->id;
    $config->save();
    $test->holder = app(SubmitProviderCardholderAction::class)->execute($test->tenant->id, $test->user->id, independentCardMaterials($test));

    return DB::table('u1_connections')->where('reference_id', $ref->id)->firstOrFail();
}

function u1StandardFake(string $terminal = 'openvcc.success', bool $loseResponse = false, string $key = 'offline-u1-key', string $innerKey = 'offline-u1-key'): void
{
    Http::swap(new Factory);
    Http::preventStrayRequests();
    Http::fake(function ($request) use ($terminal, $loseResponse, $key, $innerKey) {
        $endpoint = basename($request->url());
        $data = match ($endpoint) {
            'queryaccount' => ['amount' => [['currency' => 'USD', 'freeAmt' => '999.12345678', 'unfreeAmt' => '0']], 'cardCount' => '0'],
            'querygroupno' => ['group' => [['currency' => 'USD', 'groupNo' => 'GROUP-SHARE', 'bin' => '412345', 'model' => 'SHARE'], ['currency' => 'USD', 'groupNo' => 'GROUP-SINGLE', 'bin' => '412346', 'model' => 'SINGLE']]],
            'vccquery' => ['cardNo' => 'U1-CARD-001', 'amount' => '100.00000000', 'status' => '1'],
            'querycvv' => ['status' => '1', 'cardNo' => '4111111111114242', 'cvv' => '123', 'expiry' => '12/29'],
            'queryapiid' => (function () use ($request, $terminal, $innerKey) {
                $event = ['apiId' => $request['apiId'], 'type' => $terminal, 'cardNo' => 'U1-CARD-001', 'timestamp' => (string) now()->getTimestampMs()];
                $event['sign'] = md5(implode('', array_map(fn ($name) => $event[$name], U1NotificationVerifier::FIELDS[$terminal])).$innerKey);

                return json_encode($event, JSON_THROW_ON_ERROR);
            })(),
            'vcctrade' => [],
            'vccopen','vccrechage','vccwithdraw' => [],
            default => throw new RuntimeException('Unexpected U1 endpoint: '.$endpoint),
        };
        if (in_array($endpoint, ['vccopen', 'vccrechage', 'vccwithdraw'], true)) {
            expect($request->data())->not->toHaveKey('requestId');
            if ($loseResponse) {
                throw new ConnectionException('offline lost response');
            }
        }

        return Http::response(['resultCode' => '0000', 'timestamp' => $request['timestamp'],
            'sign' => md5('0000'.$request['timestamp'].$key), 'apiId' => 'API-'.$endpoint, 'data' => $data]);
    });
}

it('settles U1 issuance only after authoritative asynchronous evidence and never creates an upstream holder', function (): void {
    $connection = u1StandardFixture($this);
    expect($this->holder->provider)->toBe('U1')->and($this->holder->status)->toBe(ProviderCardholderStatus::LocalReady)
        ->and($this->holder->provider_cardholder_id)->toBeNull()->and($this->product->source_bin)->toBe('412345');
    $request = (string) Str::uuid();
    $order = phaseTenIssue($this, '100.00', $request);
    expect($order->provider)->toBe('U1')->and($order->status->value)->toBe('PROCESSING')
        ->and(UserCard::where('provider', 'U1')->count())->toBe(0);
    phaseTenIssue($this, '100.00', $request);
    $completed = app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id);
    expect($completed->status->value)->toBe('SUCCEEDED');
    $card = UserCard::where('provider', 'U1')->sole();
    expect($card->last4)->toBe('4242')->and($card->provider)->toBe('U1')->and($card->provider_balance)->toBe('100.00000000');
    app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id);
    Http::assertSent(fn ($request) => str_ends_with($request->url(), '/vccopen') && $request['groupNo'] === 'GROUP-SHARE');
    expect(collect(Http::recorded())->filter(fn ($pair) => str_ends_with($pair[0]->url(), '/vccopen'))->count())->toBe(1);
    expect(DB::table('u1_operations')->sole()->status)->toBe('SUCCEEDED');
    expect(DB::table('user_cards')->where('id', $card->id)->get()->toJson())->not->toContain('4111111111114242');
});

it('keeps uncertain U1 openings reserved without blindly resending or querying undocumented request IDs', function (): void {
    u1StandardFixture($this);
    u1StandardFake(loseResponse: true);
    $request = (string) Str::uuid();
    $order = phaseTenIssue($this, '100.00', $request);
    expect($order->status->value)->toBe('UNKNOWN');
    phaseTenIssue($this, '100.00', $request);
    app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id);
    expect(DB::table('u1_operations')->sole()->api_id)->toBeNull();
    expect(DB::table('u1_operations')->count())->toBe(1);
    Http::assertNothingSent();
    expect(UserCard::where('provider', 'U1')->count())->toBe(0);
});

it('processes U1 callbacks by existing scoped intents, masks OTPs and permits only fresh owner reads', function (): void {
    $connection = u1StandardFixture($this);
    $order = phaseTenIssue($this, '100.00');
    $payload = ['apiId' => 'API-vccopen', 'type' => 'openvcc.success', 'cardNo' => 'U1-CARD-001', 'timestamp' => (string) now()->getTimestampMs()];
    $payload['sign'] = md5($payload['apiId'].$payload['type'].$payload['cardNo'].$payload['timestamp'].'offline-u1-key');
    $accounts = app(U1Accounts::class);
    $event = $accounts->receive($connection->id, json_encode($payload));
    app(U1Callbacks::class)->process($connection->id, $event['id']);
    expect($order->fresh()->status->value)->toBe('SUCCEEDED')->and(DB::table('u1_notifications')->value('processing_status'))->toBe('PROCESSED');
    $card = UserCard::where('provider', 'U1')->sole();
    $otp = ['type' => 'otp', 'cardNo' => $card->provider_card_id, 'timestamp' => (string) now()->getTimestampMs(), 'otp' => '876543'];
    $otp['sign'] = md5($otp['cardNo'].$otp['type'].$otp['timestamp'].$otp['otp'].'offline-u1-key');
    $event = $accounts->receive($connection->id, json_encode($otp));
    expect(app(U1Callbacks::class)->otp($card->tenant_id, $card->user_id, $card->id)['code'])->toBe('876543');
    expect(json_encode($accounts->notification($connection->reference_id, $event['id'])))->not->toContain('876543');
    $this->travel(6)->minutes();
    expect(app(U1Callbacks::class)->otp($card->tenant_id, $card->user_id, $card->id))->toBeNull();
});

it('recovers accepted U1 openings across credential rotation using only their encrypted key snapshot', function (): void {
    $connection = u1StandardFixture($this);
    $order = phaseTenIssue($this, '100.00');
    $service = app(U1Accounts::class);
    $admin = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    $service->save($connection->reference_id, ['name' => 'U1 rotated', 'customer_no' => $connection->customer_no, 'base_url' => $connection->base_url,
        'api_key' => 'replacement-key', 'version' => 1, 'enabled' => true, 'zero_fees_confirmed' => true], $admin);
    u1StandardFake(key: 'replacement-key');
    $service->check($connection->reference_id, $admin);
    expect(app(SyncCardIssueAction::class)->execute($this->tenant->id, $order->id, $this->user->id)->status->value)->toBe('SUCCEEDED');
});

it('rejects duplicate physical BIN claims even when U1 group IDs differ', function (): void {
    $connection = u1StandardFixture($this);
    $admin = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    DB::table('u1_connections')->where('id', $connection->id)->update(['group_catalog' => json_encode([
        ['currency' => 'USD', 'groupNo' => 'OTHER-GROUP', 'bin' => '412345', 'model' => 'SHARE']])]);
    expect(fn () => app(CreateCardProductAction::class)->execute([
        'name' => 'duplicate U1 BIN', 'card_provider_reference_id' => $connection->reference_id, 'provider_product_ref' => 'OTHER-GROUP',
        'minimum_initial_load' => '20', 'minimum_reload' => '20', 'opening_fee' => '0', 'status' => 'ACTIVE'], $admin))->toThrow(ValidationException::class);
});

it('settles U1 recharge and SHARE withdrawal once through existing wallet ledgers', function (): void {
    u1StandardFixture($this);
    $issue = phaseTenIssue($this, '100.00');
    app(SyncCardIssueAction::class)->execute($this->tenant->id, $issue->id, $this->user->id);
    $card = UserCard::where('provider', 'U1')->sole();
    $manage = app(ManageCardAction::class);
    $quote = $manage->quote($card->tenant_id, $card->user_id, $card->id, (string) Str::uuid(), '20.00');
    expect($quote->status)->toBe('QUOTED')->and($quote->fee_amount)->toBe('0.00000000');
    $pending = $manage->confirmLoad($card->tenant_id, $card->user_id, $card->id, $quote->id);
    expect($pending->status)->toBe('UNKNOWN');
    u1StandardFake('rechargevcc.success');
    expect($manage->sync($card->tenant_id, $pending->id)->status)->toBe('SUCCEEDED');
    $entries = LedgerEntry::count();
    $manage->sync($card->tenant_id, $pending->id);
    expect(LedgerEntry::count())->toBe($entries);
    u1StandardFake('withdrawvcc.success');
    $before = phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance;
    $return = $manage->operate($card->tenant_id, $card->user_id, $card->id, (string) Str::uuid(), 'RETURN', '20.00');
    expect($return->status)->toBe('UNKNOWN')->and(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe($before);
    expect($manage->sync($card->tenant_id, $return->id)->status)->toBe('SUCCEEDED');
    expect(phaseTenAccount($this, LedgerAccountType::UserAvailable)->balance)->toBe(Money::of($before, 'USDT')->add(Money::of('20', 'USDT'))->amount());
});

it('blocks U1 funding without confirmed terms and voiding without a cancellation API before funds move', function (): void {
    u1StandardFixture($this, fees: false);
    $issue = phaseTenIssue($this, '100.00');
    app(SyncCardIssueAction::class)->execute($this->tenant->id, $issue->id, $this->user->id);
    $card = UserCard::where('provider', 'U1')->sole();
    $entries = LedgerEntry::count();
    $quote = app(ManageCardAction::class)->quote($card->tenant_id, $card->user_id, $card->id, (string) Str::uuid(), '20.00');
    expect($quote->status)->toBe('FAILED')->and(LedgerEntry::count())->toBe($entries);
    $admin = AdminUser::where('email', 'owner@platform.local')->firstOrFail();
    expect(fn () => app(CardVoidBatch::class)->create($admin, ['card_ids' => [$card->id], 'request_id' => (string) Str::uuid(), 'confirmed' => true]))
        ->toThrow(DomainException::class, 'cancellation');
    expect(DB::table('card_void_batches')->count())->toBe(0)->and(LedgerEntry::count())->toBe($entries);
});

it('rejects mismatched U1 operation evidence while retaining the accepted intent', function (): void {
    u1StandardFixture($this);
    $issue = phaseTenIssue($this, '100.00');
    u1StandardFake('rechargevcc.success');
    $result = app(SyncCardIssueAction::class)->execute($this->tenant->id, $issue->id, $this->user->id);
    expect($result->status->value)->toBe('UNKNOWN')->and(UserCard::where('provider', 'U1')->count())->toBe(0);
});

it('uses U1 transaction notifications only to refresh scoped authoritative balances and trade evidence', function (): void {
    $connection = u1StandardFixture($this);
    $issue = phaseTenIssue($this, '100.00');
    app(SyncCardIssueAction::class)->execute($this->tenant->id, $issue->id, $this->user->id);
    $card = UserCard::where('provider', 'U1')->sole();
    Http::swap(new Factory);
    Http::preventStrayRequests();
    Http::fake(function ($request) use ($card) {
        $base = ['resultCode' => '0000', 'timestamp' => $request['timestamp'], 'sign' => md5('0000'.$request['timestamp'].'offline-u1-key')];
        if (str_ends_with($request->url(), '/vccquery')) {
            expect($request['cardNo'])->toBe($card->provider_card_id);

            return Http::response($base + ['data' => ['cardNo' => $card->provider_card_id, 'status' => '1', 'amount' => '99.12345678']]);
        }
        expect($request->url())->toEndWith('/vcctrade')->and($request['cardNo'])->toBe($card->provider_card_id);

        return Http::response($base + ['vcctradelist' => [['uuid' => 'TRADE-001', 'cardNo' => $card->provider_card_id,
            'tradeAmount' => '-0.00000001', 'tradeCurrency' => 'USD', 'tradeTime' => (string) now()->getTimestampMs(), 'tradeStatus' => '1', 'tradeType' => '1', 'feeAmount' => '0.12345678', 'feeCurrency' => 'USD']]]);
    });
    $event = ['type' => 'transaction', 'timestamp' => (string) now()->getTimestampMs(), 'cardno' => $card->provider_card_id, 'amount' => '999999', 'free' => '999999'];
    $event['sign'] = md5($event['type'].$event['timestamp'].'offline-u1-key');
    $row = app(U1Accounts::class)->receive($connection->id, json_encode($event));
    $entries = LedgerEntry::count();
    app(U1Callbacks::class)->process($connection->id, $row['id']);
    expect($card->fresh()->provider_balance)->toBe('99.12345678')->and(LedgerEntry::count())->toBe($entries);
    $trade = DB::table('card_transactions')->where('card_id',$card->id)->sole();
    expect($trade->amount)->toBe('-0.00000001')->and($trade->fee_amount)->toBe('0.12345678')->and($trade->type)->toBe('1');
    app(U1Callbacks::class)->process($connection->id,$row['id']);
    expect(DB::table('card_transactions')->where('card_id',$card->id)->count())->toBe(1);
});

it('requires card owner scope and the current password before disclosing a U1 OTP', function (): void {
    $connection=u1StandardFixture($this);
    $issue=phaseTenIssue($this,'100.00');
    app(SyncCardIssueAction::class)->execute($this->tenant->id,$issue->id,$this->user->id);
    $card=UserCard::where('provider','U1')->sole();
    $event=['type'=>'otp','cardNo'=>$card->provider_card_id,'timestamp'=>(string) now()->getTimestampMs(),'otp'=>'876543'];
    $event['sign']=md5($event['cardNo'].$event['type'].$event['timestamp'].$event['otp'].'offline-u1-key');
    app(\App\Application\CardProviderDirectory\U1Accounts::class)->receive($connection->id,json_encode($event));
    $url='http://a.localhost/cards/'.$card->id.'/management';
    $this->actingAs($this->user,'tenant_user')->postJson($url,['action'=>'otp','current_password'=>'incorrect'])->assertUnprocessable();
    $response=$this->postJson($url,['action'=>'otp','current_password'=>'local-password'])->assertOk()->assertJsonPath('code','876543');
    expect($response->headers->get('Cache-Control'))->toContain('no-store');
    expect(DB::table('audit_logs')->where('action','CARD_OTP_VIEWED')->get()->toJson())->not->toContain('876543');
    $other=User::where('tenant_id','!=',$this->tenant->id)->firstOrFail();
    $denied=$this->actingAs($other,'tenant_user')->postJson($url,['action'=>'otp','current_password'=>'local-password'])->assertRedirect();
    expect($denied->getContent())->not->toContain('876543');
    expect(fn()=>app(U1Callbacks::class)->otp($card->tenant_id,$other->id,$card->id))->toThrow(\Illuminate\Database\Eloquent\ModelNotFoundException::class);
});
