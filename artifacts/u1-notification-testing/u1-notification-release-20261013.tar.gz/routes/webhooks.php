<?php

use App\Http\Controllers\Webhooks\PaymentWebhookController;
use App\Http\Controllers\Webhooks\PhotonPayWebhookController;
use App\Http\Controllers\Webhooks\U1TestWebhookController;
use Illuminate\Support\Facades\Route;

Route::post('/u1/{connection}', U1TestWebhookController::class)
    ->whereUuid('connection')->middleware('throttle:300,1')->name('webhooks.u1.test');

Route::post('/payments/{provider}', PaymentWebhookController::class)
    ->where('provider', '[a-z0-9_-]{2,64}')
    ->middleware('throttle:120,1')
    ->name('webhooks.payments');

Route::post('/card-provider', PhotonPayWebhookController::class)->middleware('throttle:300,1')->name('webhooks.photonpay');

Route::post('/card-provider/{account}', PhotonPayWebhookController::class)->whereUuid('account')->middleware('throttle:300,1')->name('webhooks.photonpay.account');
