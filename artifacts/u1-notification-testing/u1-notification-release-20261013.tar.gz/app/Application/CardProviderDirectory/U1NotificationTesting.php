<?php

namespace App\Application\CardProviderDirectory;

use App\Domain\Admin\Models\AdminUser;
use App\Domain\Audit\Services\AuditLogger;
use App\Domain\CardProviderDirectory\Models\CardProviderReference;
use App\Infrastructure\Assets\ExactJson;
use App\Infrastructure\Providers\Card\U1NotificationVerifier;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

final class U1NotificationTesting
{
    public const BASE_URL = 'https://api.uucard.cyou/v1';

    public function __construct(private PhotonPayAccounts $authorization, private U1NotificationVerifier $verifier) {}

    public function save(?string $id, #[\SensitiveParameter] array $input, AdminUser $actor): CardProviderReference
    {
        $this->authorization->authorize($actor);
        $data = Validator::make($input, [
            'name' => ['required', 'string', 'max:120'],
            'customer_no' => ['required', 'string', 'regex:/^[a-zA-Z0-9_-]{1,100}$/D'],
            'api_key' => ['nullable', 'string', 'max:2000'],
            'base_url' => ['required', Rule::in([self::BASE_URL])],
            'version' => [$id ? 'required' : 'prohibited', 'integer', 'min:1'],
            'request_id' => [$id ? 'prohibited' : 'required', 'uuid'],
        ])->validate();
        $data['name'] = trim($data['name']);
        if ($data['name'] === '') {
            throw ValidationException::withMessages(['name' => 'A card provider name is required.']);
        }
        $creationHash = hash_hmac('sha256', json_encode([$data['name'], $data['customer_no'], $data['base_url'], $data['api_key'] ?? ''], JSON_THROW_ON_ERROR), config('app.key'));

        $creating = $id === null;

        return DB::transaction(function () use ($id, $data, $actor, $creationHash, $creating): CardProviderReference {
            $this->authorization->authorize($actor);
            if (! $id) {
                $id = $data['request_id'];
                DB::select('SELECT pg_advisory_xact_lock(hashtextextended(?,0))', ['card-provider-reference:'.$id]);
                $existing = DB::table('u1_test_connections')->where('reference_id', $id)->first();
                if ($existing) {
                    $reference = CardProviderReference::whereKey($id)->lockForUpdate()->firstOrFail();
                    if ($reference->created_by !== $actor->id || ! hash_equals($existing->creation_hash, $creationHash)) {
                        throw ValidationException::withMessages(['request_id' => 'This request was already used. Start a new creation request.']);
                    }

                    return $reference;
                }
                // Never convert a historical creation request to another provider.
                if (DB::table('platform_card_provider_references')->where('id', $id)->exists()) {
                    throw ValidationException::withMessages(['request_id' => 'This request was already used. Start a new creation request.']);
                }
                $row = app(SaveCardProviderReferenceAction::class)->execute(null, [
                    'name' => $data['name'], 'reference_balance' => '0.00', 'request_id' => $id,
                ], $actor, notificationOnly: true);
            } else {
                $row = CardProviderReference::whereKey($id)->lockForUpdate()->firstOrFail();
                if ($row->version !== (int) $data['version']) {
                    throw ValidationException::withMessages(['version' => 'Configuration changed. Refresh before saving.']);
                }
            }
            if ($row->runtime_driver !== 'UNCONFIGURED' || $row->photonpay_issuing_encrypted || $row->photonpay_identity || DB::table('card_products')->where('card_provider_reference_id', $row->id)->exists()) {
                throw ValidationException::withMessages(['provider_type' => 'This connection cannot be converted to U1 notification testing.']);
            }
            $connection = DB::table('u1_test_connections')->where('reference_id', $row->id)->first();
            if ($connection && $connection->customer_no !== $data['customer_no']) {
                throw ValidationException::withMessages(['customer_no' => 'Customer number is locked. Create a separate connection instead.']);
            }
            $key = $data['api_key'] ?? '';
            if ($key === '' && ! $connection) {
                throw ValidationException::withMessages(['api_key' => 'U1 API key is required.']);
            }
            if ($connection) {
                $values = ['updated_at' => now()];
                if ($key !== '') {
                    $values['api_key_encrypted'] = Crypt::encryptString($key);
                }
                DB::table('u1_test_connections')->where('id', $connection->id)->update($values);
                $row->forceFill(['name' => $data['name'], 'version' => $row->version + 1, 'updated_by' => $actor->id])->save();
            } else {
                DB::table('u1_test_connections')->insert([
                    'id' => (string) Str::uuid(), 'reference_id' => $row->id, 'customer_no' => $data['customer_no'],
                    'base_url' => self::BASE_URL, 'api_key_encrypted' => Crypt::encryptString($key),
                    'creation_hash' => $creationHash, 'created_at' => now(), 'updated_at' => now(),
                ]);
                if (! $creating) {
                    $row->forceFill(['name' => $data['name'], 'version' => $row->version + 1, 'updated_by' => $actor->id])->save();
                }
            }
            app(AuditLogger::class)->record(null, 'ADMIN', $actor->id, 'U1_NOTIFICATION_CONNECTION_SAVED', 'card_provider_reference', $row->id, null, [
                'mode' => 'NOTIFICATION_TEST_ONLY', 'credentials_replaced' => $key !== '', 'version' => $row->version,
            ]);

            return $row;
        });
    }

    public function publicConfiguration(string $reference): ?array
    {
        $connection = DB::table('u1_test_connections')->where('reference_id', $reference)->first();
        if (! $connection) {
            return null;
        }
        // Use configured application origin, never an untrusted request Host.
        $host = parse_url((string) config('app.url'), PHP_URL_HOST);
        $port = parse_url((string) config('app.url'), PHP_URL_PORT);
        $origin = $host ? 'https://'.$host.($port ? ':'.$port : '') : null;

        return ['customerNo' => $connection->customer_no, 'baseUrl' => $connection->base_url,
            'callbackUrl' => $origin ? $origin.'/webhooks/u1/'.$connection->id : null,
            'mode' => 'NOTIFICATION_TEST_ONLY', 'types' => array_keys(U1NotificationVerifier::FIELDS)];
    }

    private function connection(string $reference): object
    {
        CardProviderReference::findOrFail($reference);

        return DB::table('u1_test_connections')->where('reference_id', $reference)->firstOrFail();
    }

    public function send(string $reference, array $input, AdminUser $actor): array
    {
        $this->authorization->authorize($actor);
        $data = Validator::make($input, [
            'request_id' => ['required', 'uuid'], 'version' => ['required', 'integer', 'min:1'],
            'notification_type' => ['required', Rule::in(array_keys(U1NotificationVerifier::FIELDS))],
        ])->validate();
        [$connection, $created] = DB::transaction(function () use ($reference, $data, $actor): array {
            $this->authorization->authorize($actor);
            $row = CardProviderReference::whereKey($reference)->lockForUpdate()->firstOrFail();
            $connection = $this->connection($reference);
            DB::select('SELECT pg_advisory_xact_lock(hashtextextended(?,0))', ['u1-test-request:'.$data['request_id']]);
            $old = DB::table('u1_test_requests')->where('id', $data['request_id'])->first();
            if ($old) {
                abort_unless($old->connection_id === $connection->id && $old->actor_id === $actor->id && $old->notification_type === $data['notification_type'] && $old->connection_version === (int) $data['version'], 409);

                return [$connection, false];
            }
            if ($row->version !== (int) $data['version']) {
                throw ValidationException::withMessages(['version' => 'Configuration changed. Refresh before saving.']);
            }
            DB::table('u1_test_requests')->insert(['id' => $data['request_id'], 'connection_id' => $connection->id,
                'actor_id' => $actor->id, 'connection_version' => $row->version, 'notification_type' => $data['notification_type'],
                'status' => 'REQUESTING', 'requested_at' => now()]);
            app(AuditLogger::class)->record(null, 'ADMIN', $actor->id, 'U1_NOTIFICATION_TEST_REQUESTED', 'card_provider_reference', $reference, null,
                ['test_request_id' => $data['request_id'], 'notification_type' => $data['notification_type']]);

            return [$connection, true];
        });
        if ($created) {
            $status = 'UNKNOWN';
            $body = null;
            try {
                if ($connection->base_url !== self::BASE_URL) {
                    throw new \RuntimeException('Unsupported U1 origin.');
                }
                $key = Crypt::decryptString($connection->api_key_encrypted);
                $timestamp = (string) now()->getTimestampMs();
                $response = Http::connectTimeout(5)->timeout(15)->withoutRedirecting()->post(self::BASE_URL.'/api/notifytest', [
                    'customerNo' => $connection->customer_no, 'editType' => $data['notification_type'], 'timestamp' => $timestamp,
                    'sign' => md5($connection->customer_no.$data['notification_type'].$timestamp.$key),
                ]);
                if (strlen($response->body()) <= 262144) {
                    $body = $response->body();
                    $decoded = ExactJson::decode($body);
                    if ($response->successful() && is_string($decoded['resultCode'] ?? null) && is_string($decoded['timestamp'] ?? null)
                        && is_string($decoded['sign'] ?? null) && preg_match('/^[a-fA-F0-9]{32}$/D', $decoded['sign'])
                        && hash_equals(md5($decoded['resultCode'].$decoded['timestamp'].$key), strtolower($decoded['sign']))) {
                        $status = in_array($decoded['resultCode'], ['0000', '0001', '0003'], true) ? 'ACCEPTED' : 'REJECTED';
                    }
                }
            } catch (\Throwable) {
                // Do not log HTTP exceptions: they may contain signatures or provider response secrets.
                $status = 'UNKNOWN';
            }
            DB::table('u1_test_requests')->where('id', $data['request_id'])->update([
                'status' => $status, 'response_encrypted' => $body === null ? null : Crypt::encryptString($body), 'finished_at' => now(),
            ]);
        }

        return $this->requestStatus($reference, $data['request_id']);
    }

    public function requestStatus(string $reference, string $id): array
    {
        $connection = $this->connection($reference);
        $request = DB::table('u1_test_requests')->where('connection_id', $connection->id)->where('id', $id)->firstOrFail();
        // notifytest does not document correlation with its generated callback API/card IDs.
        // This is an observation, not a claim that the callback belongs to this request.
        $event = DB::table('u1_test_notifications')->where('connection_id', $connection->id)
            ->where('notification_type', $request->notification_type)->where('verified', true)
            ->where('last_received_at', '>=', $request->requested_at)->latest('last_received_at')->first();
        $waiting = now()->diffInSeconds($request->requested_at, true) < 30;

        return ['id' => $request->id, 'type' => $request->notification_type, 'status' => $request->status,
            'notificationStatus' => $event ? 'RECEIVED' : ($waiting ? 'WAITING' : 'NOT_RECEIVED'),
            'notificationId' => $event?->id, 'correlation' => 'TYPE_AND_RECEIVE_TIME_ONLY',
            'requestedAt' => $request->requested_at,
            'response' => $request->response_encrypted ? $this->verifier->display(Crypt::decryptString($request->response_encrypted)) : null];
    }

    public function receive(string $connectionId, #[\SensitiveParameter] string $body): array
    {
        abort_if(strlen($body) > 262144, 413);

        return DB::transaction(function () use ($connectionId, $body): array {
            $connection = DB::table('u1_test_connections')->where('id', $connectionId)->firstOrFail();
            // Locks serialize duplicate deliveries, key replacement, and provider deletion.
            CardProviderReference::whereKey($connection->reference_id)->lockForUpdate()->firstOrFail();
            $connection = DB::table('u1_test_connections')->where('id', $connectionId)->firstOrFail();
            $facts = $this->verifier->verify($body, Crypt::decryptString($connection->api_key_encrypted));
            $digest = hash('sha256', $body);
            $old = DB::table('u1_test_notifications')->where('connection_id', $connectionId)->where('body_digest', $digest)->first();
            if ($old) {
                DB::table('u1_test_notifications')->where('id', $old->id)->update([
                    'delivery_count' => $old->delivery_count + 1, 'last_received_at' => now(),
                    'verified' => $facts['verified'], 'verification_reason' => $facts['reason'],
                ]);
            } else {
                DB::table('u1_test_notifications')->insert([
                    'id' => (string) Str::uuid(), 'connection_id' => $connectionId, 'body_digest' => $digest,
                    'notification_type' => $facts['type'], 'verified' => $facts['verified'], 'verification_reason' => $facts['reason'],
                    'body_encrypted' => Crypt::encryptString($body), 'delivery_count' => 1,
                    'received_at' => now(), 'last_received_at' => now(),
                ]);
            }

            return $facts;
        });
    }

    public function notifications(string $reference, int $page): array
    {
        $connection = $this->connection($reference);
        $rows = DB::table('u1_test_notifications')->where('connection_id', $connection->id)
            ->orderByDesc('received_at')->orderBy('id')->paginate(20, ['id', 'notification_type', 'verified', 'verification_reason', 'delivery_count', 'received_at', 'last_received_at'], 'page', $page);

        return ['items' => $rows->items(), 'page' => $rows->currentPage(), 'pages' => $rows->lastPage(), 'total' => $rows->total()];
    }

    public function recentRequests(string $reference): array
    {
        $connection = $this->connection($reference);

        return DB::table('u1_test_requests')->where('connection_id', $connection->id)
            ->orderByDesc('requested_at')->orderByDesc('id')->limit(9)->pluck('id')
            ->map(fn ($id) => $this->requestStatus($reference, $id))->all();
    }

    public function notification(string $reference, string $id): array
    {
        $connection = $this->connection($reference);
        $row = DB::table('u1_test_notifications')->where('connection_id', $connection->id)->where('id', $id)->firstOrFail();
        $data = $this->verifier->display(Crypt::decryptString($row->body_encrypted));
        $fields = ['cardno', 'cardNo', 'apiId', 'tradetime', 'tradeTime', 'status', 'tradeStatus', 'tradetype', 'tradeType',
            'amount', 'tradeAmt', 'tradeAmount', 'currency', 'tradeCurrency', 'billingamount', 'billAmount', 'billingcurrency', 'billCurrency',
            'free', 'freeAmount', 'freecurrency', 'feeAmount', 'feeCurrency', 'merchantinfo', 'merchantName', 'wallet', 'description'];

        return ['id' => $row->id, 'type' => $row->notification_type, 'verified' => (bool) $row->verified,
            'reason' => $row->verification_reason, 'deliveries' => $row->delivery_count,
            'receivedAt' => $row->received_at, 'lastReceivedAt' => $row->last_received_at,
            'fields' => array_combine($fields, array_map(fn ($field) => $data[$field] ?? null, $fields)),
            'payload' => $data, 'signedFields' => U1NotificationVerifier::FIELDS[$row->notification_type] ?? [],
            'balanceIndependentlyVerified' => false];
    }
}
