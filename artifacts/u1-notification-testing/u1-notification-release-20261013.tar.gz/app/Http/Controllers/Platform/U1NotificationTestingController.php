<?php

namespace App\Http\Controllers\Platform;

use App\Application\CardProviderDirectory\U1NotificationTesting;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class U1NotificationTestingController extends Controller
{
    public function send(string $reference, Request $request, U1NotificationTesting $testing)
    {
        return response()->json($testing->send($reference, $request->only(['request_id', 'version', 'notification_type']), $request->user('platform_admin')))
            ->header('Cache-Control', 'private, no-store');
    }

    public function index(string $reference, Request $request, U1NotificationTesting $testing)
    {
        $data = $request->validate(['page' => ['nullable', 'integer', 'min:1', 'max:100000'],
            'request_ids' => ['nullable', 'array', 'max:9'], 'request_ids.*' => ['required', 'uuid']]);
        $result = $testing->notifications($reference, (int) ($data['page'] ?? 1));
        $result['requests'] = empty($data['request_ids']) ? $testing->recentRequests($reference)
            : array_map(fn ($id) => $testing->requestStatus($reference, $id), $data['request_ids']);

        return response()->json($result)->header('Cache-Control', 'private, no-store');
    }

    public function show(string $reference, string $notification, U1NotificationTesting $testing)
    {
        return response()->json($testing->notification($reference, $notification))->header('Cache-Control', 'private, no-store');
    }
}
